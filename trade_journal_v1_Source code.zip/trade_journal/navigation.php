<?php
// Get current page for highlighting active nav item
$current_page = basename($_SERVER['PHP_SELF']);
?>
<nav class="navbar navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand" href="index.php">
            <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
                <polyline
                    points="10,90 40,30 60,50 90,10"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="10"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                />
            </svg>
            Trade Journal
        </a>
        <div class="d-flex align-items-center">
            <?php include('theme-select.php'); ?>
            
            <a href="index.php" class="nav-button <?= $current_page === 'index.php' ? 'active' : '' ?>">
                <i class="fas fa-home me-2"></i>Dashboard
            </a>
            <a href="analysis.php" class="nav-button <?= $current_page === 'analysis.php' ? 'active' : '' ?>">
                <i class="fas fa-chart-line me-2"></i>Analysis
            </a>
            <a href="wallet_chart.php" class="nav-button <?= $current_page === 'wallet_chart.php' ? 'active' : '' ?>">
                <i class="fas fa-wallet me-2"></i>Balance
            </a>
            <a href="pcal.php" class="nav-button <?= $current_page === 'pcal.php' ? 'active' : '' ?>">
                <i class="fas fa-calculator me-2"></i>Calculator
            </a>
            <div class="dropdown">
                <button class="nav-button dropdown-toggle" type="button" id="profileDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="fas fa-user-circle me-2"></i>Profile
                </button>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="profileDropdown">
                    <li>
                        <a class="dropdown-item <?= $current_page === 'settings.php' ? 'active' : '' ?>" href="settings.php">
                            <i class="fas fa-cog me-2"></i>Settings
                        </a>
                    </li>
                    <li>
                        <a class="dropdown-item <?= $current_page === 'user_guide.php' ? 'active' : '' ?>" href="user_guide.php">
                            <i class="fas fa-book me-2"></i>Guide
                        </a>
                    </li>

                    <li><hr class="dropdown-divider"></li>
                    <li>
                        <a class="dropdown-item text-danger" href="logout.php">
                            <i class="fas fa-sign-out-alt me-2"></i>Logout
                        </a>
                    </li>
                </ul>
            </div>
            <a href="add_trade.php" class="nav-button primary <?= $current_page === 'add_trade.php' ? 'active' : '' ?>">
                <i class="fas fa-plus me-2"></i>Add Trade
            </a>
        </div>
    </div>
</nav>

<?php include('theme-select.php'); ?>