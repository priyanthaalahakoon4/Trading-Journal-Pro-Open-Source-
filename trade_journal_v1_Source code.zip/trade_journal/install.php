<?php
/**
 * Trade Journal Installation Wizard
 * 
 * Multi-step installation process:
 * 1. System Requirements
 * 2. Database Configuration
 * 3. User Account Setup
 * 4. Installation Complete
 */

// Prevent any output before headers are sent
ob_start();

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

include_once 'auth.php';

// Redirect to dashboard if already installed
if (is_installed() && !isset($_GET['force'])) {
    header('Location: index.php');
    exit;
}

// Current step (default to 1)
$current_step = isset($_GET['step']) ? (int)$_GET['step'] : 1;
// If beyond range, default to step 1
if ($current_step < 1 || $current_step > 4) {
    $current_step = 1;
}

// Check for installation in progress
if (isset($_SESSION['installation_progress'])) {
    $installation_progress = $_SESSION['installation_progress'];
} else {
    $installation_progress = [
        'db_host' => '',
        'db_user' => '',
        'db_pass' => '',
        'db_name' => '',
        'currency_symbol' => '$',
        'initial_capital' => '1000',
        'username' => '',
        'password' => ''
    ];
    $_SESSION['installation_progress'] = $installation_progress;
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Process based on current step
    switch ($current_step) {
        case 1:
            // System requirements validated, proceed to next step
            header('Location: install.php?step=2');
            exit;
            break;
            
        case 2:
            // Database configuration
            $db_host = $_POST['db_host'] ?? '';
            $db_user = $_POST['db_user'] ?? '';
            $db_pass = $_POST['db_pass'] ?? '';
            $db_name = $_POST['db_name'] ?? '';
            
            // Validate inputs
            if (empty($db_host) || empty($db_user) || empty($db_name)) {
                $error_message = 'All database fields except password are required';
            } else {
                // Test database connection
                $conn = @new mysqli($db_host, $db_user, $db_pass, $db_name);
                
                if ($conn->connect_error) {
                    $error_message = 'Database connection error: ' . $conn->connect_error;
                    error_log($error_message);
                } else {
                    // Save database configuration to session
                    $installation_progress['db_host'] = $db_host;
                    $installation_progress['db_user'] = $db_user;
                    $installation_progress['db_pass'] = $db_pass;
                    $installation_progress['db_name'] = $db_name;
                    $_SESSION['installation_progress'] = $installation_progress;
                    
                    // Create database tables
                    $create_trades_table = "CREATE TABLE IF NOT EXISTS trades (
                        id INT(11) NOT NULL AUTO_INCREMENT,
                        pair VARCHAR(50) NOT NULL,
                        order_type VARCHAR(20) NOT NULL,
                        status VARCHAR(20) NOT NULL,
                        entry DECIMAL(15,8) DEFAULT NULL,
                        stop_loss DECIMAL(15,8) DEFAULT NULL,
                        take_profit DECIMAL(15,8) DEFAULT NULL,
                        position_size DECIMAL(15,2) DEFAULT NULL,
                        pnl DECIMAL(15,2) NOT NULL DEFAULT 0.00,
                        date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                        image VARCHAR(255) DEFAULT NULL,
                        notes TEXT DEFAULT NULL,
                        market_conditions TEXT DEFAULT NULL,
                        rr DECIMAL(5,2) DEFAULT 0.00,
                        strategy VARCHAR(100) DEFAULT NULL,
                        emotion VARCHAR(50) DEFAULT NULL,
                        confidence_rating INT(1) DEFAULT NULL,
                        lessons_learned TEXT DEFAULT NULL,
                        market_context VARCHAR(50) DEFAULT NULL,
                        PRIMARY KEY (id)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";
                    
                    $create_settings_table = "CREATE TABLE IF NOT EXISTS settings (
                        id INT(11) NOT NULL AUTO_INCREMENT,
                        setting_name VARCHAR(50) NOT NULL,
                        setting_value TEXT NOT NULL,
                        PRIMARY KEY (id),
                        UNIQUE KEY (setting_name)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";
                    
                    if ($conn->query($create_trades_table) !== TRUE) {
                        $error_message = 'Error creating trades table: ' . $conn->error;
                    } elseif ($conn->query($create_settings_table) !== TRUE) {
                        $error_message = 'Error creating settings table: ' . $conn->error;
                    } else {
                        // Proceed to next step
                        header('Location: install.php?step=3');
                        exit;
                    }
                    
                    $conn->close();
                }
            }
            break;
            
        case 3:
            // User account setup
            $username = $_POST['username'] ?? '';
            $password = $_POST['password'] ?? '';
            $password_confirm = $_POST['password_confirm'] ?? '';
            $currency_symbol = $_POST['currency_symbol'] ?? '$';
            $initial_capital = $_POST['initial_capital'] ?? '1000';
            
            // Validate inputs
            if (empty($username) || empty($password) || empty($password_confirm)) {
                $error_message = 'All fields are required';
            } elseif (strlen($password) < 6) {
                $error_message = 'Password must be at least 6 characters long';
            } elseif ($password !== $password_confirm) {
                $error_message = 'Passwords do not match';
            } else {
                // Save user account setup to session
                $installation_progress['username'] = $username;
                $installation_progress['password'] = password_hash($password, PASSWORD_DEFAULT);
                $installation_progress['currency_symbol'] = $currency_symbol;
                $installation_progress['initial_capital'] = $initial_capital;
                $_SESSION['installation_progress'] = $installation_progress;
                
                // Connect to database
                $conn = @new mysqli(
                    $installation_progress['db_host'],
                    $installation_progress['db_user'],
                    $installation_progress['db_pass'],
                    $installation_progress['db_name']
                );
                
                if ($conn->connect_error) {
                    $error_message = 'Database connection error: ' . $conn->connect_error;
                } else {
                    // Insert default settings
                    $stmt = $conn->prepare("INSERT INTO settings (setting_name, setting_value) VALUES (?, ?)");
                    $stmt->bind_param("ss", $name, $value);
                    
                    $name = "initial_capital";
                    $value = $initial_capital;
                    $stmt->execute();
                    
                    $name = "currency_symbol";
                    $value = $currency_symbol;
                    $stmt->execute();
                    
                    // Add default strategies
                    $name = "strategies";
                    $value = "Trend Following,Breakout,Range Trading,Scalping,News Trading,Swing Trading,Position Trading,Mean Reversion,Counter Trend";
                    $stmt->execute();
                    
                    // Add default emotions
                    $name = "emotions";
                    $value = "Calm,Excited,Fearful,Greedy,Impatient,Confident,Nervous,Indecisive,Regretful,Focused";
                    $stmt->execute();
                    
                    // Add default market contexts
                    $name = "market_contexts";
                    $value = "Trending Up,Trending Down,Ranging,Volatile,Choppy,Consolidating,Breakout,News Impact,Low Volume,High Volume";
                    $stmt->execute();
                    
                    $stmt->close();
                    $conn->close();
                    
                    // Create config file
                    $config_content = '<?php
/**
 * Trade Journal Configuration File
 * 
 * This file is generated during the installation process
 * Do not edit manually unless you know what you\'re doing
 */

// Installation status
if (!defined(\'INSTALLED\')) define(\'INSTALLED\', true);

// Database configuration
if (!defined(\'DB_HOST\')) define(\'DB_HOST\', \'' . $installation_progress['db_host'] . '\');
if (!defined(\'DB_USER\')) define(\'DB_USER\', \'' . $installation_progress['db_user'] . '\');
if (!defined(\'DB_PASS\')) define(\'DB_PASS\', \'' . $installation_progress['db_pass'] . '\');
if (!defined(\'DB_NAME\')) define(\'DB_NAME\', \'' . $installation_progress['db_name'] . '\');

// Initial settings
if (!defined(\'CURRENCY_SYMBOL\')) define(\'CURRENCY_SYMBOL\', \'' . $installation_progress['currency_symbol'] . '\');
if (!defined(\'INITIAL_CAPITAL\')) define(\'INITIAL_CAPITAL\', \'' . $installation_progress['initial_capital'] . '\');

// User account
if (!defined(\'USERNAME\')) define(\'USERNAME\', \'' . $installation_progress['username'] . '\');
if (!defined(\'PASSWORD\')) define(\'PASSWORD\', \'' . $installation_progress['password'] . '\');

?>';
                    
                    if (file_put_contents('config.php', $config_content) === false) {
                        $error_message = 'Failed to write configuration file';
                    } else {
                        // Proceed to final step
                        header('Location: install.php?step=4');
                        exit;
                    }
                }
            }
            break;
    }
}

// Get PHP version
$php_version = phpversion();
$php_version_ok = version_compare($php_version, '7.0.0', '>=');

// Check if database extension is loaded
$mysql_ok = extension_loaded('mysqli');

// Check if GD library is available for image processing
$gd_ok = extension_loaded('gd');

// Check if directory is writable
$writable_ok = is_writable(__DIR__);

// All requirements met
$all_requirements_met = $php_version_ok && $mysql_ok && $gd_ok && $writable_ok;

// Page title based on current step
$page_titles = [
    1 => 'System Requirements',
    2 => 'Database Configuration',
    3 => 'User Account Setup',
    4 => 'Installation Complete'
];

$page_title = $page_titles[$current_step] ?? 'Installation';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - Trade Journal Installation</title>
    
    <link rel="icon" type="image/png" href="fav.png">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="themes.css">
    <link rel="stylesheet" href="auth.css">
</head>
<body>
    <div class="auth-container">
        <div class="auth-card">
            <div class="auth-header">
                <div class="logo-container">
                    <svg width="40" height="40" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M2 12.5L7.5 18L22 3.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M2 5.5L7.5 11" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                        <path d="M12 12L22 21.5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                    </svg>
                </div>
                <h1>Trade Journal Installation</h1>
                <p><?php echo $page_title; ?></p>
            </div>
            
            <div class="installation-steps">
                <div class="step <?php echo $current_step >= 1 ? ($current_step > 1 ? 'completed' : 'active') : ''; ?>">
                    <div class="step-number">1</div>
                    <div class="step-label">Requirements</div>
                </div>
                <div class="step <?php echo $current_step >= 2 ? ($current_step > 2 ? 'completed' : 'active') : ''; ?>">
                    <div class="step-number">2</div>
                    <div class="step-label">Database</div>
                </div>
                <div class="step <?php echo $current_step >= 3 ? ($current_step > 3 ? 'completed' : 'active') : ''; ?>">
                    <div class="step-number">3</div>
                    <div class="step-label">Account</div>
                </div>
                <div class="step <?php echo $current_step == 4 ? 'active' : ''; ?>">
                    <div class="step-number">4</div>
                    <div class="step-label">Complete</div>
                </div>
            </div>
            
            <?php if (isset($error_message) && !empty($error_message)): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo htmlspecialchars($error_message); ?>
                </div>
            <?php endif; ?>
            
            <?php if ($current_step == 1): ?>
                <!-- Step 1: System Requirements -->
                <div class="requirements-list">
                    <div class="requirement-item">
                        <div class="requirement-icon <?php echo $php_version_ok ? 'success' : 'error'; ?>">
                            <i class="fas <?php echo $php_version_ok ? 'fa-check' : 'fa-times'; ?>"></i>
                        </div>
                        <div class="requirement-text">
                            <div class="requirement-name">PHP Version</div>
                            <div class="requirement-description">
                                PHP 7.0 or higher is required. Your version: <?php echo $php_version; ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="requirement-item">
                        <div class="requirement-icon <?php echo $mysql_ok ? 'success' : 'error'; ?>">
                            <i class="fas <?php echo $mysql_ok ? 'fa-check' : 'fa-times'; ?>"></i>
                        </div>
                        <div class="requirement-text">
                            <div class="requirement-name">MySQL Extension</div>
                            <div class="requirement-description">
                                MySQL extension (mysqli) is required for database operations
                            </div>
                        </div>
                    </div>
                    
                    <div class="requirement-item">
                        <div class="requirement-icon <?php echo $gd_ok ? 'success' : 'error'; ?>">
                            <i class="fas <?php echo $gd_ok ? 'fa-check' : 'fa-times'; ?>"></i>
                        </div>
                        <div class="requirement-text">
                            <div class="requirement-name">GD Library</div>
                            <div class="requirement-description">
                                GD Library is required for image processing
                            </div>
                        </div>
                    </div>
                    
                    <div class="requirement-item">
                        <div class="requirement-icon <?php echo $writable_ok ? 'success' : 'error'; ?>">
                            <i class="fas <?php echo $writable_ok ? 'fa-check' : 'fa-times'; ?>"></i>
                        </div>
                        <div class="requirement-text">
                            <div class="requirement-name">Directory Permissions</div>
                            <div class="requirement-description">
                                Application directory must be writable
                            </div>
                        </div>
                    </div>
                </div>
                
                <form method="post" action="install.php?step=1">
                    <button type="submit" class="auth-button" <?php echo !$all_requirements_met ? 'disabled' : ''; ?>>
                        <span>Next Step</span>
                        <i class="fas fa-arrow-right"></i>
                    </button>
                </form>
                
                <?php if (!$all_requirements_met): ?>
                    <div class="alert alert-warning mt-3" role="alert">
                        <i class="fas fa-exclamation-triangle"></i> 
                        Please fix the requirements before proceeding with installation.
                    </div>
                <?php endif; ?>
                
            <?php elseif ($current_step == 2): ?>
                <!-- Step 2: Database Configuration -->
                <form method="post" action="install.php?step=2">
                    <div class="form-group">
                        <label for="db_host">Database Host</label>
                        <div class="input-wrapper">
                            <i class="fas fa-server"></i>
                            <input type="text" id="db_host" name="db_host" class="form-control" 
                                value="<?php echo htmlspecialchars($installation_progress['db_host']); ?>"
                                placeholder="localhost" required>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="db_user">Database Username</label>
                            <div class="input-wrapper">
                                <i class="fas fa-user"></i>
                                <input type="text" id="db_user" name="db_user" class="form-control" 
                                    value="<?php echo htmlspecialchars($installation_progress['db_user']); ?>"
                                    placeholder="root" required>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="db_pass">Database Password</label>
                            <div class="input-wrapper">
                                <i class="fas fa-lock"></i>
                                <input type="password" id="db_pass" name="db_pass" class="form-control" 
                                    value="<?php echo htmlspecialchars($installation_progress['db_pass']); ?>"
                                    placeholder="Password">
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="db_name">Database Name</label>
                        <div class="input-wrapper">
                            <i class="fas fa-database"></i>
                            <input type="text" id="db_name" name="db_name" class="form-control" 
                                value="<?php echo htmlspecialchars($installation_progress['db_name']); ?>"
                                placeholder="trade_journal" required>
                        </div>
                    </div>
                    
                    <div class="alert alert-info mt-3" role="alert">
                        <i class="fas fa-info-circle"></i> 
                        The database must exist before installation. Tables will be created automatically.
                    </div>
                    
                    <button type="submit" class="auth-button">
                        <span>Next Step</span>
                        <i class="fas fa-arrow-right"></i>
                    </button>
                </form>
                
            <?php elseif ($current_step == 3): ?>
                <!-- Step 3: User Account Setup -->
                <form method="post" action="install.php?step=3">
                    <div class="form-group">
                        <label for="username">Admin Username</label>
                        <div class="input-wrapper">
                            <i class="fas fa-user"></i>
                            <input type="text" id="username" name="username" class="form-control" 
                                value="<?php echo htmlspecialchars($installation_progress['username']); ?>"
                                placeholder="admin" required>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="password">Password</label>
                            <div class="input-wrapper">
                                <i class="fas fa-lock"></i>
                                <input type="password" id="password" name="password" class="form-control" 
                                    placeholder="Password" required minlength="6">
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="password_confirm">Confirm Password</label>
                            <div class="input-wrapper">
                                <i class="fas fa-lock"></i>
                                <input type="password" id="password_confirm" name="password_confirm" class="form-control" 
                                    placeholder="Confirm password" required minlength="6">
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="currency_symbol">Currency Symbol</label>
                            <div class="input-wrapper">
                                <i class="fas fa-dollar-sign"></i>
                                <input type="text" id="currency_symbol" name="currency_symbol" class="form-control" 
                                    value="<?php echo htmlspecialchars($installation_progress['currency_symbol']); ?>"
                                    placeholder="$" required maxlength="3">
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="initial_capital">Initial Capital</label>
                            <div class="input-wrapper">
                                <i class="fas fa-wallet"></i>
                                <input type="number" id="initial_capital" name="initial_capital" class="form-control" 
                                    value="<?php echo htmlspecialchars($installation_progress['initial_capital']); ?>"
                                    placeholder="30.00" step="0.01" min="0" required>
                            </div>
                        </div>
                    </div>
                    
                    <button type="submit" class="auth-button">
                        <span>Complete Installation</span>
                        <i class="fas fa-arrow-right"></i>
                    </button>
                </form>
                
            <?php elseif ($current_step == 4): ?>
                <!-- Step 4: Installation Complete -->
                <div class="success-message">
                    <i class="fas fa-check-circle success-icon"></i>
                    <h2>Installation Complete!</h2>
                    <p>Your Trade Journal has been successfully installed and is ready to use.</p>
                </div>
                
                <a href="login.php" class="auth-button">
                    <span>Login to Your Journal</span>
                    <i class="fas fa-arrow-right"></i>
                </a>
                
                <?php
                // Clear installation session data
                unset($_SESSION['installation_progress']);
                ?>
                
            <?php endif; ?>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>