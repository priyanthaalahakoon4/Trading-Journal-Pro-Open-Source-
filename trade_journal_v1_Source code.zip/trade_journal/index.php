<?php
// Prevent any output before headers are sent
ob_start();

include('auth.php');

// Check if the application is installed
require_installation();

// Check if user is logged in
require_login();

// Include database connection after authentication checks
include('db_connect.php');

// Ensure we have a valid database connection
$conn = ensure_db_connection();

// Get wallet information
$start_wallet = get_initial_capital();
$current_wallet = get_wallet_balance();
$currency_symbol = get_currency_symbol();

// Initialize statistics
$total_pnl = 0;
$total_win = 0;
$total_loss = 0;
$total_trades = 0;
$positive_trades = 0;
$trades_data = [];

// Get all trades ordered by date (most recent first)
$sql = "SELECT id, pair, pnl, order_type, status, image, 
        entry, stop_loss, take_profit, position_size, 
        DATE_FORMAT(date, '%Y-%m-%d') as formatted_date 
        FROM trades ORDER BY date DESC";
$result = $conn->query($sql);

if ($result) {
    if ($result->num_rows > 0) {
        while ($trade = $result->fetch_assoc()) {
            $trades_data[] = $trade;
            $pnl = floatval($trade['pnl']);

            $total_pnl += $pnl;
            $total_trades++;

            if ($pnl > 0) {
                $total_win += $pnl;
                $positive_trades++;
            } elseif ($pnl < 0) {
                $total_loss += $pnl;
            }
        }
    }
}

// Calculate win rate
$win_rate = ($total_trades > 0) ? number_format(($positive_trades / $total_trades) * 100, 1) : 0;

// Handle trade deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_trade'])) {
    if (isset($_POST['trade_id']) && filter_var($_POST['trade_id'], FILTER_VALIDATE_INT)) {
        $trade_id = $_POST['trade_id'];
        $delete_sql = "DELETE FROM trades WHERE id = ?";
        $stmt = $conn->prepare($delete_sql);

        if ($stmt) {
            $stmt->bind_param("i", $trade_id);
            $stmt->execute();
            $stmt->close();
            
            // Redirect to refresh the page after deletion
            header("Location: " . $_SERVER['PHP_SELF']);
            exit;
        }
    }
}

// Format numbers with currency symbol
function format_money($amount) {
    global $currency_symbol;
    return $currency_symbol . number_format($amount, 2);
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trade Journal - Dashboard</title>

    <link rel="icon" type="image/png" href="fav.png">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="themes.css">

    <style>
        /* These variables are now defined in themes.css */

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        body {
            background-color: var(--bg-primary);
            color: var(--text-primary);
            font-family: var(--font-family);
            line-height: 1.6;
        }

        .navbar {
            background-color: var(--bg-secondary);
            border-bottom: 1px solid var(--border-color);
            padding: 0.8rem 0;
            animation: fadeInUp 0.5s ease-out;
        }

        .navbar-brand {
            font-weight: 700;
            font-size: 1.4rem;
            color: var(--neon-cyan);
            text-shadow: 0 0 5px var(--glow-color-cyan);
            display: inline-flex; /* Align SVG and text */
            align-items: center;
        }
        .navbar-brand:hover { color: var(--neon-cyan); opacity: 0.9; }

        .navbar-brand svg {
             width: 28px;
             height: 28px;
             margin-right: 8px;
             vertical-align: -0.15em; /* Fine-tune vertical alignment */
        }

        .nav-button {
            color: var(--neon-cyan);
            border: 1px solid var(--neon-cyan);
            background-color: transparent;
            padding: 0.4rem 0.9rem;
            border-radius: var(--border-radius);
            font-weight: 500;
            font-size: 0.9rem;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 0.4rem;
            text-decoration: none;
            margin-left: 0.5rem;
        }
        .nav-button:hover {
            background-color: rgba(0, 255, 255, 0.1);
            box-shadow: 0 0 10px var(--glow-color-cyan);
            color: var(--text-primary);
        }
        .nav-button.primary {
             background-color: var(--neon-cyan);
             color: var(--bg-primary);
             font-weight: 600;
        }
        .nav-button.primary:hover {
              background-color: #00e0e0;
             box-shadow: 0 0 15px var(--glow-color-cyan);
              color: var(--bg-primary);
        }

        .dashboard-title {
            color: var(--text-primary);
            font-weight: 800;
            margin-bottom: 3rem;
            text-align: center;
            font-size: 2.5rem;
            letter-spacing: -1px;
            animation: fadeInUp 0.6s ease-out;
        }

        .metric-card {
            background-color: var(--bg-secondary);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: 1.75rem;
            text-align: center;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
            animation: fadeInUp 0.7s ease-out forwards;
            opacity: 0;
        }
        .row > div:nth-child(1) .metric-card { animation-delay: 0.1s; }
        .row > div:nth-child(2) .metric-card { animation-delay: 0.2s; }
        .row > div:nth-child(3) .metric-card { animation-delay: 0.3s; }
        .row > div:nth-child(4) .metric-card { animation-delay: 0.4s; }

        .metric-card:hover {
            transform: translateY(-5px) scale(1.02);
            box-shadow: 0 0 20px var(--glow-color-cyan);
            border-color: var(--neon-cyan);
        }

        .metric-icon {
            font-size: 2.2rem;
            margin-bottom: 1.25rem;
            color: var(--neon-cyan);
            text-shadow: 0 0 8px var(--glow-color-cyan);
        }
        .metric-icon.profit { color: var(--neon-green); text-shadow: 0 0 8px var(--glow-color-green); }
        .metric-icon.loss { color: var(--neon-red); text-shadow: 0 0 8px var(--glow-color-red); }
        .metric-icon.winrate { color: var(--neon-yellow); text-shadow: 0 0 8px rgba(245, 245, 66, 0.4);}

        .metric-value {
            font-size: 2.2rem;
            font-weight: 700;
            color: var(--text-primary);
            line-height: 1.1;
            margin-bottom: 0.5rem;
        }
        .metric-value.profit { color: var(--neon-green); }
        .metric-value.loss { color: var(--neon-red); }

        .metric-label {
            font-size: 0.9rem;
            color: var(--text-secondary);
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 0.8px;
        }

        .trade-card {
            background-color: var(--bg-secondary);
            border: 1px solid var(--border-color);
            border-radius: 16px; /* Increased rounding */
            overflow: visible;
            transition: all 0.3s ease;
            margin-bottom: 1.5rem;
            position: relative;
            display: flex;
            flex-direction: column;
            animation: fadeInUp 0.5s ease-out forwards;
            opacity: 0;
        }
        .trades-grid > .grid-item:nth-child(odd) .trade-card { animation-delay: 0.5s; }
        .trades-grid > .grid-item:nth-child(even) .trade-card { animation-delay: 0.6s; }

        .trade-card::before {
            content: '';
            position: absolute;
            left: 0;
            top: 0;
            bottom: 0;
            width: 5px;
            background-color: var(--border-color);
            transition: background-color 0.3s ease;
            border-radius: 16px 0 0 16px; /* Match increased rounding */
        }
        .trade-card.profit::before { background-color: var(--neon-green); }
        .trade-card.loss::before { background-color: var(--neon-red); }

        .trade-card-link-wrapper {
            text-decoration: none;
            color: inherit;
            display: block;
            padding: 1.5rem;
            transition: background-color 0.2s ease;
        }
         .trade-card-link-wrapper:hover {
             background-color: rgba(0, 255, 255, 0.03);
         }

        .trade-card:hover {
            transform: translateY(-5px);
            border-color: var(--neon-cyan);
            box-shadow: 0 0 15px var(--glow-color-cyan);
        }
        .trade-card.profit:hover { border-color: var(--neon-green); box-shadow: 0 0 15px var(--glow-color-green); }
        .trade-card.loss:hover { border-color: var(--neon-red); box-shadow: 0 0 15px var(--glow-color-red); }

        .trade-image-container {
            position: relative;
            width: 100%;
            height: 240px; /* Increased height */
            overflow: hidden;
            border-top-left-radius: 16px; /* Match increased rounding */
            border-top-right-radius: 16px;
            border-bottom-left-radius: 0;
            border-bottom-right-radius: 0;
        }

        .trade-image {
            width: 100%;
            height: 100%;
            object-fit: cover;
            opacity: 0.85;
            transition: opacity 0.4s ease, transform 0.4s ease, filter 0.4s ease;
            filter: grayscale(20%) contrast(110%);
            border-bottom: 1px solid var(--border-color);
        }
        .trade-card:hover .trade-image {
            opacity: 1;
            filter: grayscale(0%) contrast(100%);
            transform: scale(1.05);
        }

        .view-image-btn {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%) scale(0.8);
            background-color: rgba(10, 12, 16, 0.7);
            color: var(--neon-cyan);
            border: 1px solid var(--neon-cyan);
            border-radius: 50%;
            width: 50px;
            height: 50px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.2rem;
            cursor: pointer;
            opacity: 0;
            pointer-events: none;
            transition: all 0.3s ease;
            backdrop-filter: blur(3px);
        }
        .trade-image-container:hover .view-image-btn {
            opacity: 1;
            pointer-events: auto;
            transform: translate(-50%, -50%) scale(1);
        }
         .view-image-btn:hover {
             background-color: rgba(0, 255, 255, 0.2);
             box-shadow: 0 0 10px var(--glow-color-cyan);
         }

        .trade-content {
            padding: 0 1.5rem 1.5rem 1.5rem;
        }

        .trade-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
            padding-bottom: 0.75rem;
            border-bottom: 1px solid rgba(0, 255, 255, 0.1);
        }

        .trade-status {
            font-size: 0.75rem;
            font-weight: 600;
            padding: 0.3rem 0.8rem;
            border-radius: 50px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            border: 1px solid;
        }
        .status-open { color: var(--neon-yellow); border-color: var(--neon-yellow); background-color: rgba(245, 245, 66, 0.1); }
        .status-limit { color: var(--neon-cyan); border-color: var(--neon-cyan); background-color: rgba(0, 255, 255, 0.1); }
        .status-closed { color: var(--text-secondary); border-color: var(--text-secondary); background-color: rgba(136, 153, 168, 0.1); }

        .trade-pair {
            font-weight: 700;
            font-size: 1.5rem;
            color: var(--text-primary);
            margin-bottom: 0.25rem;
        }

        .trade-date {
            font-size: 0.9rem;
            color: var(--text-secondary);
        }

        .trade-pnl {
            font-weight: 700;
            font-size: 1.25rem;
            margin-top: 0.5rem;
        }
        .trade-pnl.profit { color: var(--neon-green); }
        .trade-pnl.loss { color: var(--neon-red); }

        .trade-details {
            display: flex;
            justify-content: space-between;
            margin-top: 1rem;
            font-size: 0.9rem;
        }
        .trade-detail-item {
            display: flex;
            flex-direction: column;
        }
        .trade-detail-label {
            color: var(--text-secondary);
            font-size: 0.75rem;
            margin-bottom: 0.25rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .trade-detail-value {
            color: var(--text-primary);
            font-weight: 500;
        }

        .trade-actions {
            display: flex;
            justify-content: flex-end;
            align-items: center;
            gap: 0.5rem;
            margin-top: 1rem;
        }

        .btn-trade-action {
            border: none;
            background: none;
            color: var(--text-secondary);
            font-size: 0.9rem;
            padding: 0.3rem 0.5rem;
            border-radius: var(--border-radius);
            transition: all 0.2s ease;
        }
        .btn-trade-action:hover {
            background-color: rgba(0, 255, 255, 0.1);
            color: var(--neon-cyan);
        }
        .btn-trade-action.delete:hover {
            background-color: rgba(255, 51, 102, 0.1);
            color: var(--neon-red);
        }

        .section-title {
            font-weight: 700;
            color: var(--text-primary);
            margin: 3rem 0 1.5rem 0;
            font-size: 1.8rem;
            position: relative;
            display: inline-block;
        }
        .section-title::after {
            content: '';
            position: absolute;
            bottom: -0.5rem;
            left: 0;
            width: 3rem;
            height: 0.2rem;
            background-color: var(--neon-cyan);
            border-radius: 2px;
            box-shadow: 0 0 10px var(--glow-color-cyan);
        }

        .empty-state {
            background-color: var(--bg-secondary);
            border: 1px dashed var(--border-color);
            border-radius: var(--border-radius);
            padding: 3rem 1rem;
            text-align: center;
            margin-top: 1rem;
        }
        .empty-state-icon {
            font-size: 3rem;
            color: var(--text-secondary);
            margin-bottom: 1rem;
            opacity: 0.6;
        }
        .empty-state-text {
            color: var(--text-secondary);
            font-size: 1.1rem;
            margin-bottom: 1.5rem;
        }

        .action-buttons {
            display: flex;
            justify-content: center;
            gap: 1.5rem;
            margin-top: 2rem;
            flex-wrap: wrap;
        }
        
        .action-button {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-decoration: none;
            background-color: var(--bg-secondary);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: 1.5rem;
            width: 180px;
            transition: all 0.3s ease;
            cursor: pointer;
            position: relative;
            overflow: hidden;
        }
        
        .action-button::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(
                90deg, 
                transparent, 
                rgba(0, 255, 255, 0.1), 
                transparent
            );
            transition: left 0.7s ease;
            z-index: 1;
        }
        
        .action-button:hover {
            transform: translateY(-5px);
            border-color: var(--neon-cyan);
            box-shadow: 0 0 15px var(--glow-color-cyan);
        }
        
        .action-button:hover::before {
            left: 100%;
        }
        
        .action-icon {
            font-size: 2rem;
            color: var(--neon-cyan);
            margin-bottom: 1rem;
        }
        
        .action-text {
            color: var(--text-primary);
            font-weight: 600;
            text-align: center;
        }

        /* Modal styling */
        .modal-content {
            background-color: var(--bg-secondary);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
        }
        .modal-header {
            border-bottom: 1px solid var(--border-color);
        }
        .modal-title {
            color: var(--text-primary);
            font-weight: 600;
        }
        .modal-body {
            color: var(--text-primary);
        }
        .modal-footer {
            border-top: 1px solid var(--border-color);
        }
        .btn-close {
            color: var(--text-primary);
            filter: invert(1);
        }
        
        /* Responsive adjustments */
        @media (max-width: 767.98px) {
            .action-buttons {
                gap: 1rem;
            }
            .action-button {
                width: 140px;
                padding: 1rem;
            }
        }
        
        /* Wallet balance card with gradient background */
        .wallet-card {
            background: linear-gradient(135deg, #162431 0%, #1E293B 100%);
            border-radius: var(--border-radius);
            padding: 2rem;
            border: 1px solid var(--border-color);
            margin-bottom: 2rem;
            position: relative;
            overflow: hidden;
            animation: fadeInUp 0.7s ease-out forwards;
        }
        
        .wallet-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: radial-gradient(circle at 30% 30%, rgba(0, 255, 255, 0.1) 0%, transparent 70%);
            pointer-events: none;
        }
        
        .wallet-label {
            font-size: 1rem;
            color: var(--text-secondary);
            margin-bottom: 0.5rem;
            text-transform: uppercase;
            letter-spacing: 1px;
            font-weight: 500;
        }
        
        .wallet-balance {
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 0;
            position: relative;
        }
        
        .wallet-currency {
            font-size: 1rem;
            color: var(--text-secondary);
            font-weight: 400;
            margin-left: 0.25rem;
        }
        
        .wallet-action {
            position: absolute;
            right: 1.5rem;
            top: 50%;
            transform: translateY(-50%);
            color: var(--neon-cyan);
            font-size: 1.5rem;
            transition: all 0.3s ease;
        }
        
        .wallet-action:hover {
            color: var(--text-primary);
        }
    </style>
</head>
<body>
    <?php 
    $current_page = basename($_SERVER['PHP_SELF']);
    include('navigation.php'); 
    ?>

    <div class="container mt-5">
        <!-- Wallet Balance Card -->
        <div class="wallet-card">
            <div class="wallet-label">Current Wallet Balance</div>
            <h2 class="wallet-balance">
                <?= format_money($current_wallet) ?>
                <span class="wallet-currency">USD</span>
                <a href="wallet_chart.php" class="wallet-action">
                    <i class="fas fa-chart-line"></i>
                </a>
            </h2>
        </div>

        <!-- Dashboard Title -->
        <h1 class="dashboard-title">Trading Dashboard</h1>

        <!-- Key Metrics -->
        <div class="row mb-5">
            <div class="col-md-3 col-sm-6 mb-4">
                <div class="metric-card">
                    <div class="metric-icon">
                        <i class="fas fa-exchange-alt"></i>
                    </div>
                    <div class="metric-value"><?= $total_trades ?></div>
                    <div class="metric-label">Total Trades</div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 mb-4">
                <div class="metric-card">
                    <div class="metric-icon profit">
                        <i class="fas fa-arrow-trend-up"></i>
                    </div>
                    <div class="metric-value profit"><?= format_money($total_win) ?></div>
                    <div class="metric-label">Total Profits</div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 mb-4">
                <div class="metric-card">
                    <div class="metric-icon loss">
                        <i class="fas fa-arrow-trend-down"></i>
                    </div>
                    <div class="metric-value loss"><?= format_money($total_loss) ?></div>
                    <div class="metric-label">Total Losses</div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 mb-4">
                <div class="metric-card">
                    <div class="metric-icon winrate">
                        <i class="fas fa-chart-pie"></i>
                    </div>
                    <div class="metric-value"><?= $win_rate ?>%</div>
                    <div class="metric-label">Win Rate</div>
                </div>
            </div>
        </div>

        <!-- Recent Trades Section -->
        <h2 class="section-title">Recent Trades</h2>

        <?php if (empty($trades_data)): ?>
            <div class="empty-state">
                <div class="empty-state-icon">
                    <i class="fas fa-chart-line"></i>
                </div>
                <div class="empty-state-text">
                    You haven't logged any trades yet. Start by adding your first trade.
                </div>
                <a href="add_trade.php" class="nav-button primary">
                    <i class="fas fa-plus me-2"></i>Add First Trade
                </a>
            </div>
        <?php else: ?>
            <div class="row trades-grid">
                <?php foreach ($trades_data as $trade): 
                    $pnl = floatval($trade['pnl']);
                    $pnl_class = ($pnl > 0) ? 'profit' : (($pnl < 0) ? 'loss' : '');
                    
                    // Determine status class
                    $status_class = 'status-closed';
                    $trade_status = strtolower($trade['status']);
                    if (strpos($trade_status, 'open') !== false) {
                        $status_class = 'status-open';
                    } elseif (strpos($trade_status, 'limit') !== false) {
                        $status_class = 'status-limit';
                    }
                ?>
                <div class="col-lg-6 grid-item mb-4">
                    <div class="trade-card <?= $pnl_class ?>">
                        <?php if (!empty($trade['image'])): ?>
                        <div class="trade-image-container">
                            <img src="<?= htmlspecialchars($trade['image']) ?>" class="trade-image" alt="<?= htmlspecialchars($trade['pair']) ?> chart">
                            <a href="trade_details.php?id=<?= $trade['id'] ?>" class="view-image-btn">
                                <i class="fas fa-search"></i>
                            </a>
                        </div>
                        <?php endif; ?>
                        
                        <a href="trade_details.php?id=<?= $trade['id'] ?>" class="trade-card-link-wrapper">
                            <div class="trade-header">
                                <div>
                                    <div class="trade-pair"><?= htmlspecialchars($trade['pair']) ?></div>
                                    <div class="trade-date"><?= htmlspecialchars($trade['formatted_date']) ?></div>
                                </div>
                                <div class="trade-status <?= $status_class ?>"><?= htmlspecialchars($trade['status']) ?></div>
                            </div>
                            
                            <div class="trade-content">
                                <div class="trade-pnl <?= $pnl_class ?>"><?= format_money($pnl) ?></div>
                                
                                <div class="trade-details">
                                    <div class="trade-detail-item">
                                        <div class="trade-detail-label">Type</div>
                                        <div class="trade-detail-value"><?= htmlspecialchars($trade['order_type']) ?></div>
                                    </div>
                                    
                                    <?php if (!empty($trade['entry'])): ?>
                                    <div class="trade-detail-item">
                                        <div class="trade-detail-label">Entry</div>
                                        <div class="trade-detail-value"><?= htmlspecialchars($trade['entry']) ?></div>
                                    </div>
                                    <?php endif; ?>
                                    
                                    <?php if (!empty($trade['stop_loss'])): ?>
                                    <div class="trade-detail-item">
                                        <div class="trade-detail-label">SL</div>
                                        <div class="trade-detail-value"><?= htmlspecialchars($trade['stop_loss']) ?></div>
                                    </div>
                                    <?php endif; ?>
                                    
                                    <?php if (!empty($trade['take_profit'])): ?>
                                    <div class="trade-detail-item">
                                        <div class="trade-detail-label">TP</div>
                                        <div class="trade-detail-value"><?= htmlspecialchars($trade['take_profit']) ?></div>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </a>
                        
                        <div class="trade-actions">
                            <a href="edit_trade.php?id=<?= $trade['id'] ?>" class="btn-trade-action">
                                <i class="fas fa-edit"></i> Edit
                            </a>
                            <button class="btn-trade-action delete" data-bs-toggle="modal" data-bs-target="#deleteTrade<?= $trade['id'] ?>">
                                <i class="fas fa-trash"></i> Delete
                            </button>
                        </div>
                    </div>
                </div>
                
                <!-- Delete Confirmation Modal -->
                <div class="modal fade" id="deleteTrade<?= $trade['id'] ?>" tabindex="-1" aria-labelledby="deleteTradeLabel<?= $trade['id'] ?>" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="deleteTradeLabel<?= $trade['id'] ?>">Confirm Delete</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                Are you sure you want to delete the trade for <?= htmlspecialchars($trade['pair']) ?> from <?= htmlspecialchars($trade['formatted_date']) ?>?
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="nav-button" data-bs-dismiss="modal">Cancel</button>
                                <form method="post">
                                    <input type="hidden" name="trade_id" value="<?= $trade['id'] ?>">
                                    <button type="submit" name="delete_trade" class="nav-button" style="color: var(--neon-red); border-color: var(--neon-red);">Delete</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            
            <?php if (count($trades_data) > 10): ?>
                <div class="text-center mt-4 mb-5">
                    <a href="analysis.php" class="nav-button">
                        View All Trades <i class="fas fa-arrow-right ms-2"></i>
                    </a>
                </div>
            <?php endif; ?>
        <?php endif; ?>
        

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script src="js/main.js"></script>
    <script src="js/theme-switcher.js"></script>
</body>
</html>
