<?php
include_once 'auth.php';

// Define test credentials
$test_username = 'admin';  // From config.php
$test_password = 'test';  // Try simple password

// Test authentication
$result = authenticate($test_username, $test_password);

echo "Authentication test:\n";
echo "Username: $test_username\n";
echo "Result: " . ($result ? "SUCCESS" : "FAILED") . "\n";

// Test password verification directly
$stored_hash = '$2y$10$xa8IPq1J6IYXQ6ZoEmqSo.yFMs39ZDhPXeizzCkZCW1RJ98hDm9Yu'; // Password 'test'
$passwords_to_test = ['test', 'admin', 'password', '123456'];

echo "\nPassword verification tests:\n";
foreach ($passwords_to_test as $pwd) {
    $verify_result = password_verify($pwd, $stored_hash);
    echo "Password '$pwd': " . ($verify_result ? "MATCH" : "NO MATCH") . "\n";
}
?>