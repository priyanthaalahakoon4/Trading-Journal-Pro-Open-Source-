<?php
// Include database connection
require_once 'db_connect.php';

// Ensure we have a connection
$conn = ensure_db_connection();

if ($conn) {
    // Update initial capital to 1000
    if (update_setting('initial_capital', '1000')) {
        echo "Successfully restored initial capital to 1000\n";
    } else {
        echo "Failed to restore initial capital\n";
    }
} else {
    echo "No database connection available\n";
}
?>