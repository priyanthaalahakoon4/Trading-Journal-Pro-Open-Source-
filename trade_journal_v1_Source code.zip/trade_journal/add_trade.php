<?php
include('db_connect.php');

// Ensure we have a valid database connection
$conn = ensure_db_connection();

// Get wallet balance for reference
$wallet_balance = get_wallet_balance();
$currency_symbol = get_currency_symbol();

// Initialize variables
$error_message = '';
$success_message = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate and sanitize inputs
    $pair = sanitize_input($_POST['pair'] ?? '');
    $order_type = sanitize_input($_POST['order_type'] ?? '');
    $status = sanitize_input($_POST['status'] ?? '');
    $entry = !empty($_POST['entry']) ? floatval($_POST['entry']) : null;
    $stop_loss = !empty($_POST['stop_loss']) ? floatval($_POST['stop_loss']) : null;
    $take_profit = !empty($_POST['take_profit']) ? floatval($_POST['take_profit']) : null;
    $position_size = !empty($_POST['position_size']) ? floatval($_POST['position_size']) : null;
    $pnl = !empty($_POST['pnl']) ? floatval($_POST['pnl']) : 0;
    $notes = sanitize_input($_POST['notes'] ?? '');
    $market_conditions = sanitize_input($_POST['market_conditions'] ?? '');
    $date = !empty($_POST['date']) ? sanitize_input($_POST['date']) : date('Y-m-d');
    
    // Phase 1 new fields
    $strategy = sanitize_input($_POST['strategy'] ?? '');
    $emotion = sanitize_input($_POST['emotion'] ?? '');
    $confidence_rating = !empty($_POST['confidence_rating']) ? intval($_POST['confidence_rating']) : null;
    $lessons_learned = sanitize_input($_POST['lessons_learned'] ?? '');
    $market_context = sanitize_input($_POST['market_context'] ?? '');
    
    // Validation
    if (empty($pair)) {
        $error_message = "Trading pair is required";
    } elseif (empty($order_type)) {
        $error_message = "Order type is required";
    } elseif (empty($status)) {
        $error_message = "Trade status is required";
    } else {
        // Image upload handling
        $image_path = null;
        
        if (isset($_FILES['chart_image']) && $_FILES['chart_image']['error'] === UPLOAD_ERR_OK) {
            $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
            $file_type = $_FILES['chart_image']['type'];
            
            if (!in_array($file_type, $allowed_types)) {
                $error_message = "Invalid file type. Only JPG, PNG, GIF, and WEBP are allowed.";
            } else {
                // Create uploads directory if it doesn't exist
                if (!file_exists('uploads')) {
                    mkdir('uploads', 0755);
                }
                
                // Generate unique filename
                $file_extension = pathinfo($_FILES['chart_image']['name'], PATHINFO_EXTENSION);
                $new_filename = uniqid('trade_') . '.' . $file_extension;
                $upload_path = 'uploads/' . $new_filename;
                
                if (move_uploaded_file($_FILES['chart_image']['tmp_name'], $upload_path)) {
                    $image_path = $upload_path;
                } else {
                    $error_message = "Failed to upload image. Please try again.";
                }
            }
        }
        
        // If no errors, insert into database
        if (empty($error_message)) {
           // Corrected prepared statement and binding
$sql = "INSERT INTO trades 
    (pair, order_type, status, entry, stop_loss, take_profit, position_size, pnl, date, image, notes, market_conditions, strategy, emotion, confidence_rating, lessons_learned, market_context) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);

if ($stmt) {
    // Note: There was a typo in your variable name ($strategy vs $strategy)
    $stmt->bind_param(
        "sssdddddsssssiiss", // 17 type specifiers
        $pair, 
        $order_type, 
        $status, 
        $entry, 
        $stop_loss, 
        $take_profit, 
        $position_size, 
        $pnl, 
        $date, 
        $image_path, 
        $notes, 
        $market_conditions,
        $strategy,  // Fixed variable name (was $strategy in some places)
        $emotion,
        $confidence_rating,
        $lessons_learned,
        $market_context
    );
                
                if ($stmt->execute()) {
                    $success_message = "Trade added successfully!";
                    // Clear form data on success
                    $_POST = array();
                } else {
                    $error_message = "Error adding trade: " . $stmt->error;
                }
                $stmt->close();
            } else {
                $error_message = "Database error: " . $conn->error;
            }
        }
    }
}

// Get current date for default value
$current_date = date('Y-m-d');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Trade - Trade Journal</title>
    <link rel="icon" type="image/png" href="fav.png">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="themes.css">

    <style>
        /* These variables are now defined in themes.css */

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        body {
            background-color: var(--bg-primary);
            color: var(--text-primary);
            font-family: var(--font-family);
            line-height: 1.6;
        }

        .navbar {
            background-color: var(--bg-secondary);
            border-bottom: 1px solid var(--border-color);
            padding: 0.8rem 0;
        }

        .navbar-brand {
            font-weight: 700;
            font-size: 1.4rem;
            color: var(--neon-cyan);
            text-shadow: 0 0 5px var(--glow-color-cyan);
            display: inline-flex;
            align-items: center;
        }
        .navbar-brand:hover { color: var(--neon-cyan); opacity: 0.9; }

        .navbar-brand svg {
             width: 28px;
             height: 28px;
             margin-right: 8px;
             vertical-align: -0.15em;
        }

        .nav-button {
            color: var(--neon-cyan);
            border: 1px solid var(--neon-cyan);
            background-color: transparent;
            padding: 0.4rem 0.9rem;
            border-radius: var(--border-radius);
            font-weight: 500;
            font-size: 0.9rem;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 0.4rem;
            text-decoration: none;
            margin-left: 0.5rem;
        }
        .nav-button:hover {
            background-color: rgba(0, 255, 255, 0.1);
            box-shadow: 0 0 10px var(--glow-color-cyan);
            color: var(--text-primary);
        }
        .nav-button.primary {
             background-color: var(--neon-cyan);
             color: var(--bg-primary);
             font-weight: 600;
        }
        .nav-button.primary:hover {
              background-color: #00e0e0;
             box-shadow: 0 0 15px var(--glow-color-cyan);
              color: var(--bg-primary);
        }

        .page-title {
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 2rem;
            position: relative;
            display: inline-block;
            animation: fadeInUp 0.6s ease-out;
        }
        
        .page-title::after {
            content: '';
            position: absolute;
            bottom: -0.5rem;
            left: 0;
            width: 3rem;
            height: 0.2rem;
            background-color: var(--neon-cyan);
            border-radius: 2px;
            box-shadow: 0 0 10px var(--glow-color-cyan);
        }

        .form-card {
            background-color: var(--bg-secondary);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: 2rem;
            margin-bottom: 2rem;
            animation: fadeInUp 0.7s ease-out;
        }

        .form-label {
            color: var(--text-primary);
            font-weight: 600;
            margin-bottom: 0.5rem;
        }

        .form-text {
            color: var(--text-secondary);
            font-size: 0.85rem;
        }

        .form-control {
            background-color: rgba(10, 12, 16, 0.5);
            border: 1px solid var(--border-color);
            color: var(--text-primary);
            border-radius: var(--border-radius);
            padding: 0.75rem 1rem;
            transition: all 0.2s ease;
        }

        .form-control:focus {
            background-color: rgba(10, 12, 16, 0.7);
            border-color: var(--neon-cyan);
            box-shadow: 0 0 0 0.25rem rgba(0, 255, 255, 0.2);
            color: var(--text-primary);
        }

        .form-select {
            background-color: rgba(10, 12, 16, 0.5);
            border: 1px solid var(--border-color);
            color: var(--text-primary);
            border-radius: var(--border-radius);
            padding: 0.75rem 1rem;
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='%2300ffff' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='m2 5 6 6 6-6'/%3e%3c/svg%3e");
        }

        .form-select:focus {
            background-color: rgba(10, 12, 16, 0.7);
            border-color: var(--neon-cyan);
            box-shadow: 0 0 0 0.25rem rgba(0, 255, 255, 0.2);
            color: var(--text-primary);
        }

        .form-check-input {
            background-color: rgba(10, 12, 16, 0.5);
            border: 1px solid var(--border-color);
        }

        .form-check-input:checked {
            background-color: var(--neon-cyan);
            border-color: var(--neon-cyan);
        }

        .form-check-input:focus {
            border-color: var(--neon-cyan);
            box-shadow: 0 0 0 0.25rem rgba(0, 255, 255, 0.2);
        }

        .form-check-label {
            color: var(--text-primary);
        }

        .section-heading {
            font-size: 1.1rem;
            color: var(--neon-cyan);
            margin-bottom: 1.5rem;
            padding-bottom: 0.5rem;
            border-bottom: 1px solid var(--border-color);
        }

        /* Alert styling */
        .alert {
            border-radius: var(--border-radius);
            padding: 1rem;
            margin-bottom: 1.5rem;
            border: 1px solid transparent;
        }

        .alert-success {
            background-color: rgba(0, 255, 127, 0.1);
            border-color: var(--neon-green);
            color: var(--neon-green);
        }

        .alert-danger {
            background-color: rgba(255, 51, 102, 0.1);
            border-color: var(--neon-red);
            color: var(--neon-red);
        }

        /* File input styling */
        .file-input-container {
            position: relative;
            margin-bottom: 1rem;
        }

        .file-input-label {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            border: 2px dashed var(--border-color);
            border-radius: var(--border-radius);
            padding: 2rem;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
            background-color: rgba(10, 12, 16, 0.3);
        }

        .file-input-label:hover {
            border-color: var(--neon-cyan);
            background-color: rgba(0, 255, 255, 0.05);
        }

        .file-input-icon {
            font-size: 2.5rem;
            color: var(--text-secondary);
            margin-bottom: 1rem;
        }

        .file-input-text {
            color: var(--text-primary);
            font-weight: 500;
            margin-bottom: 0.25rem;
        }

        .file-input-help {
            color: var(--text-secondary);
            font-size: 0.85rem;
        }

        .file-input {
            position: absolute;
            width: 0.1px;
            height: 0.1px;
            opacity: 0;
            overflow: hidden;
            z-index: -1;
        }

        #file-name {
            margin-top: 0.5rem;
            font-size: 0.9rem;
            color: var(--neon-cyan);
        }

        /* Preview image */
        .preview-container {
            width: 100%;
            margin-top: 1rem;
            display: none;
            position: relative;
        }

        .preview-image {
            max-width: 100%;
            max-height: 300px;
            border-radius: var(--border-radius);
            border: 1px solid var(--border-color);
        }
        
        .preview-delete-btn {
            position: absolute;
            top: 10px;
            right: 10px;
            background-color: rgba(10, 12, 16, 0.7);
            color: var(--neon-red);
            border: 1px solid var(--neon-red);
            border-radius: 50%;
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.9rem;
            cursor: pointer;
            opacity: 0.8;
            transition: all 0.2s ease;
            z-index: 10;
        }
        
        .preview-delete-btn:hover {
            opacity: 1;
            transform: scale(1.1);
            background-color: rgba(255, 51, 102, 0.2);
            box-shadow: 0 0 10px var(--glow-color-red);
        }

        /* Wallet info display */
        .wallet-info {
            background-color: rgba(10, 12, 16, 0.5);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: 1rem;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .wallet-balance {
            font-weight: 600;
            color: var(--neon-cyan);
        }

        .wallet-balance-amount {
            font-size: 1.2rem;
        }

        /* Form sections */
        .form-section {
            margin-bottom: 2rem;
        }
        
        /* Star rating styles */
        .rating-container {
            display: flex;
            align-items: center;
            margin-top: 0.5rem;
        }
        
        .form-check-inline {
            margin-right: 0.8rem;
        }
        
        .form-check-input[name="confidence_rating"]:checked + label {
            color: var(--neon-cyan);
            text-shadow: 0 0 5px var(--glow-color-cyan);
        }
        
        .form-check-input[name="confidence_rating"]:checked + label i {
            font-weight: 900;
            color: var(--neon-cyan);
        }
        
        .form-check-input[name="confidence_rating"] + label i {
            margin-left: 2px;
        }

        /* Form actions */
        .form-actions {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 2rem;
        }

        /* Optional fields note */
        .optional-note {
            font-size: 0.85rem;
            color: var(--text-secondary);
            font-style: italic;
            margin-top: 0.25rem;
        }
        
        /* Mobile Optimization Styles */
        @media (max-width: 768px) {
            .form-card {
                padding: 1.5rem;
                margin-bottom: 1.5rem;
            }
            
            .navbar {
                padding: 0.6rem 0;
            }
            
            .navbar-brand {
                font-size: 1.2rem;
            }
            
            .nav-button {
                padding: 0.3rem 0.7rem;
                font-size: 0.8rem;
                margin-left: 0.3rem;
            }
            
            .form-label {
                font-size: 0.9rem;
            }
            
            .page-title {
                font-size: 1.5rem;
            }
            
            .wallet-info {
                padding: 0.8rem;
                margin-bottom: 1rem;
            }
            
            .wallet-balance-amount {
                font-size: 1.1rem;
            }
            
            .section-heading {
                font-size: 1rem;
                margin-bottom: 1rem;
            }
            
            .rating-container {
                flex-wrap: wrap;
            }
            
            .form-check-inline {
                margin-right: 0.5rem;
                margin-bottom: 0.5rem;
            }
            
            .file-input-label {
                padding: 1.5rem;
            }
            
            .file-input-icon {
                font-size: 2rem;
                margin-bottom: 0.5rem;
            }
            
            /* Make form inputs larger on mobile for easier touch */
            .form-control, .form-select {
                padding: 0.8rem;
                font-size: 1rem;
            }
            
            /* Improve tap targets */
            .form-check-input {
                width: 1.2rem;
                height: 1.2rem;
            }
            
            .form-check-label {
                font-size: 0.9rem;
                padding-left: 0.2rem;
            }
            
            /* Adjust button size for easier tapping */
            .preview-delete-btn {
                width: 40px;
                height: 40px;
                font-size: 1rem;
            }
        }

    </style>
</head>
<body>
    <?php 
    $current_page = basename($_SERVER['PHP_SELF']);
    include('navigation.php'); 
    ?>

    <div class="container mt-5">
        <h1 class="page-title">Add New Trade</h1>

        <?php if (!empty($error_message)): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle me-2"></i> <?= htmlspecialchars($error_message) ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($success_message)): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle me-2"></i> <?= htmlspecialchars($success_message) ?>
            </div>
        <?php endif; ?>

        <div class="wallet-info">
            <div>
                <span class="wallet-label">Current Wallet Balance:</span>
            </div>
            <div class="wallet-balance">
                <span class="wallet-balance-amount"><?= $currency_symbol . number_format($wallet_balance, 2) ?></span>
            </div>
        </div>

        <form method="post" enctype="multipart/form-data" class="needs-validation" novalidate>
            <div class="form-card">
                <h2 class="section-heading">Trade Information</h2>
                
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="pair" class="form-label">Trading Pair / Asset *</label>
                        <input type="text" class="form-control" id="pair" name="pair" placeholder="e.g. BTC/USD, AAPL, EUR/USD" value="<?= htmlspecialchars($_POST['pair'] ?? '') ?>" required>
                        <div class="invalid-feedback">Please enter a trading pair.</div>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <label for="date" class="form-label">Trade Date *</label>
                        <input type="date" class="form-control" id="date" name="date" value="<?= htmlspecialchars($_POST['date'] ?? $current_date) ?>" required>
                        <div class="invalid-feedback">Please select a date.</div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="order_type" class="form-label">Order Type *</label>
                        <select class="form-select" id="order_type" name="order_type" required>
                            <option value="" disabled <?= !isset($_POST['order_type']) ? 'selected' : '' ?>>Select order type</option>
                            <option value="Long" <?= (isset($_POST['order_type']) && $_POST['order_type'] === 'Long') ? 'selected' : '' ?>>Long</option>
                            <option value="Short" <?= (isset($_POST['order_type']) && $_POST['order_type'] === 'Short') ? 'selected' : '' ?>>Short</option>
                        </select>
                        <div class="invalid-feedback">Please select an order type.</div>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <label for="status" class="form-label">Trade Status *</label>
                        <select class="form-select" id="status" name="status" required>
                            <option value="" disabled <?= !isset($_POST['status']) ? 'selected' : '' ?>>Select status</option>
                            <option value="Open" <?= (isset($_POST['status']) && $_POST['status'] === 'Open') ? 'selected' : '' ?>>Open</option>
                            <option value="Closed" <?= (isset($_POST['status']) && $_POST['status'] === 'Closed') ? 'selected' : '' ?>>Closed</option>
                            <option value="Limit Order" <?= (isset($_POST['status']) && $_POST['status'] === 'Limit Order') ? 'selected' : '' ?>>Limit Order</option>
                        </select>
                        <div class="invalid-feedback">Please select a status.</div>
                    </div>
                </div>
            </div>

            <div class="form-card">
                <h2 class="section-heading">Trade Details</h2>
                
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="entry" class="form-label">Entry Price</label>
                        <input type="number" step="any" class="form-control" id="entry" name="entry" placeholder="Entry price" value="<?= htmlspecialchars($_POST['entry'] ?? '') ?>">
                        <div class="optional-note">Optional field</div>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <label for="position_size" class="form-label">Position Size</label>
                        <input type="number" step="any" class="form-control" id="position_size" name="position_size" placeholder="Position size" value="<?= htmlspecialchars($_POST['position_size'] ?? '') ?>">
                        <div class="optional-note">Optional field</div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="stop_loss" class="form-label">Stop Loss Price</label>
                        <input type="number" step="any" class="form-control" id="stop_loss" name="stop_loss" placeholder="Stop loss price" value="<?= htmlspecialchars($_POST['stop_loss'] ?? '') ?>">
                        <div class="optional-note">Optional field</div>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <label for="take_profit" class="form-label">Take Profit Price</label>
                        <input type="number" step="any" class="form-control" id="take_profit" name="take_profit" placeholder="Take profit price" value="<?= htmlspecialchars($_POST['take_profit'] ?? '') ?>">
                        <div class="optional-note">Optional field</div>
                    </div>
                </div>

                <div class="mb-3">
                    <label for="pnl" class="form-label">Profit/Loss Amount</label>
                    <div class="input-group">
                        <span class="input-group-text"><?= $currency_symbol ?></span>
                        <input type="number" step="any" class="form-control" id="pnl" name="pnl" placeholder="Enter P&L amount" value="<?= htmlspecialchars($_POST['pnl'] ?? '0') ?>">
                    </div>
                    <div class="form-text">For profitable trades, enter a positive number. For losses, enter a negative number.</div>
                </div>
            </div>

            <div class="form-card">
                <h2 class="section-heading">Chart Image</h2>
                
                <div class="file-input-container">
                    <label for="chart_image" class="file-input-label">
                        <div class="file-input-icon">
                            <i class="fas fa-chart-line"></i>
                        </div>
                        <div class="file-input-text">Drag and drop a chart image or click to browse</div>
                        <div class="file-input-help">JPEG, PNG, GIF up to 5MB</div>
                    </label>
                    <input type="file" id="chart_image" name="chart_image" class="file-input" accept="image/jpeg, image/png, image/gif, image/webp">
                    <div id="file-name"></div>
                </div>
                
                <div class="preview-container" id="preview-container">
                    <img id="preview-image" class="preview-image">
                    <div class="preview-delete-btn" id="preview-delete-btn">
                        <i class="fas fa-times"></i>
                    </div>
                </div>
            </div>

            <div class="form-card">
                <h2 class="section-heading">Trade Psychology & Strategy</h2>
                
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="strategy" class="form-label">Trading Strategy</label>
                        <select class="form-select" id="strategy" name="strategy">
                            <option value="" selected>Select a strategy</option>
                            <?php foreach(get_strategies() as $strategyOption): ?>
                            <option value="<?= htmlspecialchars($strategyOption) ?>" <?= (isset($_POST['strategy']) && $_POST['strategy'] === $strategyOption) ? 'selected' : '' ?>><?= htmlspecialchars($strategyOption) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <div class="optional-note">Select the strategy used for this trade</div>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <label for="emotion" class="form-label">Emotional State</label>
                        <select class="form-select" id="emotion" name="emotion">
                            <option value="" selected>How did you feel?</option>
                            <?php foreach(get_emotions() as $emotionOption): ?>
                            <option value="<?= htmlspecialchars($emotionOption) ?>" <?= (isset($_POST['emotion']) && $_POST['emotion'] === $emotionOption) ? 'selected' : '' ?>><?= htmlspecialchars($emotionOption) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <div class="optional-note">How did you feel during this trade?</div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="market_context" class="form-label">Market Context</label>
                        <select class="form-select" id="market_context" name="market_context">
                            <option value="" selected>Select market context</option>
                            <?php foreach(get_market_contexts() as $contextOption): ?>
                            <option value="<?= htmlspecialchars($contextOption) ?>" <?= (isset($_POST['market_context']) && $_POST['market_context'] === $contextOption) ? 'selected' : '' ?>><?= htmlspecialchars($contextOption) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <div class="optional-note">Market conditions during this trade</div>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <label for="confidence_rating" class="form-label">Confidence Rating</label>
                        <div class="rating-container">
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="confidence_rating" id="confidence1" value="1" <?= (isset($_POST['confidence_rating']) && $_POST['confidence_rating'] == 1) ? 'checked' : '' ?>>
                                <label class="form-check-label" for="confidence1">1 <i class="far fa-star"></i></label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="confidence_rating" id="confidence2" value="2" <?= (isset($_POST['confidence_rating']) && $_POST['confidence_rating'] == 2) ? 'checked' : '' ?>>
                                <label class="form-check-label" for="confidence2">2 <i class="far fa-star"></i></label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="confidence_rating" id="confidence3" value="3" <?= (isset($_POST['confidence_rating']) && $_POST['confidence_rating'] == 3) ? 'checked' : '' ?>>
                                <label class="form-check-label" for="confidence3">3 <i class="far fa-star"></i></label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="confidence_rating" id="confidence4" value="4" <?= (isset($_POST['confidence_rating']) && $_POST['confidence_rating'] == 4) ? 'checked' : '' ?>>
                                <label class="form-check-label" for="confidence4">4 <i class="far fa-star"></i></label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="confidence_rating" id="confidence5" value="5" <?= (isset($_POST['confidence_rating']) && $_POST['confidence_rating'] == 5) ? 'checked' : '' ?>>
                                <label class="form-check-label" for="confidence5">5 <i class="far fa-star"></i></label>
                            </div>
                        </div>
                        <div class="optional-note">How confident were you in this trade? (1-5 stars)</div>
                    </div>
                </div>
                
                <div class="mb-3">
                    <label for="lessons_learned" class="form-label">Lessons Learned</label>
                    <textarea class="form-control" id="lessons_learned" name="lessons_learned" rows="3" placeholder="What did you learn from this trade? What would you do differently next time?"><?= htmlspecialchars($_POST['lessons_learned'] ?? '') ?></textarea>
                    <div class="optional-note">Document key takeaways and things to improve</div>
                </div>
            </div>

            <div class="form-card">
                <h2 class="section-heading">Notes & Analysis</h2>
                
                <div class="mb-3">
                    <label for="notes" class="form-label">Trade Notes</label>
                    <textarea class="form-control" id="notes" name="notes" rows="4" placeholder="Enter your trade notes, strategy used, and reasons for entry/exit..."><?= htmlspecialchars($_POST['notes'] ?? '') ?></textarea>
                </div>
                
                <div class="mb-3">
                    <label for="market_conditions" class="form-label">Market Conditions</label>
                    <textarea class="form-control" id="market_conditions" name="market_conditions" rows="3" placeholder="Describe the market conditions, trends, or events affecting this trade..."><?= htmlspecialchars($_POST['market_conditions'] ?? '') ?></textarea>
                </div>
            </div>

            <div class="form-actions">
                <a href="index.php" class="nav-button">
                    <i class="fas fa-times me-2"></i>Cancel
                </a>
                <button type="submit" class="nav-button primary">
                    <i class="fas fa-save me-2"></i>Save Trade
                </button>
            </div>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script src="js/main.js"></script>
    <script src="js/theme-switcher.js"></script>
    
    <script>
        // File input handling
        const fileInput = document.getElementById('chart_image');
        const fileNameDisplay = document.getElementById('file-name');
        const previewContainer = document.getElementById('preview-container');
        const previewImage = document.getElementById('preview-image');
        const previewDeleteBtn = document.getElementById('preview-delete-btn');
        
        fileInput.addEventListener('change', function(e) {
            const file = e.target.files[0];
            
            if (file) {
                fileNameDisplay.textContent = file.name;
                
                // Show image preview
                const reader = new FileReader();
                reader.onload = function(e) {
                    previewImage.src = e.target.result;
                    previewContainer.style.display = 'block';
                }
                reader.readAsDataURL(file);
            } else {
                fileNameDisplay.textContent = '';
                previewContainer.style.display = 'none';
            }
        });
        
        // Handle delete button click
        previewDeleteBtn.addEventListener('click', function() {
            // Clear the file input
            fileInput.value = '';
            fileNameDisplay.textContent = '';
            
            // Hide the preview
            previewContainer.style.display = 'none';
            previewImage.src = '';
            
            // Create a new DataTransfer object and clear any selected files
            const dt = new DataTransfer();
            fileInput.files = dt.files;
        });
        
        // Form validation
        (() => {
            'use strict'
            
            // Fetch all forms we want to apply custom validation to
            const forms = document.querySelectorAll('.needs-validation');
            
            // Loop over them and prevent submission
            Array.from(forms).forEach(form => {
                form.addEventListener('submit', event => {
                    if (!form.checkValidity()) {
                        event.preventDefault();
                        event.stopPropagation();
                    }
                    
                    form.classList.add('was-validated');
                }, false);
            });
        })();
    </script>
</body>
</html>
