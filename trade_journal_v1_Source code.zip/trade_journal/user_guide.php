<?php
/**
 * User Guide for Trade Journal
 */

// Prevent any output before headers are sent
ob_start();

// Include authentication functions and database connection
include_once 'auth.php';
include_once 'db_connect.php';

// Require login for this page
require_login();

// Get navigation active page
$active_page = 'user_guide';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Guide - Trade Journal</title>
    
    <link rel="icon" type="image/png" href="fav.png">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="themes.css">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="app-container">
        <!-- Sidebar/Navigation -->
        <?php include_once 'navigation.php'; // Include the reusable navigation partial with styling fix ?>
        
        <!-- Main Content -->
        <main class="content">
            <div class="content-header">
                <h1>User Guide</h1>
                <p>Learn how to use your trading journal effectively</p>
            </div>
            
            <div class="content-body">
                <div class="card mb-4">
                    <div class="card-header">
                        <h2><i class="fas fa-book me-2"></i>User Guide Contents</h2>
                    </div>
                    <div class="card-body">
                        <div class="toc-container">
                            <ul class="toc-list">
                                <li><a href="#dashboard">Dashboard Overview</a></li>
                                <li><a href="#trades">Managing Trades</a></li>
                                <li><a href="#analysis">Performance Analysis</a></li>
                                <li><a href="#settings">Customizing Settings</a></li>
                                <li><a href="#themes">Changing Themes</a></li>
                                <li><a href="#tips">Best Practices</a></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <!-- Dashboard Section -->
                <div class="card mb-4" id="dashboard">
                    <div class="card-header">
                        <h2><i class="fas fa-tachometer-alt me-2"></i>Dashboard Overview</h2>
                    </div>
                    <div class="card-body">
                        <div class="guide-section">
                            <h3>Dashboard Components</h3>
                            <p>
                                The dashboard is your central hub for tracking your trading performance. Here's what you'll find:
                            </p>
                            
                            <div class="guide-feature">
                                <h4><i class="fas fa-wallet me-2"></i>Wallet Balance</h4>
                                <p>
                                    Located at the top of the dashboard, this shows your current account balance based on your initial capital 
                                    (<?php echo get_currency_symbol() . number_format(get_initial_capital(), 2); ?>) plus all realized profit and loss from your trades.
                                </p>
                            </div>
                            
                            <div class="guide-feature">
                                <h4><i class="fas fa-chart-line me-2"></i>Performance Overview</h4>
                                <p>
                                    Visual charts and metrics showing your win rate, average profit/loss, and performance over time.
                                    These metrics help you track your progress and identify patterns in your trading.
                                </p>
                            </div>
                            
                            <div class="guide-feature">
                                <h4><i class="fas fa-list me-2"></i>Recent Trades</h4>
                                <p>
                                    A summary of your most recent trades including pair traded, profit/loss, and date.
                                    Click on any trade to view its complete details.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Trades Section -->
                <div class="card mb-4" id="trades">
                    <div class="card-header">
                        <h2><i class="fas fa-exchange-alt me-2"></i>Managing Trades</h2>
                    </div>
                    <div class="card-body">
                        <div class="guide-section">
                            <h3>Adding New Trades</h3>
                            <p>
                                To add a new trade, click the <span class="badge bg-primary"><i class="fas fa-plus"></i> Add Trade</span> button 
                                in the navigation menu or on the dashboard.
                            </p>
                            
                            <div class="guide-feature">
                                <h4>Trade Entry Form Fields</h4>
                                <ul>
                                    <li><strong>Pair:</strong> The trading pair (e.g., BTC/USD, EUR/USD)</li>
                                    <li><strong>Order Type:</strong> Buy or Sell</li>
                                    <li><strong>Status:</strong> Open or Closed</li>
                                    <li><strong>Entry Price:</strong> Your entry price for the trade</li>
                                    <li><strong>Stop Loss:</strong> Your stop loss level (optional)</li>
                                    <li><strong>Take Profit:</strong> Your take profit target (optional)</li>
                                    <li><strong>Position Size:</strong> The size of your position</li>
                                    <li><strong>Risk-Reward Ratio:</strong> Automatically calculated based on your entry, stop loss, and take profit</li>
                                    <li><strong>Profit/Loss:</strong> For closed trades, enter the realized P/L</li>
                                    <li><strong>Screenshot:</strong> Upload a chart image for visual reference (optional)</li>
                                    <li><strong>Notes:</strong> Any additional notes about the trade</li>
                                </ul>
                            </div>
                            
                            <h3>Editing Trades</h3>
                            <p>
                                To edit an existing trade, find it in your trade list and click the <span class="badge bg-warning text-dark"><i class="fas fa-edit"></i></span> icon.
                                You can update any information about the trade, including changing its status from Open to Closed.
                            </p>
                            
                            <h3>Viewing Trade Details</h3>
                            <p>
                                Click on any trade in your list to view its complete details, including the chart image if one was uploaded.
                                This view also shows additional information like market context and your emotional state during the trade.
                            </p>
                        </div>
                    </div>
                </div>

                <!-- Analysis Section -->
                <div class="card mb-4" id="analysis">
                    <div class="card-header">
                        <h2><i class="fas fa-chart-pie me-2"></i>Performance Analysis</h2>
                    </div>
                    <div class="card-body">
                        <div class="guide-section">
                            <h3>Analysis Features</h3>
                            <p>
                                The analysis page provides deeper insights into your trading performance to help you identify strengths 
                                and areas for improvement.
                            </p>
                            
                            <div class="guide-feature">
                                <h4><i class="fas fa-coins me-2"></i>P/L by Pair</h4>
                                <p>
                                    See which trading pairs are most profitable for you. This can help you focus on markets where 
                                    you have a consistent edge.
                                </p>
                            </div>
                            
                            <div class="guide-feature">
                                <h4><i class="fas fa-brain me-2"></i>Strategy Performance</h4>
                                <p>
                                    Compare the effectiveness of different trading strategies. The analysis shows win rate and 
                                    average profit for each strategy you've used.
                                </p>
                            </div>
                            
                            <div class="guide-feature">
                                <h4><i class="fas fa-calendar-alt me-2"></i>Time Analysis</h4>
                                <p>
                                    View your performance by day of week and time of day. This can help you identify optimal 
                                    trading hours or days when you should be more cautious.
                                </p>
                            </div>
                            
                            <div class="guide-feature">
                                <h4><i class="fas fa-smile me-2"></i>Emotional Impact</h4>
                                <p>
                                    Analyze how your emotional state affects your trading results. This psychological insight can 
                                    help you develop better emotional discipline.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Settings Section -->
                <div class="card mb-4" id="settings">
                    <div class="card-header">
                        <h2><i class="fas fa-cog me-2"></i>Customizing Settings</h2>
                    </div>
                    <div class="card-body">
                        <div class="guide-section">
                            <h3>Available Settings</h3>
                            <p>
                                Access the settings page by clicking the <span class="badge bg-secondary"><i class="fas fa-cog"></i> Settings</span> 
                                option in the navigation menu.
                            </p>
                            
                            <div class="guide-feature">
                                <h4><i class="fas fa-dollar-sign me-2"></i>Currency and Initial Capital</h4>
                                <p>
                                    Change your currency symbol and initial capital amount. This affects how monetary values are 
                                    displayed throughout the application and serves as the baseline for your wallet balance.
                                </p>
                            </div>
                            
                            <div class="guide-feature">
                                <h4><i class="fas fa-tags me-2"></i>Trading Strategies</h4>
                                <p>
                                    Customize the list of trading strategies available when adding or editing trades. Add your own 
                                    strategies or remove ones you don't use.
                                </p>
                            </div>
                            
                            <div class="guide-feature">
                                <h4><i class="fas fa-chart-area me-2"></i>Market Contexts</h4>
                                <p>
                                    Define different market conditions (trending, ranging, volatile, etc.) to categorize your trades 
                                    and analyze performance in different market environments.
                                </p>
                            </div>
                            
                            <div class="guide-feature">
                                <h4><i class="fas fa-heart me-2"></i>Emotions</h4>
                                <p>
                                    Customize the list of emotional states to track with your trades. This helps you identify how 
                                    emotions affect your trading decisions.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Themes Section -->
                <div class="card mb-4" id="themes">
                    <div class="card-header">
                        <h2><i class="fas fa-paint-brush me-2"></i>Changing Themes</h2>
                    </div>
                    <div class="card-body">
                        <div class="guide-section">
                            <h3>Theme Selection</h3>
                            <p>
                                Change the visual appearance of your trading journal by selecting a different theme. Click on the theme 
                                selector in the top right corner of any page.
                            </p>
                            
                            <div class="guide-feature">
                                <h4>Available Themes</h4>
                                <ul>
                                    <li><strong>Light:</strong> Clean, bright interface suitable for daytime use</li>
                                    <li><strong>Midnight:</strong> Dark theme that's easier on the eyes in low-light environments</li>
                                    <li><strong>Financial:</strong> Professional theme inspired by financial terminals</li>
                                    <li><strong>Neon:</strong> High-contrast theme with vibrant accents</li>
                                </ul>
                            </div>
                            
                            <p>
                                Your theme preference is saved automatically and will persist across sessions.
                            </p>
                        </div>
                    </div>
                </div>

                <!-- Best Practices Section -->
                <div class="card mb-4" id="tips">
                    <div class="card-header">
                        <h2><i class="fas fa-lightbulb me-2"></i>Best Practices</h2>
                    </div>
                    <div class="card-body">
                        <div class="guide-section">
                            <h3>Getting the Most from Your Trading Journal</h3>
                            
                            <div class="guide-feature">
                                <h4><i class="fas fa-clock me-2"></i>Consistent Documentation</h4>
                                <p>
                                    Record your trades as soon as possible after execution. Include all relevant details, especially your 
                                    reasoning and emotional state, to make your journal more valuable for future analysis.
                                </p>
                            </div>
                            
                            <div class="guide-feature">
                                <h4><i class="fas fa-camera me-2"></i>Use Screenshots</h4>
                                <p>
                                    Upload chart images for your trades whenever possible. Visual documentation helps you remember the context 
                                    and can reveal patterns in your trading that might not be apparent otherwise.
                                </p>
                            </div>
                            
                            <div class="guide-feature">
                                <h4><i class="fas fa-search me-2"></i>Regular Review</h4>
                                <p>
                                    Schedule weekly and monthly reviews of your trading performance. Use the analysis tools to identify 
                                    weaknesses and strengths in your trading approach.
                                </p>
                            </div>
                            
                            <div class="guide-feature">
                                <h4><i class="fas fa-book-open me-2"></i>Track Lessons Learned</h4>
                                <p>
                                    For each trade, document what you learned in the "Lessons Learned" field. Over time, this creates a 
                                    personalized trading handbook based on your actual experience.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script src="js/theme-switcher.js"></script>
    <script src="js/main.js"></script>
    
    <script>
        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                
                const targetId = this.getAttribute('href');
                const targetElement = document.querySelector(targetId);
                
                if (targetElement) {
                    window.scrollTo({
                        top: targetElement.offsetTop - 20,
                        behavior: 'smooth'
                    });
                }
            });
        });
    </script>
</body>
</html>