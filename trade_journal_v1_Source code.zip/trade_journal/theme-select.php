<?php
// Apply the current theme to the document root
$current_theme = isset($_COOKIE['theme']) ? $_COOKIE['theme'] : 'neon';
?>
<!-- Theme Selector Modal -->
<div class="modal fade" id="themeModal" tabindex="-1" aria-labelledby="themeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="themeModalLabel">Choose Theme</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="theme-options-container">
                    <div class="theme-preview">
                        <div class="theme-option-card" data-theme-value="neon">
                            <div class="theme-option-preview theme-neon">
                                <div class="theme-preview-header"></div>
                                <div class="theme-preview-content"></div>
                            </div>
                            <div class="theme-option-name">Dark Neon</div>
                            <div class="theme-option-description">Cyberpunk-inspired dark theme with neon accents</div>
                        </div>
                        
                        <div class="theme-option-card" data-theme-value="light">
                            <div class="theme-option-preview theme-light">
                                <div class="theme-preview-header"></div>
                                <div class="theme-preview-content"></div>
                            </div>
                            <div class="theme-option-name">Light</div>
                            <div class="theme-option-description">Clean light theme with blue accents</div>
                        </div>
                        
                        <div class="theme-option-card" data-theme-value="financial">
                            <div class="theme-option-preview theme-financial">
                                <div class="theme-preview-header"></div>
                                <div class="theme-preview-content"></div>
                            </div>
                            <div class="theme-option-name">Financial</div>
                            <div class="theme-option-description">Professional theme with green accents</div>
                        </div>
                        
                        <div class="theme-option-card" data-theme-value="midnight">
                            <div class="theme-option-preview theme-midnight">
                                <div class="theme-preview-header"></div>
                                <div class="theme-preview-content"></div>
                            </div>
                            <div class="theme-option-name">Midnight</div>
                            <div class="theme-option-description">Deep blue dark theme with purple accents</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="nav-button" data-bs-dismiss="modal">Cancel</button>
            </div>
        </div>
    </div>
</div>

<style>
/* Theme modal styles */
.theme-options-container {
    display: flex;
    flex-direction: column;
    gap: 20px;
}

.theme-preview {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
    gap: 20px;
}

.theme-option-card {
    border-radius: var(--border-radius);
    overflow: hidden;
    transition: all 0.3s ease;
    cursor: pointer;
    border: 2px solid transparent;
    padding: 8px;
}

.theme-option-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
}

.theme-option-card.active {
    border-color: var(--neon-cyan);
    box-shadow: 0 0 15px var(--glow-color-cyan);
}

.theme-option-preview {
    height: 120px;
    border-radius: var(--border-radius);
    overflow: hidden;
    margin-bottom: 10px;
    position: relative;
}

.theme-preview-header {
    height: 30px;
    width: 100%;
    position: absolute;
    top: 0;
    left: 0;
}

.theme-preview-content {
    height: calc(100% - 30px);
    width: 100%;
    position: absolute;
    bottom: 0;
    left: 0;
}

.theme-option-name {
    font-weight: 600;
    font-size: 1rem;
    margin-bottom: 5px;
    color: var(--text-primary);
}

.theme-option-description {
    font-size: 0.8rem;
    color: var(--text-secondary);
    line-height: 1.4;
}

/* Theme preview colors */
.theme-option-preview.theme-neon {
    background-color: #0a0c10;
    border: 1px solid #00ffff;
    box-shadow: 0 0 10px rgba(0, 255, 255, 0.2);
}

.theme-option-preview.theme-neon .theme-preview-header {
    background-color: #141821;
    border-bottom: 1px solid #00ffff;
}

.theme-option-preview.theme-neon .theme-preview-content {
    background: linear-gradient(135deg, #0a0c10 0%, #141821 100%);
}

.theme-option-preview.theme-light {
    background-color: #f5f7fa;
    border: 1px solid #007bff;
}

.theme-option-preview.theme-light .theme-preview-header {
    background-color: #e4e7eb;
    border-bottom: 1px solid #007bff;
}

.theme-option-preview.theme-light .theme-preview-content {
    background: linear-gradient(135deg, #f5f7fa 0%, #e4e7eb 100%);
}

.theme-option-preview.theme-financial {
    background-color: #ffffff;
    border: 1px solid #28a745;
}

.theme-option-preview.theme-financial .theme-preview-header {
    background-color: #f8f9fa;
    border-bottom: 1px solid #28a745;
}

.theme-option-preview.theme-financial .theme-preview-content {
    background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);
}

.theme-option-preview.theme-midnight {
    background-color: #0f172a;
    border: 1px solid #818cf8;
    box-shadow: 0 0 10px rgba(129, 140, 248, 0.2);
}

.theme-option-preview.theme-midnight .theme-preview-header {
    background-color: #1e293b;
    border-bottom: 1px solid #818cf8;
}

.theme-option-preview.theme-midnight .theme-preview-content {
    background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
}
</style>

<script>
// Add active class to the current theme
document.addEventListener('DOMContentLoaded', function() {
    const currentTheme = '<?= $current_theme ?>';
    const themeCards = document.querySelectorAll('.theme-option-card');
    
    // Mark active theme
    themeCards.forEach(card => {
        if (card.getAttribute('data-theme-value') === currentTheme) {
            card.classList.add('active');
        }
    });
    
    // Add click event to theme cards
    themeCards.forEach(card => {
        card.addEventListener('click', function() {
            const themeValue = this.getAttribute('data-theme-value');
            
            // Remove active class from all cards
            themeCards.forEach(c => c.classList.remove('active'));
            
            // Add active class to clicked card
            this.classList.add('active');
            
            // Set the theme cookie and reload the page
            document.cookie = `theme=${themeValue}; path=/; max-age=31536000`;
            document.documentElement.setAttribute('data-theme', themeValue);
            
            // Close the modal
            const themeModal = bootstrap.Modal.getInstance(document.getElementById('themeModal'));
            if (themeModal) {
                themeModal.hide();
            }
        });
    });
});
</script>