<?php
// Include configuration file if it exists
if (file_exists('config.php')) {
    @include_once 'config.php';
}

// Database credentials
$host = defined('DB_HOST') ? DB_HOST : 'localhost';
$user = defined('DB_USER') ? DB_USER : 'root';
$pass = defined('DB_PASS') ? DB_PASS : '';
$dbname = defined('DB_NAME') ? DB_NAME : 'trade';

// Check if the site is installed and database credentials are set
$is_installed = defined('INSTALLED') && INSTALLED === true;

// Don't attempt to connect if we're not installed and on the install page
$on_install_page = basename($_SERVER['PHP_SELF']) === 'install.php';
if (!$is_installed && $on_install_page && empty($host)) {
    // Skip database connection during installation
    $conn = null;
} else {
    // Connect to MySQL
    $conn = @new mysqli($host, $user, $pass, $dbname);

    // Check connection
    if ($conn && $conn->connect_error) {
        $error_message = "Connection failed: " . $conn->connect_error;
        error_log($error_message);
        
        // Only die if we're not on the install page
        if (!$on_install_page) {
            die($error_message);
        }
    } elseif ($conn) {
        // Set charset to ensure proper encoding
        $conn->set_charset("utf8mb4");
    }
}

// Function to sanitize input data
function sanitize_input($data) {
    global $conn;
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    
    // If we have a connection, use real_escape_string
    if ($conn) {
        return $conn->real_escape_string($data);
    }
    
    return $data;
}

// Function to check if a table exists for MySQL
function table_exists($table_name) {
    global $conn, $dbname;
    
    // If we don't have a connection, return false
    if (!$conn) {
        return false;
    }
    
    $result = $conn->query("SHOW TABLES LIKE '{$table_name}'");
    return $result && $result->num_rows > 0;
}

// Create tables only if we have a database connection
if ($conn) {
    // Create trades table if it doesn't exist
    if (!table_exists('trades')) {
        $sql = "CREATE TABLE trades (
            id INT(11) NOT NULL AUTO_INCREMENT,
            pair VARCHAR(50) NOT NULL,
            order_type VARCHAR(20) NOT NULL,
            status VARCHAR(20) NOT NULL,
            entry DECIMAL(15,8) DEFAULT NULL,
            stop_loss DECIMAL(15,8) DEFAULT NULL,
            take_profit DECIMAL(15,8) DEFAULT NULL,
            position_size DECIMAL(15,2) DEFAULT NULL,
            pnl DECIMAL(15,2) NOT NULL DEFAULT 0.00,
            date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            image VARCHAR(255) DEFAULT NULL,
            notes TEXT DEFAULT NULL,
            market_conditions TEXT DEFAULT NULL,
            rr DECIMAL(5,2) DEFAULT 0.00,
            
            -- New Phase 1 fields
            strategy VARCHAR(100) DEFAULT NULL,
            emotion VARCHAR(50) DEFAULT NULL,
            confidence_rating INT(1) DEFAULT NULL,
            lessons_learned TEXT DEFAULT NULL,
            market_context VARCHAR(50) DEFAULT NULL,
            
            PRIMARY KEY (id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";
        
        if ($conn->query($sql) !== TRUE) {
            error_log("Error creating trades table: " . $conn->error);
        }
    }

    // Create settings table if it doesn't exist
    if (!table_exists('settings')) {
        $sql = "CREATE TABLE settings (
            id INT(11) NOT NULL AUTO_INCREMENT,
            setting_name VARCHAR(50) NOT NULL,
            setting_value TEXT NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY (setting_name)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";
        
        if ($conn->query($sql) !== TRUE) {
            error_log("Error creating settings table: " . $conn->error);
        } else {
            // Insert default settings
            $stmt = $conn->prepare("INSERT INTO settings (setting_name, setting_value) VALUES (?, ?)");
            $stmt->bind_param("ss", $name, $value);
            
            $name = "initial_capital";
            $value = "30.00";
            $stmt->execute();
            
            $name = "currency_symbol";
            $value = "$";
            $stmt->execute();
            
            // Add default strategies
            $name = "strategies";
            $value = "Trend Following,Breakout,Range Trading,Scalping,News Trading,Swing Trading,Position Trading,Mean Reversion,Counter Trend";
            $stmt->execute();
            
            // Add default emotions
            $name = "emotions";
            $value = "Calm,Excited,Fearful,Greedy,Impatient,Confident,Nervous,Indecisive,Regretful,Focused";
            $stmt->execute();
            
            // Add default market contexts
            $name = "market_contexts";
            $value = "Trending Up,Trending Down,Ranging,Volatile,Choppy,Consolidating,Breakout,News Impact,Low Volume,High Volume";
            $stmt->execute();
            
            $stmt->close();
        }
    }
}

// Function to get a setting value
function get_setting($setting_name, $default = '') {
    global $conn;
    $value = $default;
    
    // If we don't have a connection, return default
    if (!$conn) {
        return $value;
    }
    
    try {
        $sql = "SELECT setting_value FROM settings WHERE setting_name = ?";
        $stmt = $conn->prepare($sql);
        
        if ($stmt) {
            $stmt->bind_param("s", $setting_name);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result && $result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $value = $row['setting_value'];
            }
            $stmt->close();
        }
    } catch (Exception $e) {
        // Log the error but continue with default value
        error_log("Error getting setting: " . $e->getMessage());
    }
    
    return $value;
}

// Function to update a setting
function update_setting($setting_name, $setting_value) {
    global $conn;
    
    // If we don't have a connection, return false
    if (!$conn) {
        return false;
    }
    
    $sql = "INSERT INTO settings (setting_name, setting_value) VALUES (?, ?) 
            ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)";
    $stmt = $conn->prepare($sql);
    
    if ($stmt) {
        $stmt->bind_param("ss", $setting_name, $setting_value);
        $success = $stmt->execute();
        $stmt->close();
        return $success;
    }
    
    return false;
}

// Get initial capital from settings or use default
function get_initial_capital() {
    // Always try to get from database first
    $initial_capital = get_setting('initial_capital', '1000');
    
    // If database value is available, use it
    if ($initial_capital !== '1000') {
        return floatval($initial_capital);
    }
    
    // Fallback to config constant if available
    if (defined('INITIAL_CAPITAL')) {
        return floatval(INITIAL_CAPITAL);
    }
    
    // Default value as last resort
    return 1000;
}

// Get current wallet balance (initial capital + all PnL)
function get_wallet_balance() {
    global $conn;
    $initial_capital = get_initial_capital();
    
    // If we don't have a connection, return initial capital
    if (!$conn) {
        return $initial_capital;
    }
    
    // Check if trades table exists first
    $trades_exist = $conn->query("SHOW TABLES LIKE 'trades'")->num_rows > 0;
    if (!$trades_exist) {
        return $initial_capital;
    }
    
    // Check if there are any trades
    $count_result = $conn->query("SELECT COUNT(*) as count FROM trades");
    $count_row = $count_result->fetch_assoc();
    if ($count_row['count'] == 0) {
        return $initial_capital;
    }
    
    // Now get the sum of PnL
    $sql = "SELECT SUM(pnl) as total_pnl FROM trades";
    $result = $conn->query($sql);
    
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        // Explicitly handle NULL case
        if ($row['total_pnl'] === NULL) {
            return $initial_capital;
        }
        $total_pnl = floatval($row['total_pnl']);
        return $initial_capital + $total_pnl;
    }
    
    return $initial_capital;
}

// Get currency symbol
function get_currency_symbol() {
    // Always try to get from database first
    $currency_symbol = get_setting('currency_symbol', '$');
    
    // If database value is available and not the default, use it
    if ($currency_symbol !== '$') {
        return $currency_symbol;
    }
    
    // Fallback to config constant if available and valid
    if (defined('CURRENCY_SYMBOL') && is_string(CURRENCY_SYMBOL) && strlen(CURRENCY_SYMBOL) < 5) {
        return CURRENCY_SYMBOL;
    }
    
    // Default value as last resort
    return '$';
}

// Get list of available strategies as array
function get_strategies() {
    $strategies_str = get_setting('strategies', 'Trend Following,Breakout,Range Trading');
    return array_map('trim', explode(',', $strategies_str));
}

// Get list of available emotions as array
function get_emotions() {
    $emotions_str = get_setting('emotions', 'Calm,Excited,Fearful');
    return array_map('trim', explode(',', $emotions_str));
}

// Get list of available market contexts as array
function get_market_contexts() {
    $contexts_str = get_setting('market_contexts', 'Trending Up,Trending Down,Ranging');
    return array_map('trim', explode(',', $contexts_str));
}

// Function to ensure we have a valid database connection
function ensure_db_connection() {
    global $conn, $host, $user, $pass, $dbname;
    
    // If we're on the installation page, just return whatever we have
    $on_install_page = basename($_SERVER['PHP_SELF']) === 'install.php';
    if ($on_install_page) {
        return $conn;
    }
    
    // Check if connection is closed or not working
    if (!$conn || $conn->connect_error || ($conn && !$conn->ping())) {
        // Close the existing connection if it exists
        if ($conn) {
            $conn->close();
        }
        
        // Don't attempt to reconnect if we don't have credentials
        if (empty($host) || empty($dbname)) {
            error_log("Database connection failed: Missing host or database name");
            return null;
        }
        
        // Create a new connection
        $conn = @new mysqli($host, $user, $pass, $dbname);
        
        // Check the new connection
        if ($conn->connect_error) {
            error_log("Failed to reconnect to database: " . $conn->connect_error);
            // Only die if we're not on the install page
            if (!$on_install_page) {
                die("Database connection failed. Please try again later.");
            }
            return null;
        }
        
        // Set charset
        $conn->set_charset("utf8mb4");
    }
    
    return $conn;
}
?>
