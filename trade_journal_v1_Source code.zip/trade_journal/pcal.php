<?php
// Include database connection
include('db_connect.php');

// Calculate current wallet balance
$wallet_balance = get_wallet_balance();
$currency_symbol = get_currency_symbol();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Position Size Calculator - Trade Journal</title>
    <link rel="icon" type="image/png" href="fav.png"> 

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="themes.css">
    <style>

        body {
            background-color: var(--bg-primary);
            color: var(--text-primary);
            font-family: var(--font-family);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .navbar {
            background-color: var(--bg-secondary);
            border-bottom: 1px solid var(--border-color);
            padding: 0.8rem 0;
        }

        .navbar-brand {
            font-weight: 700;
            font-size: 1.4rem;
            color: var(--neon-cyan);
            text-shadow: 0 0 5px var(--glow-color-cyan);
            display: inline-flex;
            align-items: center;
        }
        .navbar-brand:hover { color: var(--neon-cyan); opacity: 0.9; }

        .navbar-brand svg {
             width: 28px;
             height: 28px;
             margin-right: 8px;
             vertical-align: -0.15em;
        }

        .nav-button {
            color: var(--neon-cyan);
            border: 1px solid var(--neon-cyan);
            background-color: transparent;
            padding: 0.4rem 0.9rem;
            border-radius: var(--border-radius);
            font-weight: 500;
            font-size: 0.9rem;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 0.4rem;
            text-decoration: none;
            margin-left: 0.5rem;
        }
        .nav-button:hover {
            background-color: rgba(0, 255, 255, 0.1);
            box-shadow: 0 0 10px var(--glow-color-cyan);
            color: var(--text-primary);
        }
        .nav-button.primary {
             background-color: var(--neon-cyan);
             color: var(--bg-primary);
             font-weight: 600;
        }
        .nav-button.primary:hover {
              background-color: #00e0e0;
             box-shadow: 0 0 15px var(--glow-color-cyan);
              color: var(--bg-primary);
        }

        .calculator-container {
            flex-grow: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 2rem 1rem;
        }

        .calculator {
            background-color: var(--bg-secondary);
            padding: 2.5rem;
            border-radius: var(--border-radius);
            border: 1px solid var(--border-color);
            max-width: 500px;
            width: 100%;
            box-shadow: 0 0 30px rgba(0, 0, 0, 0.2);
        }

        h1 {
            color: var(--text-primary);
            text-align: center;
            margin-bottom: 2.5rem;
            font-weight: 700;
            font-size: 1.8rem;
            position: relative;
            display: inline-block;
            width: 100%;
        }

        h1::after {
            content: '';
            position: absolute;
            bottom: -0.5rem;
            left: 50%;
            transform: translateX(-50%);
            width: 4rem;
            height: 0.2rem;
            background-color: var(--neon-cyan);
            border-radius: 2px;
            box-shadow: 0 0 10px var(--glow-color-cyan);
        }

        .input-group {
            margin-bottom: 1.5rem;
        }

        .input-label {
            color: var(--text-primary);
            font-weight: 600;
            margin-bottom: 0.5rem;
            display: block;
        }

        input[type="number"] {
            width: 100%;
            padding: 0.875rem 1rem;
            background-color: rgba(10, 12, 16, 0.5);
            border: 1px solid var(--border-color);
            color: var(--text-primary);
            border-radius: var(--border-radius);
            font-size: 1rem;
            transition: all 0.2s ease;
        }
        
        input[type="number"]:focus {
            background-color: rgba(10, 12, 16, 0.7);
            border-color: var(--neon-cyan);
            box-shadow: 0 0 0 0.25rem rgba(0, 255, 255, 0.2);
            color: var(--text-primary);
            outline: none;
        }
        
        input[type=number]::-webkit-inner-spin-button,
        input[type=number]::-webkit-outer-spin-button {
          -webkit-appearance: none;
          margin: 0;
        }
        input[type=number] { -moz-appearance: textfield; }

        input[readonly] {
            background-color: rgba(20, 24, 33, 0.7);
            cursor: not-allowed;
            border-color: rgba(0, 255, 255, 0.1);
        }

        .risk-buttons {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 0.75rem;
            margin: 1.5rem 0;
        }

        .risk-btn {
            padding: 0.75rem;
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            background-color: rgba(10, 12, 16, 0.5);
            color: var(--text-primary);
            cursor: pointer;
            transition: all 0.3s ease;
            font-weight: 500;
        }

        .risk-btn:hover {
            background-color: rgba(0, 255, 255, 0.1);
            border-color: var(--neon-cyan);
        }

        .risk-btn.active {
            background-color: var(--neon-cyan);
            color: var(--bg-primary);
            border-color: var(--neon-cyan);
            box-shadow: 0 0 15px var(--glow-color-cyan);
            font-weight: 600;
        }

        .result-box {
            background-color: rgba(10, 12, 16, 0.5);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: 1.5rem;
            margin-top: 2rem;
            text-align: center;
            cursor: pointer;
            position: relative;
            overflow: hidden;
            transition: all 0.3s ease;
        }
        
        .result-box:hover {
            border-color: var(--neon-cyan);
            background-color: rgba(0, 255, 255, 0.1);
            box-shadow: 0 0 15px var(--glow-color-cyan);
        }

        .result-label {
            color: var(--text-secondary);
            font-size: 0.8rem;
            margin-bottom: 0.5rem;
            text-transform: uppercase;
            letter-spacing: 0.8px;
            font-weight: 500;
        }

        .result-value {
            color: var(--neon-cyan);
            font-size: 2rem;
            font-weight: 700;
            text-shadow: 0 0 5px var(--glow-color-cyan);
        }

        .error-message {
            color: var(--neon-red);
            text-align: center;
            margin: 1rem 0 0 0;
            font-size: 0.9rem;
            display: none;
        }

        .copy-effect {
            position: absolute;
            background: rgba(0, 255, 255, 0.15);
            border-radius: 50%;
            pointer-events: none;
            transform: translate(-50%, -50%) scale(0);
            opacity: 1;
            animation: ripple 0.6s ease-out forwards;
        }

        @keyframes ripple {
            to {
                transform: translate(-50%, -50%) scale(3);
                opacity: 0;
            }
        }

        .hidden-input {
            position: absolute;
            left: -9999px;
            opacity: 0;
            pointer-events: none;
        }

        .form-text {
            color: var(--text-secondary);
            font-size: 0.85rem;
            margin-top: 0.25rem;
        }

        .info-tip {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.85rem;
            color: var(--text-secondary);
            margin-top: 0.5rem;
        }

        .info-icon {
            color: var(--neon-cyan);
            font-size: 0.9rem;
        }

        .page-title {
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 2rem;
            position: relative;
            display: inline-block;
        }
        
        .page-title::after {
            content: '';
            position: absolute;
            bottom: -0.5rem;
            left: 0;
            width: 3rem;
            height: 0.2rem;
            background-color: var(--neon-cyan);
            border-radius: 2px;
            box-shadow: 0 0 10px var(--glow-color-cyan);
        }

        .copied-message {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: rgba(0, 0, 0, 0.8);
            color: var(--neon-green);
            padding: 0.5rem 1rem;
            border-radius: var(--border-radius);
            font-weight: 500;
            opacity: 0;
            pointer-events: none;
            transition: opacity 0.3s ease;
        }
        
        .copied-message.show {
            opacity: 1;
        }
    </style>
</head>
<body>
    <?php 
    $current_page = basename($_SERVER['PHP_SELF']);
    include('navigation.php'); 
    ?>

    <div class="calculator-container">
        <div class="calculator">
            <h1>Position Size Calculator</h1>

            <div class="input-group">
                <label for="wallet" class="input-label">Wallet Balance</label>
                <input type="number" id="wallet" value="<?= htmlspecialchars(number_format($wallet_balance, 2, '.', '')) ?>" readonly>
                <div class="form-text">Your current wallet balance</div>
            </div>

            <div class="input-group">
                <label for="sl_percent" class="input-label">Stop Loss Percentage (%)</label>
                <input type="number" id="sl_percent" placeholder="e.g. 2.5" step="0.01">
                <div class="form-text">Distance from entry to stop loss as percentage</div>
            </div>

            <div class="input-group">
                <label class="input-label">Risk Percentage</label>
                <div class="risk-buttons">
                    <button class="risk-btn active" data-risk="1">1%</button>
                    <button class="risk-btn" data-risk="2">2%</button>
                    <button class="risk-btn" data-risk="3">3%</button>
                    <button class="risk-btn" data-risk="4">4%</button>
                    <button class="risk-btn" data-risk="5">5%</button>
                </div>
                <div class="info-tip">
                    <i class="fas fa-info-circle info-icon"></i>
                    <span>Percentage of your balance you're willing to risk</span>
                </div>
            </div>

            <div class="error-message" id="error">Please fill all fields correctly.</div>

            <div class="result-box" id="resultBox">
                <div class="result-label">Position Size (<?= $currency_symbol ?>) - Click to copy</div>
                <div class="result-value" id="resultValue">0.00</div>
                <div class="copied-message" id="copiedMessage">Copied!</div>
            </div>
        </div>
    </div>

    <input type="text" id="hiddenInput" class="hidden-input">

    <script src="js/theme-switcher.js"></script>
    <script>
        const riskBtns = document.querySelectorAll('.risk-btn');
        const resultBox = document.getElementById('resultBox');
        const hiddenInput = document.getElementById('hiddenInput');
        const walletInput = document.getElementById('wallet');
        const slInput = document.getElementById('sl_percent');
        const errorMsg = document.getElementById('error');
        const resultValueEl = document.getElementById('resultValue');
        const copiedMessage = document.getElementById('copiedMessage');
        let selectedRisk = 1;

        // Initialize calculator
        calculatePosition();

        // Risk button event listeners
        riskBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                riskBtns.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                selectedRisk = parseFloat(btn.dataset.risk);
                calculatePosition();
            });
        });

        // Input event listeners
        slInput.addEventListener('input', calculatePosition);

        // Calculate position size
        function calculatePosition() {
            const wallet = parseFloat(walletInput.value) || 0;
            const slPercent = parseFloat(slInput.value) || 0;

            errorMsg.style.display = 'none';

            if (wallet <= 0 || slPercent <= 0) {
                if (slInput.value !== '') {
                    errorMsg.textContent = 'Wallet and SL % must be positive numbers.';
                    errorMsg.style.display = 'block';
                }
                resultValueEl.textContent = '0.00';
                return;
            }

            const riskAmount = wallet * (selectedRisk / 100);
            const positionSize = riskAmount / (slPercent / 100);

            resultValueEl.textContent = positionSize.toFixed(2);
        }

        // Copy functionality with visual feedback
        resultBox.addEventListener('click', (event) => {
            const textToCopy = resultValueEl.textContent;
            hiddenInput.value = textToCopy;
            hiddenInput.select();
            document.execCommand('copy');

            // Show copied message
            copiedMessage.classList.add('show');
            setTimeout(() => {
                copiedMessage.classList.remove('show');
            }, 1500);

            // Add ripple effect
            const ripple = document.createElement('span');
            ripple.classList.add('copy-effect');
            
            const rect = resultBox.getBoundingClientRect();
            const x = event.clientX - rect.left;
            const y = event.clientY - rect.top;
            
            ripple.style.left = `${x}px`;
            ripple.style.top = `${y}px`;
            
            resultBox.appendChild(ripple);
            
            // Remove ripple after animation completes
            setTimeout(() => {
                ripple.remove();
            }, 600);
        });
    </script>
</body>
</html>
