<?php
// Include MySQL connection
require_once 'db_connect.php';

// Get trade ID from the URL
$trade_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$trade = null; // Initialize trade variable
$currency_symbol = get_currency_symbol();

// Ensure we have a valid database connection
$conn = ensure_db_connection();

if ($trade_id > 0) {
    // Fetch trade details from MySQL
    $sql = "SELECT id, pair, order_type, status, notes, market_conditions, pnl, image, 
            entry, stop_loss, take_profit, position_size, 
            DATE_FORMAT(date, '%Y-%m-%d') as formatted_date 
            FROM trades WHERE id = ?";
    $stmt = $conn->prepare($sql);
    
    if($stmt) {
        $stmt->bind_param("i", $trade_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $trade = $result->fetch_assoc();
        }
        $stmt->close();
    } else {
        error_log("Prepare failed: (" . $conn->errno . ") " . $conn->error);
    }
}

// If no trade found after checks, show error
if ($trade === null) {
    $error_message = "Trade not found or database connection error.";
}

// Calculate Risk-Reward Ratio
$rr_ratio = 'N/A';
if (!empty($trade)) {
    $entry = floatval($trade['entry'] ?? 0);
    $stop_loss = floatval($trade['stop_loss'] ?? 0);
    $take_profit = floatval($trade['take_profit'] ?? 0);
    
    if ($entry > 0 && $stop_loss > 0 && $take_profit > 0) {
        $risk = abs($entry - $stop_loss);
        $reward = abs($take_profit - $entry);
        
        if ($risk > 0) {
            $rr_ratio = round($reward / $risk, 2);
        }
    }
}

// PnL coloring class
$pnl_class = 'neutral';
if (isset($trade['pnl'])) {
    $pnl_value = floatval($trade['pnl']);
    if ($pnl_value > 0) { 
        $pnl_class = 'profit'; 
    } elseif ($pnl_value < 0) { 
        $pnl_class = 'loss'; 
    }
}

// Status class
$status_class = 'status-closed';
if (isset($trade['status'])) {
    $status_lower = strtolower($trade['status']);
    if (strpos($status_lower, 'open') !== false) { 
        $status_class = 'status-open'; 
    } elseif (strpos($status_lower, 'limit') !== false) { 
        $status_class = 'status-limit'; 
    } elseif (isset($trade['pnl'])) {
        $pnl_value = floatval($trade['pnl']);
        if ($pnl_value > 0) { 
            $status_class = 'status-profit'; 
        } elseif ($pnl_value < 0) { 
            $status_class = 'status-loss'; 
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trade Details - <?= isset($trade['pair']) ? htmlspecialchars($trade['pair']) : 'Not Found' ?></title>
    <link rel="icon" type="image/png" href="fav.png">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="themes.css">

    <style>

        body {
            background-color: var(--bg-primary);
            color: var(--text-primary);
            font-family: var(--font-family);
            line-height: 1.6;
        }

        .navbar {
            background-color: var(--bg-secondary);
            border-bottom: 1px solid var(--border-color);
            padding: 0.8rem 0;
        }

        .navbar-brand {
            font-weight: 700;
            font-size: 1.4rem;
            color: var(--neon-cyan);
            text-shadow: 0 0 5px var(--glow-color-cyan);
            display: inline-flex;
            align-items: center;
        }
        .navbar-brand:hover { color: var(--neon-cyan); opacity: 0.9; }

        .navbar-brand svg {
             width: 28px;
             height: 28px;
             margin-right: 8px;
             vertical-align: -0.15em;
        }

        .nav-button {
            color: var(--neon-cyan);
            border: 1px solid var(--neon-cyan);
            background-color: transparent;
            padding: 0.4rem 0.9rem;
            border-radius: var(--border-radius);
            font-weight: 500;
            font-size: 0.9rem;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 0.4rem;
            text-decoration: none;
            margin-left: 0.5rem;
        }
        .nav-button:hover {
            background-color: rgba(0, 255, 255, 0.1);
            box-shadow: 0 0 10px var(--glow-color-cyan);
            color: var(--text-primary);
        }
        .nav-button.primary {
             background-color: var(--neon-cyan);
             color: var(--bg-primary);
             font-weight: 600;
        }
        .nav-button.primary:hover {
              background-color: #00e0e0;
             box-shadow: 0 0 15px var(--glow-color-cyan);
              color: var(--bg-primary);
        }

        .details-header {
            padding: 1.5rem 0;
            border-bottom: 1px solid var(--border-color);
            margin-bottom: 2rem;
            text-align: center;
        }

        .details-pair {
            font-size: 2rem;
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 0.5rem;
        }

        .details-meta {
            font-size: 0.9rem;
            color: var(--text-secondary);
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 1rem;
            flex-wrap: wrap;
        }

        .trade-status {
            font-size: 0.75rem;
            font-weight: 600;
            padding: 0.3rem 0.8rem;
            border-radius: 50px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            border: 1px solid;
        }
        .status-open { color: var(--neon-yellow); border-color: var(--neon-yellow); background-color: rgba(245, 245, 66, 0.1); }
        .status-limit { color: var(--neon-cyan); border-color: var(--neon-cyan); background-color: rgba(0, 255, 255, 0.1); }
        .status-profit { color: var(--neon-green); border-color: var(--neon-green); background-color: rgba(0, 255, 127, 0.1); }
        .status-loss { color: var(--neon-red); border-color: var(--neon-red); background-color: rgba(255, 51, 102, 0.1); }
        .status-closed { color: var(--text-secondary); border-color: var(--text-secondary); background-color: rgba(136, 153, 168, 0.1); }

        .details-image-section {
            margin-bottom: 2rem;
            text-align: center;
        }

        .details-image {
            max-width: 100%;
            height: auto;
            max-height: 60vh;
            border-radius: var(--border-radius);
            cursor: pointer;
            border: 1px solid var(--border-color);
            transition: all 0.3s ease;
        }
        .details-image:hover {
            transform: scale(1.01);
            border-color: var(--neon-cyan);
            box-shadow: 0 0 20px var(--glow-color-cyan);
        }

        .no-image-placeholder {
            background-color: var(--bg-secondary);
            border: 1px dashed var(--border-color);
            border-radius: var(--border-radius);
            height: 300px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--text-secondary);
        }

        .details-card {
            background-color: var(--bg-secondary);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: 1.5rem 2rem;
            margin-bottom: 2rem;
            transition: all 0.3s ease;
        }

        .details-card:hover {
            box-shadow: 0 0 15px rgba(0, 255, 255, 0.1);
            border-color: rgba(0, 255, 255, 0.4);
        }

        .details-card h5 {
            font-weight: 600;
            color: var(--neon-cyan);
            margin-bottom: 1.5rem;
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 0.75rem;
            text-shadow: 0 0 3px var(--glow-color-cyan);
        }

        .detail-item {
            margin-bottom: 1rem;
        }

        .detail-label {
            font-size: 0.8rem;
            color: var(--text-secondary);
            margin-bottom: 0.25rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-weight: 500;
        }

        .detail-value {
            font-size: 1rem;
            color: var(--text-primary);
            word-wrap: break-word;
            line-height: 1.5;
        }

        .detail-value.pnl-profit { color: var(--neon-green); font-weight: 600; }
        .detail-value.pnl-loss { color: var(--neon-red); font-weight: 600; }
        .detail-value.pnl-neutral { color: var(--text-secondary); }

        .detail-value pre {
            background-color: rgba(10, 12, 16, 0.5);
            padding: 0.75rem;
            border-radius: var(--border-radius);
            color: var(--text-primary);
            font-size: 0.9rem;
            white-space: pre-wrap;
            word-wrap: break-word;
            border: 1px solid var(--border-color);
        }

        .action-buttons {
            display: flex;
            gap: 1rem;
            margin-top: 2rem;
            justify-content: flex-end;
        }
        
        .action-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            padding: 0.6rem 1.2rem;
            font-weight: 600;
            border-radius: var(--border-radius);
            transition: all 0.3s ease;
            cursor: pointer;
            text-decoration: none;
            font-size: 0.95rem;
        }
        
        .btn-edit {
            background-color: rgba(0, 255, 255, 0.1);
            color: var(--neon-cyan);
            border: 1px solid var(--neon-cyan);
        }
        
        .btn-edit:hover {
            background-color: var(--neon-cyan);
            color: var(--bg-primary);
            box-shadow: 0 0 15px var(--glow-color-cyan);
        }
        
        .btn-delete {
            background-color: rgba(255, 51, 102, 0.1);
            color: var(--neon-red);
            border: 1px solid var(--neon-red);
        }
        
        .btn-delete:hover {
            background-color: var(--neon-red);
            color: var(--bg-primary);
            box-shadow: 0 0 15px var(--glow-color-red);
        }

        /* Modal styling */
        .modal-content {
            background-color: var(--bg-secondary);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
        }
        .modal-header {
            border-bottom: 1px solid var(--border-color);
            color: var(--text-primary);
        }
        .modal-title {
            color: var(--text-primary);
            font-weight: 600;
        }
        .modal-body {
            color: var(--text-primary);
        }
        .btn-close {
            color: var(--text-primary);
            filter: invert(1);
        }
        #imageModal .modal-dialog {
            max-width: 90vw;
            margin: 1.75rem auto;
        }
        #imageModal img {
            max-width: 100%;
            max-height: 85vh;
            display: block;
            margin: auto;
            border-radius: var(--border-radius);
        }

        .error-container {
            background-color: var(--bg-secondary);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: 3rem 2rem;
            text-align: center;
            margin-top: 2rem;
        }
        .error-icon {
            font-size: 3rem;
            color: var(--neon-red);
            margin-bottom: 1.5rem;
            opacity: 0.7;
        }
        .error-message {
            color: var(--text-primary);
            font-size: 1.2rem;
            margin-bottom: 2rem;
        }
    </style>
</head>
<body>
    <?php 
    $current_page = basename($_SERVER['PHP_SELF']);
    include('navigation.php'); 
    ?>

    <div class="container my-4">
        <?php if (isset($error_message)): ?>
            <div class="error-container">
                <div class="error-icon">
                    <i class="fas fa-exclamation-triangle"></i>
                </div>
                <div class="error-message">
                    <?= htmlspecialchars($error_message) ?>
                </div>
                <a href="index.php" class="nav-button">
                    <i class="fas fa-arrow-left me-2"></i>Back to Dashboard
                </a>
            </div>
        <?php else: ?>
            <div class="details-header">
                <div class="details-pair"><?= htmlspecialchars($trade['pair']) ?></div>
                <div class="details-meta">
                    <span><?= htmlspecialchars($trade['order_type']) ?></span>
                    <span class="trade-status <?= $status_class ?>">
                        <?= htmlspecialchars($trade['status']) ?>
                    </span>
                    <span><?= htmlspecialchars($trade['formatted_date']) ?></span>
                </div>
            </div>

            <?php if (!empty($trade['image'])): ?>
            <div class="details-image-section">
                <img src="<?= htmlspecialchars($trade['image']) ?>" 
                     alt="Trade chart for <?= htmlspecialchars($trade['pair']) ?>" 
                     class="details-image" 
                     data-bs-toggle="modal" 
                     data-bs-target="#imageModal"
                     title="Click to zoom image">
            </div>
            <?php else: ?>
            <div class="details-image-section">
                <div class="no-image-placeholder">
                    <p>No Chart Image Available</p>
                </div>
            </div>
            <?php endif; ?>

            <div class="row">
                <div class="col-lg-7">
                    <div class="details-card mb-4">
                        <h5>Trade Metrics</h5>
                        <div class="row">
                            <div class="col-md-4 col-6 mb-3">
                                <div class="detail-label">Entry Price</div>
                                <div class="detail-value"><?= htmlspecialchars($trade['entry'] ?? 'N/A') ?></div>
                            </div>
                            <div class="col-md-4 col-6 mb-3">
                                <div class="detail-label">Stop Loss</div>
                                <div class="detail-value"><?= htmlspecialchars($trade['stop_loss'] ?? 'N/A') ?></div>
                            </div>
                            <div class="col-md-4 col-12 mb-3">
                                <div class="detail-label">Take Profit</div>
                                <div class="detail-value"><?= htmlspecialchars($trade['take_profit'] ?? 'N/A') ?></div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4 col-6 mb-3">
                                <div class="detail-label">Position Size</div>
                                <div class="detail-value"><?= !empty($trade['position_size']) ? htmlspecialchars($trade['position_size']) : 'N/A' ?></div>
                            </div>
                            <div class="col-md-4 col-6 mb-3">
                                <div class="detail-label">Risk/Reward Ratio</div>
                                <div class="detail-value"><?= $rr_ratio ?></div>
                            </div>
                            <div class="col-md-4 col-12 mb-3">
                                <div class="detail-label">Profit/Loss</div>
                                <div class="detail-value pnl-<?= $pnl_class ?>">
                                    <?= $currency_symbol . number_format(floatval($trade['pnl']), 2) ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <?php if (!empty($trade['notes']) || !empty($trade['market_conditions'])): ?>
                    <div class="details-card">
                        <h5>Analysis & Notes</h5>
                        
                        <?php if (!empty($trade['notes'])): ?>
                        <div class="detail-item">
                            <div class="detail-label">Trade Notes</div>
                            <div class="detail-value">
                                <pre><?= htmlspecialchars($trade['notes']) ?></pre>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if (!empty($trade['market_conditions'])): ?>
                        <div class="detail-item">
                            <div class="detail-label">Market Conditions</div>
                            <div class="detail-value">
                                <pre><?= htmlspecialchars($trade['market_conditions']) ?></pre>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                </div>

                <div class="col-lg-5">
                    <div class="details-card">
                        <h5>Trade Summary</h5>
                        <div class="detail-item">
                            <div class="detail-label">Trading Pair</div>
                            <div class="detail-value"><?= htmlspecialchars($trade['pair']) ?></div>
                        </div>
                        <div class="detail-item">
                            <div class="detail-label">Order Type</div>
                            <div class="detail-value"><?= htmlspecialchars($trade['order_type']) ?></div>
                        </div>
                        <div class="detail-item">
                            <div class="detail-label">Status</div>
                            <div class="detail-value">
                                <span class="trade-status <?= $status_class ?>">
                                    <?= htmlspecialchars($trade['status']) ?>
                                </span>
                            </div>
                        </div>
                        <div class="detail-item">
                            <div class="detail-label">Date</div>
                            <div class="detail-value"><?= htmlspecialchars($trade['formatted_date']) ?></div>
                        </div>
                        
                        <div class="action-buttons">
                            <a href="edit_trade.php?id=<?= $trade['id'] ?>" class="action-btn btn-edit">
                                <i class="fas fa-edit"></i>Edit Trade
                            </a>
                            <button type="button" class="action-btn btn-delete" data-bs-toggle="modal" data-bs-target="#deleteModal">
                                <i class="fas fa-trash"></i>Delete
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Image Modal -->
            <div class="modal fade" id="imageModal" tabindex="-1" aria-labelledby="imageModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-xl">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="imageModalLabel"><?= htmlspecialchars($trade['pair']) ?> Chart</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <?php if (!empty($trade['image'])): ?>
                                <img src="<?= htmlspecialchars($trade['image']) ?>" alt="Full size chart">
                            <?php else: ?>
                                <p class="text-center">No image available</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Delete Confirmation Modal -->
            <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="deleteModalLabel">Confirm Delete</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            Are you sure you want to delete this trade? This action cannot be undone.
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="action-btn" style="background-color: transparent; border: 1px solid var(--border-color); color: var(--text-primary);" data-bs-dismiss="modal">Cancel</button>
                            <form action="index.php" method="post">
                                <input type="hidden" name="trade_id" value="<?= $trade['id'] ?>">
                                <button type="submit" name="delete_trade" class="action-btn btn-delete">Confirm Delete</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script src="js/main.js"></script>
    <script src="js/theme-switcher.js"></script>
</body>
</html>
