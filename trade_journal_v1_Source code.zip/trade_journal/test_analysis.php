<?php
// Include database connection
include('db_connect.php');

// Set the timezone
date_default_timezone_set('UTC');

echo "<h1>Analysis Testing Utility</h1>";
echo "<p>This script verifies that the day/time heatmap and calendar features will work correctly.</p>";

// Check database structure
echo "<h2>Database Schema Check</h2>";

$sql = "DESCRIBE trades";
$result = $conn->query($sql);

if ($result) {
    echo "<h3>Trades Table Structure:</h3>";
    echo "<pre>";
    
    $phase1_fields = ['strategy', 'emotion', 'confidence_rating', 'market_context', 'lessons_learned'];
    $found_fields = [];
    
    while ($row = $result->fetch_assoc()) {
        echo $row['Field'] . " - " . $row['Type'] . "\n";
        $found_fields[] = $row['Field'];
    }
    
    echo "</pre>";
    
    // Check if Phase 1 fields exist
    echo "<h3>Phase 1 Fields Check:</h3>";
    $missing_fields = [];
    foreach ($phase1_fields as $field) {
        if (in_array($field, $found_fields)) {
            echo "<div style='color:green'>✓ Field '{$field}' exists</div>";
        } else {
            echo "<div style='color:red'>✗ Field '{$field}' is missing</div>";
            $missing_fields[] = $field;
        }
    }
    
    if (!empty($missing_fields)) {
        echo "<p>Missing Phase 1 fields. Please run the database upgrade script.</p>";
    }
} else {
    echo "<p>Error querying database structure: " . $conn->error . "</p>";
}

// Test data for heatmap
echo "<h2>Sample Day/Time Heatmap Data</h2>";

$sql = "SELECT 
        DATE_FORMAT(date, '%w') as day_of_week,
        DATE_FORMAT(date, '%H') as hour_of_day,
        COUNT(*) as count,
        SUM(CASE WHEN pnl > 0 THEN 1 ELSE 0 END) as win_count,
        SUM(CASE WHEN pnl < 0 THEN 1 ELSE 0 END) as loss_count,
        SUM(pnl) as total_pnl
        FROM trades
        GROUP BY day_of_week, hour_of_day
        ORDER BY day_of_week, hour_of_day";

$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    $heatmap_data = [];
    
    while ($row = $result->fetch_assoc()) {
        $day = intval($row['day_of_week']);
        $hour = intval($row['hour_of_day']);
        
        if (!isset($heatmap_data[$day])) {
            $heatmap_data[$day] = [];
        }
        
        $heatmap_data[$day][$hour] = [
            'count' => $row['count'],
            'win_count' => $row['win_count'],
            'loss_count' => $row['loss_count'],
            'pnl' => $row['total_pnl']
        ];
    }
    
    // Display sample data
    echo "<h3>Sample Heatmap Data:</h3>";
    echo "<pre>";
    $days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    
    foreach ($heatmap_data as $day => $hours) {
        echo $days[$day] . ":\n";
        foreach ($hours as $hour => $data) {
            echo "  " . sprintf('%02d', $hour) . ":00 - Trades: {$data['count']}, Win/Loss: {$data['win_count']}/{$data['loss_count']}, PnL: {$data['pnl']}\n";
        }
        echo "\n";
    }
    echo "</pre>";
} else {
    echo "<p>No day/time data available or error executing query: " . $conn->error . "</p>";
}

// Test calendar data
echo "<h2>Sample Calendar Data</h2>";

$sql = "SELECT 
        DATE_FORMAT(date, '%Y-%m-%d') as trade_date,
        COUNT(*) as count,
        SUM(CASE WHEN pnl > 0 THEN 1 ELSE 0 END) as win_count,
        SUM(CASE WHEN pnl < 0 THEN 1 ELSE 0 END) as loss_count,
        SUM(pnl) as total_pnl
        FROM trades
        GROUP BY trade_date
        ORDER BY trade_date DESC
        LIMIT 10";

$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    echo "<h3>Recent Trading Days:</h3>";
    echo "<pre>";
    
    while ($row = $result->fetch_assoc()) {
        echo $row['trade_date'] . " - Trades: {$row['count']}, Win/Loss: {$row['win_count']}/{$row['loss_count']}, PnL: {$row['total_pnl']}\n";
    }
    
    echo "</pre>";
} else {
    echo "<p>No calendar data available or error executing query: " . $conn->error . "</p>";
}

// Test Phase 1 data collection
echo "<h2>Phase 1 Data Analysis</h2>";

// Check strategy data
echo "<h3>Strategy Distribution:</h3>";
$sql = "SELECT strategy, COUNT(*) as count, SUM(pnl) as total_pnl 
        FROM trades 
        WHERE strategy IS NOT NULL AND strategy != '' 
        GROUP BY strategy 
        ORDER BY count DESC";

$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    echo "<pre>";
    while ($row = $result->fetch_assoc()) {
        echo $row['strategy'] . " - Trades: {$row['count']}, PnL: {$row['total_pnl']}\n";
    }
    echo "</pre>";
} else {
    echo "<p>No strategy data available or error executing query: " . $conn->error . "</p>";
}

// Check emotion data
echo "<h3>Emotion Analysis:</h3>";
$sql = "SELECT emotion, COUNT(*) as count, SUM(pnl) as total_pnl 
        FROM trades 
        WHERE emotion IS NOT NULL AND emotion != '' 
        GROUP BY emotion 
        ORDER BY count DESC";

$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    echo "<pre>";
    while ($row = $result->fetch_assoc()) {
        echo $row['emotion'] . " - Trades: {$row['count']}, PnL: {$row['total_pnl']}\n";
    }
    echo "</pre>";
} else {
    echo "<p>No emotion data available or error executing query: " . $conn->error . "</p>";
}

// Check confidence rating distribution
echo "<h3>Confidence Rating Distribution:</h3>";
$sql = "SELECT confidence_rating, COUNT(*) as count, SUM(pnl) as total_pnl 
        FROM trades 
        WHERE confidence_rating IS NOT NULL 
        GROUP BY confidence_rating 
        ORDER BY confidence_rating";

$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    echo "<pre>";
    while ($row = $result->fetch_assoc()) {
        echo "Rating {$row['confidence_rating']} - Trades: {$row['count']}, PnL: {$row['total_pnl']}\n";
    }
    echo "</pre>";
} else {
    echo "<p>No confidence rating data available or error executing query: " . $conn->error . "</p>";
}

echo "<p><a href='analysis.php'>Go to Analysis Page</a></p>";
?>