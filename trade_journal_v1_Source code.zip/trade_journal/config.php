<?php
/**
 * Trade Journal Configuration File
 * 
 * This file is generated during the installation process
 * Do not edit manually unless you know what you're doing
 */

// Installation status
if (!defined('INSTALLED')) define('INSTALLED', false);

// Database configuration
if (!defined('DB_HOST')) define('DB_HOST', '');
if (!defined('DB_USER')) define('DB_USER', '');
if (!defined('DB_PASS')) define('DB_PASS', '');
if (!defined('DB_NAME')) define('DB_NAME', '');

// Initial settings
if (!defined('CURRENCY_SYMBOL')) define('CURRENCY_SYMBOL', '$');
if (!defined('INITIAL_CAPITAL')) define('INITIAL_CAPITAL', '1000');

// User account
if (!defined('USERNAME')) define('USERNAME', '');
if (!defined('PASSWORD')) define('PASSWORD', ''); 

?>