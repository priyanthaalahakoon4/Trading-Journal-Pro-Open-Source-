<?php
/**
 * Logout Page for Trade Journal
 */
// Prevent any output before headers are sent
ob_start();

include_once 'auth.php';

// Log user out
logout();
?>