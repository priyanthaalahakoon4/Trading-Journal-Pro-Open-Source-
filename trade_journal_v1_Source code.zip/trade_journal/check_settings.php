<?php
// Include database connection
require_once 'db_connect.php';

// Ensure we have a connection
$conn = ensure_db_connection();

// Get settings
echo "Database Settings:\n";
echo "=================\n";
echo "Initial Capital: " . get_setting('initial_capital', 'Not found') . "\n";
echo "Currency Symbol: " . get_setting('currency_symbol', 'Not found') . "\n";
echo "\n";

// Config constants
echo "Config Constants:\n";
echo "===============\n";
echo "INITIAL_CAPITAL: " . (defined('INITIAL_CAPITAL') ? INITIAL_CAPITAL : 'Not defined') . "\n";
echo "CURRENCY_SYMBOL: " . (defined('CURRENCY_SYMBOL') ? CURRENCY_SYMBOL : 'Not defined') . "\n";
echo "\n";

// Get functions
echo "Function Results:\n";
echo "===============\n";
echo "get_initial_capital(): " . get_initial_capital() . "\n";
echo "get_currency_symbol(): " . get_currency_symbol() . "\n";
echo "get_wallet_balance(): " . get_wallet_balance() . "\n";
?>