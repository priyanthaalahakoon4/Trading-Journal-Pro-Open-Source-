<?php
/**
 * Authentication functions for Trade Journal
 */

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

/**
 * Check if user is logged in
 * @return bool True if logged in, false otherwise
 */
function is_logged_in() {
    return isset($_SESSION['user_logged_in']) && $_SESSION['user_logged_in'] === true;
}

/**
 * Check if the application is installed
 * @return bool True if installed, false otherwise
 */
function is_installed() {
    if (file_exists('config.php')) {
        // Include config file but suppress any warnings/notices
        @include_once 'config.php';
        return defined('INSTALLED') && INSTALLED === true;
    }
    return false;
}

/**
 * Redirect to installation if not installed
 */
function require_installation() {
    if (!is_installed() && basename($_SERVER['PHP_SELF']) !== 'install.php') {
        header('Location: install.php');
        exit;
    }
}

/**
 * Redirect to login if not logged in
 */
function require_login() {
    if (!is_logged_in() && basename($_SERVER['PHP_SELF']) !== 'login.php' && basename($_SERVER['PHP_SELF']) !== 'install.php') {
        header('Location: login.php');
        exit;
    }
}

/**
 * Authenticate user
 * @param string $username Username
 * @param string $password Plain text password
 * @return bool True if authenticated, false otherwise
 */
function authenticate($username, $password) {
    // Include config file but suppress any warnings/notices
    @include_once 'config.php';
    
    if (defined('USERNAME') && defined('PASSWORD')) {
        // Verify username and password hash
        if ($username === USERNAME && password_verify($password, PASSWORD)) {
            $_SESSION['user_logged_in'] = true;
            return true;
        }
    }
    
    return false;
}

/**
 * Log out user
 */
function logout() {
    $_SESSION = array();
    session_destroy();
    
    // Redirect to login page
    header('Location: login.php');
    exit;
}
?>