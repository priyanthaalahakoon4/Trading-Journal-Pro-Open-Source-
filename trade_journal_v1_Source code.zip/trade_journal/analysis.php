<?php
include('db_connect.php');

// Get wallet information
$start_wallet = get_initial_capital();
$current_wallet = get_wallet_balance();
$currency_symbol = get_currency_symbol();

// Set the timezone to ensure correct day of week calculations
date_default_timezone_set('UTC');

// Initialize statistics
$total_pnl = 0;
$total_win = 0;
$total_loss = 0;
$total_trades = 0;
$positive_trades = 0;
$average_win = 0;
$average_loss = 0;
$win_streak = 0;
$loss_streak = 0;
$current_streak = 0;
$best_win_streak = 0;
$worst_loss_streak = 0;
$trades_data = [];
$pairs_data = [];
$monthly_data = [];

// Data for day/time heatmap
$day_hour_data = [];
for ($day = 0; $day < 7; $day++) {
    for ($hour = 0; $hour < 24; $hour++) {
        $day_hour_data[$day][$hour] = [
            'count' => 0,
            'win_count' => 0,
            'loss_count' => 0,
            'pnl' => 0
        ];
    }
}

// Data for calendar view
$calendar_data = [];

// Data for emotion analysis
$emotion_data = [];
$strategy_data = [];
$market_context_data = [];

// Apply filters
$filter_pair = isset($_GET['pair']) ? sanitize_input($_GET['pair']) : '';
$filter_outcome = isset($_GET['outcome']) ? sanitize_input($_GET['outcome']) : '';
$filter_start_date = isset($_GET['start_date']) ? sanitize_input($_GET['start_date']) : '';
$filter_end_date = isset($_GET['end_date']) ? sanitize_input($_GET['end_date']) : '';
$filter_order_type = isset($_GET['order_type']) ? sanitize_input($_GET['order_type']) : '';

// Build query with filters
$sql = "SELECT id, pair, pnl, order_type, status, 
        entry, stop_loss, take_profit, position_size, 
        DATE_FORMAT(date, '%Y-%m-%d') as formatted_date,
        DATE_FORMAT(date, '%Y-%m') as month_year,
        DATE_FORMAT(date, '%w') as day_of_week,
        DATE_FORMAT(date, '%H') as hour_of_day,
        strategy, emotion, confidence_rating, market_context
        FROM trades WHERE 1=1";

$params = [];
$types = "";

if (!empty($filter_pair)) {
    $sql .= " AND pair LIKE ?";
    $filter_pair = "%$filter_pair%";
    $params[] = $filter_pair;
    $types .= "s";
}

if (!empty($filter_outcome)) {
    if ($filter_outcome === 'win') {
        $sql .= " AND pnl > 0";
    } elseif ($filter_outcome === 'loss') {
        $sql .= " AND pnl < 0";
    } elseif ($filter_outcome === 'breakeven') {
        $sql .= " AND pnl = 0";
    }
}

if (!empty($filter_start_date)) {
    $sql .= " AND date >= ?";
    $params[] = $filter_start_date;
    $types .= "s";
}

if (!empty($filter_end_date)) {
    $sql .= " AND date <= ?";
    $params[] = $filter_end_date . ' 23:59:59';
    $types .= "s";
}

if (!empty($filter_order_type)) {
    $sql .= " AND order_type = ?";
    $params[] = $filter_order_type;
    $types .= "s";
}

$sql .= " ORDER BY date DESC";

// Fetch trades
$stmt = $conn->prepare($sql);

if ($stmt) {
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $last_trade_pnl = 0;
        
        while ($trade = $result->fetch_assoc()) {
            $trades_data[] = $trade;
            $pnl = floatval($trade['pnl']);

            // Aggregate statistics
            $total_pnl += $pnl;
            $total_trades++;

            // Win/loss tracking
            if ($pnl > 0) {
                $total_win += $pnl;
                $positive_trades++;
                
                // Streak tracking
                if ($current_streak >= 0) {
                    $current_streak++;
                } else {
                    $current_streak = 1;
                }
                
                if ($current_streak > $best_win_streak) {
                    $best_win_streak = $current_streak;
                }
            } elseif ($pnl < 0) {
                $total_loss += $pnl;
                
                // Streak tracking
                if ($current_streak <= 0) {
                    $current_streak--;
                } else {
                    $current_streak = -1;
                }
                
                if ($current_streak < $worst_loss_streak) {
                    $worst_loss_streak = $current_streak;
                }
            }
            
            // Track by trading pair
            $pair = $trade['pair'];
            if (!isset($pairs_data[$pair])) {
                $pairs_data[$pair] = [
                    'total' => 0,
                    'wins' => 0,
                    'losses' => 0,
                    'pnl' => 0
                ];
            }
            
            $pairs_data[$pair]['total']++;
            if ($pnl > 0) {
                $pairs_data[$pair]['wins']++;
            } elseif ($pnl < 0) {
                $pairs_data[$pair]['losses']++;
            }
            $pairs_data[$pair]['pnl'] += $pnl;
            
            // Track by month
            $month_year = $trade['month_year'];
            if (!isset($monthly_data[$month_year])) {
                $monthly_data[$month_year] = [
                    'total' => 0,
                    'wins' => 0,
                    'losses' => 0,
                    'pnl' => 0
                ];
            }
            
            $monthly_data[$month_year]['total']++;
            if ($pnl > 0) {
                $monthly_data[$month_year]['wins']++;
            } elseif ($pnl < 0) {
                $monthly_data[$month_year]['losses']++;
            }
            $monthly_data[$month_year]['pnl'] += $pnl;
            
            // Process day/time data for heatmap
            if (isset($trade['day_of_week']) && isset($trade['hour_of_day'])) {
                $day = intval($trade['day_of_week']);
                $hour = intval($trade['hour_of_day']);
                
                // Increment count
                $day_hour_data[$day][$hour]['count']++;
                $day_hour_data[$day][$hour]['pnl'] += $pnl;
                
                // Track wins/losses
                if ($pnl > 0) {
                    $day_hour_data[$day][$hour]['win_count']++;
                } elseif ($pnl < 0) {
                    $day_hour_data[$day][$hour]['loss_count']++;
                }
            }
            
            // Process calendar data
            $date = $trade['formatted_date'];
            if (!isset($calendar_data[$date])) {
                $calendar_data[$date] = [
                    'count' => 0,
                    'win_count' => 0,
                    'loss_count' => 0,
                    'pnl' => 0
                ];
            }
            $calendar_data[$date]['count']++;
            $calendar_data[$date]['pnl'] += $pnl;
            if ($pnl > 0) {
                $calendar_data[$date]['win_count']++;
            } elseif ($pnl < 0) {
                $calendar_data[$date]['loss_count']++;
            }
            
            // Process emotion data
            if (!empty($trade['emotion'])) {
                $emotion = $trade['emotion'];
                if (!isset($emotion_data[$emotion])) {
                    $emotion_data[$emotion] = [
                        'count' => 0,
                        'win_count' => 0,
                        'loss_count' => 0,
                        'pnl' => 0
                    ];
                }
                $emotion_data[$emotion]['count']++;
                $emotion_data[$emotion]['pnl'] += $pnl;
                if ($pnl > 0) {
                    $emotion_data[$emotion]['win_count']++;
                } elseif ($pnl < 0) {
                    $emotion_data[$emotion]['loss_count']++;
                }
            }
            
            // Process strategy data
            if (!empty($trade['strategy'])) {
                $strategy = $trade['strategy'];
                if (!isset($strategy_data[$strategy])) {
                    $strategy_data[$strategy] = [
                        'count' => 0,
                        'win_count' => 0,
                        'loss_count' => 0,
                        'pnl' => 0
                    ];
                }
                $strategy_data[$strategy]['count']++;
                $strategy_data[$strategy]['pnl'] += $pnl;
                if ($pnl > 0) {
                    $strategy_data[$strategy]['win_count']++;
                } elseif ($pnl < 0) {
                    $strategy_data[$strategy]['loss_count']++;
                }
            }
            
            // Process market context data
            if (!empty($trade['market_context'])) {
                $context = $trade['market_context'];
                if (!isset($market_context_data[$context])) {
                    $market_context_data[$context] = [
                        'count' => 0,
                        'win_count' => 0,
                        'loss_count' => 0,
                        'pnl' => 0
                    ];
                }
                $market_context_data[$context]['count']++;
                $market_context_data[$context]['pnl'] += $pnl;
                if ($pnl > 0) {
                    $market_context_data[$context]['win_count']++;
                } elseif ($pnl < 0) {
                    $market_context_data[$context]['loss_count']++;
                }
            }
        }
        
        // Calculate averages
        $average_win = $positive_trades > 0 ? $total_win / $positive_trades : 0;
        $average_loss = ($total_trades - $positive_trades) > 0 ? abs($total_loss) / ($total_trades - $positive_trades) : 0;
    }
    
    $stmt->close();
}

// Calculate win rate
$win_rate = ($total_trades > 0) ? number_format(($positive_trades / $total_trades) * 100, 1) : 0;

// Sort pairs by PnL
if (!empty($pairs_data)) {
    uasort($pairs_data, function($a, $b) {
        return $b['pnl'] <=> $a['pnl'];
    });
}

// Sort months chronologically
if (!empty($monthly_data)) {
    ksort($monthly_data);
}

// Sort calendar data chronologically
if (!empty($calendar_data)) {
    ksort($calendar_data);
}

// Sort emotion, strategy, and market context data by PnL
if (!empty($emotion_data)) {
    uasort($emotion_data, function($a, $b) {
        return $b['pnl'] <=> $a['pnl']; 
    });
}

if (!empty($strategy_data)) {
    uasort($strategy_data, function($a, $b) {
        return $b['pnl'] <=> $a['pnl'];
    });
}

if (!empty($market_context_data)) {
    uasort($market_context_data, function($a, $b) {
        return $b['pnl'] <=> $a['pnl'];
    });
}

// Get unique pairs and order types for filter dropdowns
$pairs = [];
$order_types = [];

$sql = "SELECT DISTINCT pair FROM trades ORDER BY pair";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $pairs[] = $row['pair'];
    }
}

$sql = "SELECT DISTINCT order_type FROM trades ORDER BY order_type";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $order_types[] = $row['order_type'];
    }
}

// Format numbers with currency symbol
function format_money($amount) {
    global $currency_symbol;
    $formatted = $currency_symbol . number_format(abs($amount), 2);
    return $amount < 0 ? "-" . $formatted : $formatted;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trade Analysis - Trade Journal</title>
    <link rel="icon" type="image/png" href="fav.png">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        :root {
            --bg-primary: #0a0c10;
            --bg-secondary: #141821;
            --border-color: rgba(0, 255, 255, 0.2);
            --text-primary: #e6f1ff;
            --text-secondary: #8899a8;
            --neon-cyan: #00ffff;
            --neon-green: #00ff7f;
            --neon-red: #ff3366;
            --neon-yellow: #f5f542;
            --glow-color-cyan: rgba(0, 255, 255, 0.4);
            --glow-color-green: rgba(0, 255, 127, 0.4);
            --glow-color-red: rgba(255, 51, 102, 0.4);
            --border-radius: 8px;
            --font-family: 'Inter', sans-serif;
        }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        body {
            background-color: var(--bg-primary);
            color: var(--text-primary);
            font-family: var(--font-family);
            line-height: 1.6;
        }

        .navbar {
            background-color: var(--bg-secondary);
            border-bottom: 1px solid var(--border-color);
            padding: 0.8rem 0;
            animation: fadeInUp 0.5s ease-out;
        }

        .navbar-brand {
            font-weight: 700;
            font-size: 1.4rem;
            color: var(--neon-cyan);
            text-shadow: 0 0 5px var(--glow-color-cyan);
            display: inline-flex;
            align-items: center;
        }
        .navbar-brand:hover { color: var(--neon-cyan); opacity: 0.9; }

        .navbar-brand svg {
             width: 28px;
             height: 28px;
             margin-right: 8px;
             vertical-align: -0.15em;
        }

        .nav-button {
            color: var(--neon-cyan);
            border: 1px solid var(--neon-cyan);
            background-color: transparent;
            padding: 0.4rem 0.9rem;
            border-radius: var(--border-radius);
            font-weight: 500;
            font-size: 0.9rem;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 0.4rem;
            text-decoration: none;
            margin-left: 0.5rem;
        }
        .nav-button:hover {
            background-color: rgba(0, 255, 255, 0.1);
            box-shadow: 0 0 10px var(--glow-color-cyan);
            color: var(--text-primary);
        }
        .nav-button.primary {
             background-color: var(--neon-cyan);
             color: var(--bg-primary);
             font-weight: 600;
        }
        .nav-button.primary:hover {
              background-color: #00e0e0;
             box-shadow: 0 0 15px var(--glow-color-cyan);
              color: var(--bg-primary);
        }

        .page-title {
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 2rem;
            position: relative;
            display: inline-block;
        }
        
        .page-title::after {
            content: '';
            position: absolute;
            bottom: -0.5rem;
            left: 0;
            width: 3rem;
            height: 0.2rem;
            background-color: var(--neon-cyan);
            border-radius: 2px;
            box-shadow: 0 0 10px var(--glow-color-cyan);
        }

        .stats-card {
            background-color: var(--bg-secondary);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            transition: all 0.3s ease;
            height: 100%;
        }

        .stats-card:hover {
            transform: translateY(-5px);
            border-color: var(--neon-cyan);
            box-shadow: 0 0 15px var(--glow-color-cyan);
        }

        .stats-title {
            font-size: 1rem;
            color: var(--text-secondary);
            margin-bottom: 1rem;
            text-transform: uppercase;
            letter-spacing: 1px;
            font-weight: 600;
        }

        .stats-value {
            font-size: 2rem;
            font-weight: 700;
            color: var(--neon-cyan);
            text-shadow: 0 0 5px var(--glow-color-cyan);
        }
        .stats-value.profit { color: var(--neon-green); text-shadow: 0 0 5px var(--glow-color-green); }
        .stats-value.loss { color: var(--neon-red); text-shadow: 0 0 5px var(--glow-color-red); }

        .stats-icon {
            font-size: 1.5rem;
            float: right;
            color: var(--text-secondary);
            opacity: 0.7;
        }

        .filter-card {
            background-color: var(--bg-secondary);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: 1.5rem;
            margin-bottom: 2rem;
        }

        .filter-title {
            font-size: 1.1rem;
            color: var(--text-primary);
            margin-bottom: 1rem;
            font-weight: 600;
        }

        .form-label {
            color: var(--text-primary);
            font-weight: 500;
        }

        .form-control, .form-select {
            background-color: rgba(10, 12, 16, 0.5);
            border: 1px solid var(--border-color);
            color: var(--text-primary);
            border-radius: var(--border-radius);
        }

        .form-control:focus, .form-select:focus {
            background-color: rgba(10, 12, 16, 0.7);
            border-color: var(--neon-cyan);
            box-shadow: 0 0 0 0.25rem rgba(0, 255, 255, 0.2);
            color: var(--text-primary);
        }

        .table-container {
            background-color: var(--bg-secondary);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: 1.5rem;
            margin-bottom: 2rem;
            overflow-x: auto;
        }

        .table {
            color: var(--text-primary);
        }

        .table thead th {
            border-bottom: 2px solid var(--border-color);
            color: var(--text-secondary);
            font-weight: 600;
            text-transform: uppercase;
            font-size: 0.85rem;
            letter-spacing: 0.5px;
        }

        .table tbody tr {
            border-bottom: 1px solid rgba(0, 255, 255, 0.1);
            transition: all 0.2s ease;
        }

        .table tbody tr:hover {
            background-color: rgba(0, 255, 255, 0.05);
        }

        .table td {
            vertical-align: middle;
        }

        .pnl-value.profit { color: var(--neon-green); }
        .pnl-value.loss { color: var(--neon-red); }
        
        .trade-status {
            font-size: 0.75rem;
            font-weight: 600;
            padding: 0.3rem 0.8rem;
            border-radius: 50px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            border: 1px solid;
            display: inline-block;
        }
        .status-open { color: var(--neon-yellow); border-color: var(--neon-yellow); background-color: rgba(245, 245, 66, 0.1); }
        .status-limit { color: var(--neon-cyan); border-color: var(--neon-cyan); background-color: rgba(0, 255, 255, 0.1); }
        .status-closed { color: var(--text-secondary); border-color: var(--text-secondary); background-color: rgba(136, 153, 168, 0.1); }

        .chart-container {
            background-color: var(--bg-secondary);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: 1.5rem;
            margin-bottom: 2rem;
            height: 300px;
        }

        .chart-title {
            font-size: 1.1rem;
            color: var(--text-primary);
            margin-bottom: 1rem;
            font-weight: 600;
            text-align: center;
        }

        .empty-state {
            background-color: var(--bg-secondary);
            border: 1px dashed var(--border-color);
            border-radius: var(--border-radius);
            padding: 3rem 1rem;
            text-align: center;
            margin-top: 1rem;
        }
        .empty-state-icon {
            font-size: 3rem;
            color: var(--text-secondary);
            margin-bottom: 1rem;
            opacity: 0.6;
        }
        .empty-state-text {
            color: var(--text-secondary);
            font-size: 1.1rem;
            margin-bottom: 1.5rem;
        }

        .pairs-table {
            margin-bottom: 0;
        }

        .pairs-table td {
            padding: 0.75rem 1rem;
        }

        .badge-win-rate {
            font-size: 0.8rem;
            font-weight: 600;
            padding: 0.35rem 0.75rem;
            border-radius: 50px;
            background: linear-gradient(135deg, rgba(0, 255, 255, 0.2) 0%, rgba(0, 255, 127, 0.2) 100%);
            color: var(--text-primary);
            letter-spacing: 0.5px;
            border: 1px solid rgba(0, 255, 255, 0.3);
        }
        
        /* Day/Time heatmap styles */
        .heatmap-container {
            background-color: var(--bg-secondary);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .heatmap-title {
            font-size: 1.1rem;
            color: var(--text-primary);
            margin-bottom: 1.5rem;
            font-weight: 600;
            text-align: center;
        }
        
        .heatmap-grid {
            display: grid;
            grid-template-columns: 80px repeat(24, minmax(20px, 1fr));
            gap: 2px;
        }
        
        .heatmap-hour-label {
            grid-column: span 1;
            text-align: center;
            font-size: 0.7rem;
            color: var(--text-secondary);
            padding: 0.25rem 0;
            font-weight: 500;
        }
        
        .heatmap-day-label {
            display: flex;
            align-items: center;
            justify-content: flex-end;
            font-size: 0.8rem;
            color: var(--text-primary);
            padding-right: 0.5rem;
            font-weight: 600;
        }
        
        .heatmap-cell {
            aspect-ratio: 1;
            border-radius: 2px;
            transition: all 0.2s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.7rem;
            font-weight: 600;
            color: rgba(255, 255, 255, 0.9);
            position: relative;
            cursor: pointer;
        }
        
        .heatmap-cell:hover {
            transform: scale(1.1);
            z-index: 10;
        }
        
        .heatmap-tooltip {
            position: absolute;
            bottom: 120%;
            left: 50%;
            transform: translateX(-50%);
            background-color: var(--bg-primary);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: 0.5rem;
            font-size: 0.8rem;
            color: var(--text-primary);
            white-space: nowrap;
            pointer-events: none;
            opacity: 0;
            transition: opacity 0.2s ease;
            z-index: 100;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }
        
        .heatmap-cell:hover .heatmap-tooltip {
            opacity: 1;
        }
        
        /* Calendar styles */
        .calendar-container {
            background-color: var(--bg-secondary);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .calendar-title {
            font-size: 1.1rem;
            color: var(--text-primary);
            margin-bottom: 1.5rem;
            font-weight: 600;
            text-align: center;
        }
        
        .calendar-controls {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }
        
        .calendar-nav {
            color: var(--neon-cyan);
            background-color: transparent;
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: 0.3rem 0.8rem;
            font-size: 0.9rem;
            cursor: pointer;
            transition: all 0.2s ease;
        }
        
        .calendar-nav:hover {
            background-color: rgba(0, 255, 255, 0.1);
            border-color: var(--neon-cyan);
        }
        
        .calendar-current-month {
            font-size: 1rem;
            color: var(--text-primary);
            font-weight: 600;
        }
        
        .calendar-grid {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            gap: 8px;
        }
        
        .calendar-weekday {
            text-align: center;
            font-size: 0.8rem;
            color: var(--text-secondary);
            padding: 0.5rem 0;
            font-weight: 600;
            text-transform: uppercase;
        }
        
        .calendar-day {
            aspect-ratio: 1;
            border-radius: var(--border-radius);
            border: 1px solid var(--border-color);
            background-color: rgba(10, 12, 16, 0.3);
            transition: all 0.2s ease;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            font-size: 0.9rem;
            color: var(--text-primary);
            cursor: pointer;
            position: relative;
            overflow: hidden;
        }
        
        .calendar-day-number {
            font-weight: 500;
            position: absolute;
            top: 5px;
            right: 8px;
            font-size: 0.8rem;
        }
        
        .calendar-day-content {
            font-size: 1.2rem;
            font-weight: 700;
            margin-top: 0.3rem;
        }
        
        .calendar-day:hover {
            transform: translateY(-3px);
            border-color: var(--neon-cyan);
            box-shadow: 0 0 10px var(--glow-color-cyan);
        }
        
        .calendar-day.has-trade {
            cursor: pointer;
            background-color: rgba(0, 255, 255, 0.1);
        }
        
        /* Calendar day theme-specific colors */
        :root[data-theme="neon"] .calendar-day.profit {
            background-color: rgba(0, 255, 127, 0.15);
            border-color: rgba(0, 255, 127, 0.4);
        }
        
        :root[data-theme="neon"] .calendar-day.loss {
            background-color: rgba(255, 51, 102, 0.15);
            border-color: rgba(255, 51, 102, 0.4);
        }
        
        :root[data-theme="light"] .calendar-day.profit {
            background-color: rgba(40, 167, 69, 0.15);
            border-color: rgba(40, 167, 69, 0.4);
        }
        
        :root[data-theme="light"] .calendar-day.loss {
            background-color: rgba(220, 53, 69, 0.15);
            border-color: rgba(220, 53, 69, 0.4);
        }
        
        :root[data-theme="financial"] .calendar-day.profit {
            background-color: rgba(25, 135, 84, 0.15);
            border-color: rgba(25, 135, 84, 0.4);
        }
        
        :root[data-theme="financial"] .calendar-day.loss {
            background-color: rgba(176, 42, 55, 0.15);
            border-color: rgba(176, 42, 55, 0.4);
        }
        
        :root[data-theme="midnight"] .calendar-day.profit {
            background-color: rgba(88, 161, 123, 0.15);
            border-color: rgba(88, 161, 123, 0.4);
        }
        
        :root[data-theme="midnight"] .calendar-day.loss {
            background-color: rgba(165, 71, 96, 0.15);
            border-color: rgba(165, 71, 96, 0.4);
        }
        
        /* Theme-specific heatmap colors */
        :root[data-theme="neon"] .heatmap-cell.profit {
            background-color: rgba(0, 255, 127, var(--intensity));
        }
        
        :root[data-theme="neon"] .heatmap-cell.loss {
            background-color: rgba(255, 51, 102, var(--intensity));
        }
        
        :root[data-theme="light"] .heatmap-cell.profit {
            background-color: rgba(40, 167, 69, var(--intensity));
        }
        
        :root[data-theme="light"] .heatmap-cell.loss {
            background-color: rgba(220, 53, 69, var(--intensity));
        }
        
        :root[data-theme="financial"] .heatmap-cell.profit {
            background-color: rgba(25, 135, 84, var(--intensity));
        }
        
        :root[data-theme="financial"] .heatmap-cell.loss {
            background-color: rgba(176, 42, 55, var(--intensity));
        }
        
        :root[data-theme="midnight"] .heatmap-cell.profit {
            background-color: rgba(88, 161, 123, var(--intensity));
        }
        
        :root[data-theme="midnight"] .heatmap-cell.loss {
            background-color: rgba(165, 71, 96, var(--intensity));
        }
        
        .calendar-tooltip {
            position: absolute;
            bottom: 120%;
            left: 50%;
            transform: translateX(-50%);
            background-color: var(--bg-primary);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: 0.5rem;
            font-size: 0.8rem;
            color: var(--text-primary);
            white-space: nowrap;
            pointer-events: none;
            opacity: 0;
            transition: opacity 0.2s ease;
            z-index: 100;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }
        
        .calendar-day:hover .calendar-tooltip {
            opacity: 1;
        }
        
        .calendar-outside-month {
            opacity: 0.3;
        }
        
        /* Strategy/Emotion/Context analysis styles */
        .strategy-analysis-container {
            background-color: var(--bg-secondary);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .strategy-title {
            font-size: 1.1rem;
            color: var(--text-primary);
            margin-bottom: 1rem;
            font-weight: 600;
        }
        
        .strategy-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem;
            border-bottom: 1px solid var(--border-color);
            transition: all 0.2s ease;
        }
        
        .strategy-item:hover {
            background-color: rgba(0, 255, 255, 0.05);
        }
        
        .strategy-item:last-child {
            border-bottom: none;
        }
        
        .strategy-name {
            font-weight: 600;
            color: var(--text-primary);
        }
        
        .strategy-stats {
            display: flex;
            gap: 1rem;
            align-items: center;
        }
        
        .strategy-value {
            display: flex;
            flex-direction: column;
            align-items: flex-end;
        }
        
        .strategy-value-label {
            font-size: 0.8rem;
            color: var(--text-secondary);
        }
        
        .strategy-value-number {
            font-weight: 600;
            color: var(--neon-cyan);
        }
        
        .strategy-value-number.profit {
            color: var(--neon-green);
        }
        
        .strategy-value-number.loss {
            color: var(--neon-red);
        }
        
        /* Animation for heatmap cells on theme change */
        @keyframes cellHighlight {
            0% {
                transform: scale(1);
                box-shadow: 0 0 0 rgba(0, 255, 255, 0);
            }
            50% {
                transform: scale(1.05);
                box-shadow: 0 0 10px rgba(0, 255, 255, 0.4);
            }
            100% {
                transform: scale(1);
                box-shadow: 0 0 3px rgba(0, 255, 255, 0.2);
            }
        }
        
        .heatmap-cell.theme-transition {
            animation: cellHighlight 0.6s ease-out;
        }
        
        .calendar-day.theme-transition {
            animation: cellHighlight 0.6s ease-out;
        }

        .clear-filters {
            font-size: 0.9rem;
            color: var(--text-secondary);
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.25rem;
            transition: all 0.2s ease;
            margin-right: 1rem;
        }
        
        .clear-filters:hover {
            color: var(--neon-cyan);
        }

        .filters-applied {
            font-size: 0.9rem;
            color: var(--neon-cyan);
            margin-bottom: 1rem;
            display: inline-block;
        }
    </style>
</head>
<body>
    <?php 
    $current_page = basename($_SERVER['PHP_SELF']);
    include('navigation.php'); 
    ?>

    <div class="container mt-5">
        <h1 class="page-title">Trade Analysis</h1>

        <div class="filter-card">
            <div class="filter-title">
                <i class="fas fa-filter me-2"></i> Filter Trades
            </div>
            <form action="analysis.php" method="get" class="row g-3">
                <div class="col-md-3">
                    <label for="pair" class="form-label">Trading Pair</label>
                    <select class="form-select" id="pair" name="pair">
                        <option value="">All Pairs</option>
                        <?php foreach ($pairs as $pair): ?>
                            <option value="<?= htmlspecialchars($pair) ?>" <?= $filter_pair === "%$pair%" ? 'selected' : '' ?>>
                                <?= htmlspecialchars($pair) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label for="outcome" class="form-label">Outcome</label>
                    <select class="form-select" id="outcome" name="outcome">
                        <option value="">All Outcomes</option>
                        <option value="win" <?= $filter_outcome === 'win' ? 'selected' : '' ?>>Profitable</option>
                        <option value="loss" <?= $filter_outcome === 'loss' ? 'selected' : '' ?>>Loss</option>
                        <option value="breakeven" <?= $filter_outcome === 'breakeven' ? 'selected' : '' ?>>Breakeven</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label for="order_type" class="form-label">Order Type</label>
                    <select class="form-select" id="order_type" name="order_type">
                        <option value="">All Types</option>
                        <?php foreach ($order_types as $type): ?>
                            <option value="<?= htmlspecialchars($type) ?>" <?= $filter_order_type === $type ? 'selected' : '' ?>>
                                <?= htmlspecialchars($type) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label for="start_date" class="form-label">Start Date</label>
                    <input type="date" class="form-control" id="start_date" name="start_date" value="<?= htmlspecialchars($filter_start_date) ?>">
                </div>
                <div class="col-md-3">
                    <label for="end_date" class="form-label">End Date</label>
                    <input type="date" class="form-control" id="end_date" name="end_date" value="<?= htmlspecialchars($filter_end_date) ?>">
                </div>
                <div class="col-md-9 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary me-2" style="background-color: var(--neon-cyan); border-color: var(--neon-cyan); color: var(--bg-primary);">
                        <i class="fas fa-search me-2"></i>Apply Filters
                    </button>
                    <?php if (!empty($filter_pair) || !empty($filter_outcome) || !empty($filter_start_date) || !empty($filter_end_date) || !empty($filter_order_type)): ?>
                        <a href="analysis.php" class="clear-filters">
                            <i class="fas fa-times me-1"></i>Clear Filters
                        </a>
                    <?php endif; ?>
                </div>
            </form>
            
            <?php if (!empty($filter_pair) || !empty($filter_outcome) || !empty($filter_start_date) || !empty($filter_end_date) || !empty($filter_order_type)): ?>
                <div class="filters-applied mt-3">
                    <i class="fas fa-check-circle me-1"></i>
                    Filters applied: 
                    <?php 
                    $applied_filters = [];
                    if (!empty($filter_pair)) $applied_filters[] = "Pair containing '" . str_replace('%', '', $filter_pair) . "'";
                    if ($filter_outcome === 'win') $applied_filters[] = "Profitable trades";
                    if ($filter_outcome === 'loss') $applied_filters[] = "Loss trades";
                    if ($filter_outcome === 'breakeven') $applied_filters[] = "Breakeven trades";
                    if (!empty($filter_start_date)) $applied_filters[] = "From " . $filter_start_date;
                    if (!empty($filter_end_date)) $applied_filters[] = "To " . $filter_end_date;
                    if (!empty($filter_order_type)) $applied_filters[] = "Order type: " . $filter_order_type;
                    echo implode(', ', $applied_filters);
                    ?>
                </div>
            <?php endif; ?>
        </div>

        <div class="row mb-4">
            <div class="col-md-3">
                <div class="stats-card">
                    <div class="stats-icon"><i class="fas fa-chart-bar"></i></div>
                    <div class="stats-title">Total Trades</div>
                    <div class="stats-value"><?= $total_trades ?></div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <div class="stats-icon"><i class="fas fa-trophy"></i></div>
                    <div class="stats-title">Win Rate</div>
                    <div class="stats-value"><?= $win_rate ?>%</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <div class="stats-icon"><i class="fas fa-arrow-trend-up"></i></div>
                    <div class="stats-title">Average Win</div>
                    <div class="stats-value profit"><?= format_money($average_win) ?></div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <div class="stats-icon"><i class="fas fa-arrow-trend-down"></i></div>
                    <div class="stats-title">Average Loss</div>
                    <div class="stats-value loss"><?= format_money(-$average_loss) ?></div>
                </div>
            </div>
        </div>

        <div class="row mb-4">
            <div class="col-md-3">
                <div class="stats-card">
                    <div class="stats-icon"><i class="fas fa-coins"></i></div>
                    <div class="stats-title">Total P&L</div>
                    <div class="stats-value <?= $total_pnl >= 0 ? 'profit' : 'loss' ?>"><?= format_money($total_pnl) ?></div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <div class="stats-icon"><i class="fas fa-wallet"></i></div>
                    <div class="stats-title">Wallet Balance</div>
                    <div class="stats-value"><?= format_money($current_wallet) ?></div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <div class="stats-icon"><i class="fas fa-award"></i></div>
                    <div class="stats-title">Best Win Streak</div>
                    <div class="stats-value profit"><?= $best_win_streak ?></div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <div class="stats-icon"><i class="fas fa-skull"></i></div>
                    <div class="stats-title">Worst Loss Streak</div>
                    <div class="stats-value loss"><?= abs($worst_loss_streak) ?></div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="chart-container">
                    <div class="chart-title">Trading Pairs Performance</div>
                    <canvas id="pairsChart"></canvas>
                </div>
            </div>
            <div class="col-md-6">
                <div class="chart-container">
                    <div class="chart-title">Monthly Performance</div>
                    <canvas id="monthlyChart"></canvas>
                </div>
            </div>
        </div>
        
        <div class="row">
            <!-- Day/Time Analysis Heatmap -->
            <div class="col-12">
                <div class="heatmap-container">
                    <div class="heatmap-title">Day & Time Analysis - Trading Performance Heatmap</div>
                    <div class="heatmap-grid" id="heatmapGrid">
                        <!-- Hours labels row -->
                        <div class="heatmap-day-label"></div>
                        <?php for ($hour = 0; $hour < 24; $hour++): ?>
                            <div class="heatmap-hour-label"><?= sprintf('%02d', $hour) ?></div>
                        <?php endfor; ?>
                        
                        <!-- Days rows -->
                        <?php 
                        $days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
                        for ($day = 0; $day < 7; $day++): 
                        ?>
                            <div class="heatmap-day-label"><?= substr($days[$day], 0, 3) ?></div>
                            <?php for ($hour = 0; $hour < 24; $hour++): 
                                $count = $day_hour_data[$day][$hour]['count'];
                                $pnl = $day_hour_data[$day][$hour]['pnl'];
                                $win_count = $day_hour_data[$day][$hour]['win_count'];
                                $loss_count = $day_hour_data[$day][$hour]['loss_count'];
                                
                                $intensity = 0;
                                $cell_class = '';
                                $content = '';
                                
                                if ($count > 0) {
                                    if ($pnl > 0) {
                                        $intensity = min(0.9, $win_count / max(1, $count) * 0.9);
                                        $cell_class = 'profit';
                                        $content = '+';
                                    } elseif ($pnl < 0) {
                                        $intensity = min(0.9, $loss_count / max(1, $count) * 0.9);
                                        $cell_class = 'loss';
                                        $content = '-';
                                    }
                                }
                            ?>
                                <div class="heatmap-cell <?= $cell_class ?>" style="--intensity: <?= $intensity ?>">
                                    <?= $content ?>
                                    <?php if ($count > 0): ?>
                                    <div class="heatmap-tooltip">
                                        <div><strong><?= $days[$day] ?> <?= sprintf('%02d', $hour) ?>:00</strong></div>
                                        <div>Trades: <?= $count ?></div>
                                        <div>Win/Loss: <?= $win_count ?>/<?= $loss_count ?></div>
                                        <div>P&L: <?= format_money($pnl) ?></div>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            <?php endfor; ?>
                        <?php endfor; ?>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Calendar View -->
        <div class="row">
            <div class="col-12">
                <div class="calendar-container">
                    <div class="calendar-title">Trading Calendar</div>
                    <div class="calendar-controls">
                        <button type="button" id="prevMonth" class="calendar-nav">
                            <i class="fas fa-chevron-left"></i> Previous Month
                        </button>
                        <div class="calendar-current-month" id="currentMonthDisplay">
                            <?= date('F Y') ?>
                        </div>
                        <button type="button" id="nextMonth" class="calendar-nav">
                            Next Month <i class="fas fa-chevron-right"></i>
                        </button>
                    </div>
                    <div id="calendarGrid" class="calendar-grid">
                        <!-- Calendar will be generated via JavaScript -->
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Trading Psychology Analysis -->
        <div class="row">
            <div class="col-md-4">
                <div class="strategy-analysis-container">
                    <div class="strategy-title">
                        <i class="fas fa-brain me-2"></i> Emotion Analysis
                    </div>
                    <?php if (empty($emotion_data)): ?>
                        <div class="empty-state">
                            <div class="empty-state-icon">
                                <i class="fas fa-face-smile-beam"></i>
                            </div>
                            <div class="empty-state-text">
                                No emotion data available yet
                            </div>
                        </div>
                    <?php else: ?>
                        <?php foreach ($emotion_data as $emotion => $data): 
                            $win_rate = $data['count'] > 0 ? ($data['win_count'] / $data['count']) * 100 : 0;
                        ?>
                            <div class="strategy-item">
                                <div class="strategy-name">
                                    <?= htmlspecialchars($emotion) ?>
                                </div>
                                <div class="strategy-stats">
                                    <div class="strategy-value">
                                        <div class="strategy-value-label">Trades</div>
                                        <div class="strategy-value-number"><?= $data['count'] ?></div>
                                    </div>
                                    <div class="strategy-value">
                                        <div class="strategy-value-label">Win Rate</div>
                                        <div class="strategy-value-number"><?= number_format($win_rate, 1) ?>%</div>
                                    </div>
                                    <div class="strategy-value">
                                        <div class="strategy-value-label">P&L</div>
                                        <div class="strategy-value-number <?= $data['pnl'] >= 0 ? 'profit' : 'loss' ?>">
                                            <?= format_money($data['pnl']) ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="strategy-analysis-container">
                    <div class="strategy-title">
                        <i class="fas fa-chess me-2"></i> Strategy Analysis
                    </div>
                    <?php if (empty($strategy_data)): ?>
                        <div class="empty-state">
                            <div class="empty-state-icon">
                                <i class="fas fa-chess-knight"></i>
                            </div>
                            <div class="empty-state-text">
                                No strategy data available yet
                            </div>
                        </div>
                    <?php else: ?>
                        <?php foreach ($strategy_data as $strategy => $data): 
                            $win_rate = $data['count'] > 0 ? ($data['win_count'] / $data['count']) * 100 : 0;
                        ?>
                            <div class="strategy-item">
                                <div class="strategy-name">
                                    <?= htmlspecialchars($strategy) ?>
                                </div>
                                <div class="strategy-stats">
                                    <div class="strategy-value">
                                        <div class="strategy-value-label">Trades</div>
                                        <div class="strategy-value-number"><?= $data['count'] ?></div>
                                    </div>
                                    <div class="strategy-value">
                                        <div class="strategy-value-label">Win Rate</div>
                                        <div class="strategy-value-number"><?= number_format($win_rate, 1) ?>%</div>
                                    </div>
                                    <div class="strategy-value">
                                        <div class="strategy-value-label">P&L</div>
                                        <div class="strategy-value-number <?= $data['pnl'] >= 0 ? 'profit' : 'loss' ?>">
                                            <?= format_money($data['pnl']) ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="strategy-analysis-container">
                    <div class="strategy-title">
                        <i class="fas fa-globe me-2"></i> Market Context Analysis
                    </div>
                    <?php if (empty($market_context_data)): ?>
                        <div class="empty-state">
                            <div class="empty-state-icon">
                                <i class="fas fa-chart-line"></i>
                            </div>
                            <div class="empty-state-text">
                                No market context data available yet
                            </div>
                        </div>
                    <?php else: ?>
                        <?php foreach ($market_context_data as $context => $data): 
                            $win_rate = $data['count'] > 0 ? ($data['win_count'] / $data['count']) * 100 : 0;
                        ?>
                            <div class="strategy-item">
                                <div class="strategy-name">
                                    <?= htmlspecialchars($context) ?>
                                </div>
                                <div class="strategy-stats">
                                    <div class="strategy-value">
                                        <div class="strategy-value-label">Trades</div>
                                        <div class="strategy-value-number"><?= $data['count'] ?></div>
                                    </div>
                                    <div class="strategy-value">
                                        <div class="strategy-value-label">Win Rate</div>
                                        <div class="strategy-value-number"><?= number_format($win_rate, 1) ?>%</div>
                                    </div>
                                    <div class="strategy-value">
                                        <div class="strategy-value-label">P&L</div>
                                        <div class="strategy-value-number <?= $data['pnl'] >= 0 ? 'profit' : 'loss' ?>">
                                            <?= format_money($data['pnl']) ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="table-container">
                    <div class="filter-title mb-3">Top Trading Pairs</div>
                    <?php if (!empty($pairs_data)): ?>
                        <table class="table pairs-table">
                            <thead>
                                <tr>
                                    <th>Pair</th>
                                    <th>Win Rate</th>
                                    <th>Trades</th>
                                    <th>P&L</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $counter = 0;
                                foreach ($pairs_data as $pair => $data): 
                                    $win_rate = $data['total'] > 0 ? ($data['wins'] / $data['total']) * 100 : 0;
                                    if ($counter++ >= 5) break; // Show only top 5
                                ?>
                                <tr>
                                    <td><?= htmlspecialchars($pair) ?></td>
                                    <td><span class="badge-win-rate"><?= number_format($win_rate, 1) ?>%</span></td>
                                    <td><?= $data['total'] ?></td>
                                    <td class="pnl-value <?= $data['pnl'] >= 0 ? 'profit' : 'loss' ?>">
                                        <?= format_money($data['pnl']) ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <p class="text-center text-muted">No data available</p>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-6">
                <div class="table-container">
                    <div class="filter-title mb-3">Monthly Stats</div>
                    <?php if (!empty($monthly_data)): ?>
                        <table class="table pairs-table">
                            <thead>
                                <tr>
                                    <th>Month</th>
                                    <th>Win Rate</th>
                                    <th>Trades</th>
                                    <th>P&L</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                // Display in reverse chronological order
                                $months = array_keys($monthly_data);
                                rsort($months);
                                foreach (array_slice($months, 0, 5) as $month): 
                                    $data = $monthly_data[$month];
                                    $win_rate = $data['total'] > 0 ? ($data['wins'] / $data['total']) * 100 : 0;
                                    $month_parts = explode('-', $month);
                                    $month_name = date('F Y', mktime(0, 0, 0, $month_parts[1], 1, $month_parts[0]));
                                ?>
                                <tr>
                                    <td><?= htmlspecialchars($month_name) ?></td>
                                    <td><span class="badge-win-rate"><?= number_format($win_rate, 1) ?>%</span></td>
                                    <td><?= $data['total'] ?></td>
                                    <td class="pnl-value <?= $data['pnl'] >= 0 ? 'profit' : 'loss' ?>">
                                        <?= format_money($data['pnl']) ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <p class="text-center text-muted">No data available</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="table-container">
            <div class="filter-title mb-3">
                <i class="fas fa-list me-2"></i>Trade History
                <small class="text-muted ms-2">(<?= count($trades_data) ?> trades)</small>
            </div>

            <?php if (empty($trades_data)): ?>
                <div class="empty-state">
                    <div class="empty-state-icon">
                        <i class="fas fa-search"></i>
                    </div>
                    <div class="empty-state-text">
                        <?php if (!empty($filter_pair) || !empty($filter_outcome) || !empty($filter_start_date) || !empty($filter_end_date) || !empty($filter_order_type)): ?>
                            No trades match your filter criteria.
                        <?php else: ?>
                            You haven't logged any trades yet. Start by adding your first trade.
                        <?php endif; ?>
                    </div>
                    <?php if (empty($filter_pair) && empty($filter_outcome) && empty($filter_start_date) && empty($filter_end_date) && empty($filter_order_type)): ?>
                        <a href="add_trade.php" class="nav-button primary">
                            <i class="fas fa-plus me-2"></i>Add First Trade
                        </a>
                    <?php else: ?>
                        <a href="analysis.php" class="nav-button">
                            <i class="fas fa-times me-2"></i>Clear Filters
                        </a>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Pair</th>
                                <th>Type</th>
                                <th>Status</th>
                                <th>Entry</th>
                                <th>SL</th>
                                <th>TP</th>
                                <th>Size</th>
                                <th>P&L</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($trades_data as $trade): 
                                $pnl = floatval($trade['pnl']);
                                $pnl_class = ($pnl > 0) ? 'profit' : (($pnl < 0) ? 'loss' : '');
                                
                                // Determine status class
                                $status_class = 'status-closed';
                                $trade_status = strtolower($trade['status']);
                                if (strpos($trade_status, 'open') !== false) {
                                    $status_class = 'status-open';
                                } elseif (strpos($trade_status, 'limit') !== false) {
                                    $status_class = 'status-limit';
                                }
                            ?>
                            <tr>
                                <td><?= htmlspecialchars($trade['formatted_date']) ?></td>
                                <td><?= htmlspecialchars($trade['pair']) ?></td>
                                <td><?= htmlspecialchars($trade['order_type']) ?></td>
                                <td>
                                    <span class="trade-status <?= $status_class ?>">
                                        <?= htmlspecialchars($trade['status']) ?>
                                    </span>
                                </td>
                                <td><?= htmlspecialchars($trade['entry'] ?? 'N/A') ?></td>
                                <td><?= htmlspecialchars($trade['stop_loss'] ?? 'N/A') ?></td>
                                <td><?= htmlspecialchars($trade['take_profit'] ?? 'N/A') ?></td>
                                <td><?= htmlspecialchars($trade['position_size'] ?? 'N/A') ?></td>
                                <td class="pnl-value <?= $pnl_class ?>"><?= format_money($pnl) ?></td>
                                <td>
                                    <a href="trade_details.php?id=<?= $trade['id'] ?>" class="btn btn-sm" style="color: var(--neon-cyan);">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="edit_trade.php?id=<?= $trade['id'] ?>" class="btn btn-sm" style="color: var(--text-secondary);">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script src="js/theme-switcher.js"></script>
    
    <script>
        // Calendar View Implementation
        const calendarData = <?= json_encode($calendar_data) ?>;
        const calendarEl = document.getElementById('calendarGrid');
        const currentMonthDisplay = document.getElementById('currentMonthDisplay');
        const prevMonthBtn = document.getElementById('prevMonth');
        const nextMonthBtn = document.getElementById('nextMonth');
        
        // Current display month/year
        let currentMonth = new Date().getMonth();
        let currentYear = new Date().getFullYear();
        
        // Days of the week for header
        const weekdays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
        
        // Function to format currency
        function formatCurrency(amount) {
            const symbol = '<?= $currency_symbol ?>';
            const formatted = symbol + Math.abs(amount).toFixed(2);
            return amount < 0 ? "-" + formatted : formatted;
        }
        
        // Get theme-appropriate colors
        function getThemeColors() {
            const theme = document.documentElement.getAttribute('data-theme') || 'neon';
            const colors = {
                neon: {
                    profitColor: 'rgba(0, 255, 127, 0.7)',
                    lossColor: 'rgba(255, 51, 102, 0.7)',
                    gridColor: 'rgba(0, 255, 255, 0.1)',
                    textColor: 'rgba(230, 241, 255, 0.7)',
                    lineColor: '#00ffff',
                    bgColor: 'rgba(0, 255, 255, 0.1)'
                },
                light: {
                    profitColor: 'rgba(40, 167, 69, 0.7)',
                    lossColor: 'rgba(220, 53, 69, 0.7)',
                    gridColor: 'rgba(0, 0, 0, 0.1)',
                    textColor: 'rgba(33, 37, 41, 0.8)',
                    lineColor: '#007bff',
                    bgColor: 'rgba(0, 123, 255, 0.1)'
                },
                financial: {
                    profitColor: 'rgba(25, 135, 84, 0.7)',
                    lossColor: 'rgba(176, 42, 55, 0.7)',
                    gridColor: 'rgba(41, 98, 255, 0.1)',
                    textColor: 'rgba(41, 50, 65, 0.8)',
                    lineColor: '#2962ff',
                    bgColor: 'rgba(41, 98, 255, 0.1)'
                },
                midnight: {
                    profitColor: 'rgba(88, 161, 123, 0.7)',
                    lossColor: 'rgba(165, 71, 96, 0.7)',
                    gridColor: 'rgba(138, 180, 248, 0.1)',
                    textColor: 'rgba(209, 213, 219, 0.8)',
                    lineColor: '#8ab4f8',
                    bgColor: 'rgba(138, 180, 248, 0.1)'
                }
            };
            
            return colors[theme];
        }
        
        // Add animation to heatmap cells on theme change
        function animateHeatmapCells() {
            // Animate heatmap cells
            const cells = document.querySelectorAll('.heatmap-cell');
            cells.forEach(cell => {
                cell.classList.add('theme-transition');
                setTimeout(() => {
                    cell.classList.remove('theme-transition');
                }, 600);
            });
            
            // Animate calendar days with trades
            const days = document.querySelectorAll('.calendar-day.has-trade');
            days.forEach((day, index) => {
                // Stagger animation for a wave effect
                setTimeout(() => {
                    day.classList.add('theme-transition');
                    setTimeout(() => {
                        day.classList.remove('theme-transition');
                    }, 600);
                }, index * 30); // Staggered delay
            });
        }
        
        // Update charts when theme changes
        function updateChartsTheme() {
            // Add animations to heatmap
            animateHeatmapCells();
            // Update the charts when we have them
            if (window.pairsChart) {
                const colors = getThemeColors();
                // Update bar colors based on the theme
                const pairPnl = pairsChart.data.datasets[0].data;
                pairsChart.data.datasets[0].backgroundColor = pairPnl.map(pnl => 
                    pnl >= 0 ? colors.profitColor : colors.lossColor
                );
                pairsChart.data.datasets[0].borderColor = pairsChart.data.datasets[0].backgroundColor.map(
                    color => color.replace('0.7', '1')
                );
                
                // Update scale colors
                pairsChart.options.scales.y.grid.color = colors.gridColor;
                pairsChart.options.scales.y.ticks.color = colors.textColor;
                pairsChart.options.scales.x.ticks.color = colors.textColor;
                pairsChart.update();
            }
            
            if (window.monthlyChart) {
                const colors = getThemeColors();
                monthlyChart.data.datasets[0].borderColor = colors.lineColor;
                monthlyChart.data.datasets[0].backgroundColor = colors.bgColor;
                
                // Update point colors based on PnL values
                const monthlyPnl = monthlyChart.data.datasets[0].data;
                monthlyChart.data.datasets[0].pointBackgroundColor = monthlyPnl.map(pnl => {
                    if (pnl === 0) return colors.lineColor;
                    return pnl > 0 ? colors.profitColor.replace('0.7', '1') : colors.lossColor.replace('0.7', '1');
                });
                
                monthlyChart.options.scales.y.grid.color = colors.gridColor;
                monthlyChart.options.scales.y.ticks.color = colors.textColor;
                monthlyChart.options.scales.x.grid.color = colors.gridColor;
                monthlyChart.options.scales.x.ticks.color = colors.textColor;
                monthlyChart.update();
            }
        }
        
        // Listen for theme changes
        document.addEventListener('themeChanged', function(e) {
            updateChartsTheme();
        });
        
        // Function to render the calendar for a specific month/year
        function renderCalendar(month, year) {
            // Clear previous calendar
            calendarEl.innerHTML = '';
            
            // Add weekday headers
            weekdays.forEach(day => {
                const dayEl = document.createElement('div');
                dayEl.className = 'calendar-weekday';
                dayEl.textContent = day;
                calendarEl.appendChild(dayEl);
            });
            
            // Get days in month and start day of month
            const firstDay = new Date(year, month, 1);
            const lastDay = new Date(year, month + 1, 0);
            const daysInMonth = lastDay.getDate();
            const startDayIndex = firstDay.getDay(); // 0-6 (Sunday-Saturday)
            
            // Get last month days to display
            const prevMonthLastDay = new Date(year, month, 0).getDate();
            
            // Display previous month days
            for (let i = 0; i < startDayIndex; i++) {
                const dayNum = prevMonthLastDay - startDayIndex + i + 1;
                const dayEl = document.createElement('div');
                dayEl.className = 'calendar-day calendar-outside-month';
                dayEl.innerHTML = `<div class="calendar-day-number">${dayNum}</div>`;
                calendarEl.appendChild(dayEl);
            }
            
            // Display current month days
            for (let i = 1; i <= daysInMonth; i++) {
                const dayEl = document.createElement('div');
                dayEl.className = 'calendar-day';
                
                // Format date to match our data format (YYYY-MM-DD)
                const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(i).padStart(2, '0')}`;
                
                // Check if there are trades on this day
                if (calendarData[dateStr]) {
                    const dayData = calendarData[dateStr];
                    const hasTrade = dayData.count > 0;
                    const isProfitable = dayData.pnl > 0;
                    const isLoss = dayData.pnl < 0;
                    
                    if (hasTrade) {
                        dayEl.classList.add('has-trade');
                        if (isProfitable) {
                            dayEl.classList.add('profit');
                        } else if (isLoss) {
                            dayEl.classList.add('loss');
                        }
                        
                        // Add day content
                        dayEl.innerHTML = `
                            <div class="calendar-day-number">${i}</div>
                            <div class="calendar-day-content">${isProfitable ? '+' : '-'}</div>
                            <div class="calendar-tooltip">
                                <div><strong>${dateStr}</strong></div>
                                <div>Trades: ${dayData.count}</div>
                                <div>Win/Loss: ${dayData.win_count}/${dayData.loss_count}</div>
                                <div>P&L: ${formatCurrency(dayData.pnl)}</div>
                            </div>
                        `;
                    } else {
                        dayEl.innerHTML = `<div class="calendar-day-number">${i}</div>`;
                    }
                } else {
                    dayEl.innerHTML = `<div class="calendar-day-number">${i}</div>`;
                }
                
                calendarEl.appendChild(dayEl);
            }
            
            // Calculate the remaining cells to fill the grid
            const totalDaysDisplayed = startDayIndex + daysInMonth;
            const remainingCells = 42 - totalDaysDisplayed; // 6 rows * 7 days = 42
            
            // Fill with next month days
            for (let i = 1; i <= remainingCells; i++) {
                const dayEl = document.createElement('div');
                dayEl.className = 'calendar-day calendar-outside-month';
                dayEl.innerHTML = `<div class="calendar-day-number">${i}</div>`;
                calendarEl.appendChild(dayEl);
            }
            
            // Update month display
            const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
            currentMonthDisplay.textContent = `${monthNames[month]} ${year}`;
        }
        
        // Initialize calendar
        renderCalendar(currentMonth, currentYear);
        
        // Previous month button
        prevMonthBtn.addEventListener('click', () => {
            currentMonth--;
            if (currentMonth < 0) {
                currentMonth = 11;
                currentYear--;
            }
            renderCalendar(currentMonth, currentYear);
        });
        
        // Next month button
        nextMonthBtn.addEventListener('click', () => {
            currentMonth++;
            if (currentMonth > 11) {
                currentMonth = 0;
                currentYear++;
            }
            renderCalendar(currentMonth, currentYear);
        });
        <?php if (!empty($pairs_data)): ?>
        // Trading Pairs Chart
        const pairsCtx = document.getElementById('pairsChart').getContext('2d');
        
        // Prepare data for pairs chart - take top 5 by trade count
        const pairsData = <?= json_encode($pairs_data) ?>;
        const sortedPairs = Object.entries(pairsData)
            .sort((a, b) => b[1].total - a[1].total)
            .slice(0, 5);
        
        const pairLabels = sortedPairs.map(item => item[0]);
        const pairPnl = sortedPairs.map(item => item[1].pnl);
        const colors = getThemeColors();
        const pairColors = pairPnl.map(pnl => 
            pnl >= 0 ? colors.profitColor : colors.lossColor
        );
        
        window.pairsChart = new Chart(pairsCtx, {
            type: 'bar',
            data: {
                labels: pairLabels,
                datasets: [{
                    label: 'P&L',
                    data: pairPnl,
                    backgroundColor: pairColors,
                    borderColor: pairColors.map(color => color.replace('0.7', '1')),
                    borderWidth: 1,
                    borderRadius: 4
                }]
            },
            options: {
                maintainAspectRatio: false,
                scales: {
                    y: {
                        grid: {
                            color: colors.gridColor
                        },
                        ticks: {
                            color: colors.textColor,
                            callback: function(value) {
                                return '<?= $currency_symbol ?>' + value.toFixed(2);
                            }
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            color: colors.textColor
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return '<?= $currency_symbol ?>' + context.raw.toFixed(2);
                            }
                        }
                    }
                }
            }
        });
        <?php endif; ?>
        
        <?php if (!empty($monthly_data)): ?>
        // Monthly Performance Chart
        const monthlyCtx = document.getElementById('monthlyChart').getContext('2d');
        
        // Prepare data for monthly chart
        const monthlyData = <?= json_encode($monthly_data) ?>;
        const months = Object.keys(monthlyData).sort();
        const monthlyPnl = months.map(month => monthlyData[month].pnl);
        
        // Format the month labels
        const monthLabels = months.map(month => {
            const [year, monthNum] = month.split('-');
            const date = new Date(year, monthNum - 1, 1);
            return date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
        });
        
        const themeColors = getThemeColors();
        window.monthlyChart = new Chart(monthlyCtx, {
            type: 'line',
            data: {
                labels: monthLabels,
                datasets: [{
                    label: 'Monthly P&L',
                    data: monthlyPnl,
                    borderColor: themeColors.lineColor,
                    backgroundColor: themeColors.bgColor,
                    borderWidth: 2,
                    fill: true,
                    tension: 0.4,
                    pointBackgroundColor: monthlyPnl.map(pnl => {
                        if (pnl === 0) return themeColors.lineColor;
                        return pnl > 0 ? themeColors.profitColor.replace('0.7', '1') : themeColors.lossColor.replace('0.7', '1');
                    }),
                    pointRadius: 4,
                    pointHoverRadius: 6
                }]
            },
            options: {
                maintainAspectRatio: false,
                scales: {
                    y: {
                        grid: {
                            color: themeColors.gridColor
                        },
                        ticks: {
                            color: themeColors.textColor,
                            callback: function(value) {
                                return '<?= $currency_symbol ?>' + value.toFixed(2);
                            }
                        }
                    },
                    x: {
                        grid: {
                            color: themeColors.gridColor
                        },
                        ticks: {
                            color: themeColors.textColor
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const pnl = context.raw;
                                return 'P&L: <?= $currency_symbol ?>' + pnl.toFixed(2);
                            }
                        }
                    }
                }
            }
        });
        <?php endif; ?>
        
        // Initialize chart themes on page load
        document.addEventListener('DOMContentLoaded', function() {
            // Update charts to match current theme
            updateChartsTheme();
        });
    </script>
</body>
</html>
