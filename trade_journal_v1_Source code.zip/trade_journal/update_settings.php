<?php
// Include database connection
require_once 'db_connect.php';

// Ensure we have a connection
$conn = ensure_db_connection();

if ($conn) {
    // Update initial capital to 1200
    if (update_setting('initial_capital', '1200')) {
        echo "Successfully updated initial capital to 1200\n";
    } else {
        echo "Failed to update initial capital\n";
    }
} else {
    echo "No database connection available\n";
}
?>