/**
 * Main JavaScript file for Trade Journal Application
 * Handles interactive elements and user experience
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize Bootstrap tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Handle image modal functionality
    initImageModal();
    
    // Handle delete confirmation
    initDeleteConfirmation();
    
    // Initialize trade form validators
    initTradeFormValidation();
});

/**
 * Sets up the image modal for trade chart images
 */
function initImageModal() {
    const imageModal = document.getElementById('imageModal');
    if (imageModal) {
        imageModal.addEventListener('show.bs.modal', function (event) {
            const button = event.relatedTarget;
            // Get image source from data attribute
            const imageSrc = button.getAttribute('data-src') || button.getAttribute('data-image-src');
            const modalImage = document.getElementById('modalImage');
            if (modalImage && imageSrc) {
                modalImage.src = imageSrc;
            }
        });
    }
}

/**
 * Sets up delete confirmation modals
 */
function initDeleteConfirmation() {
    const deleteConfirmModal = document.getElementById('deleteConfirmModal');
    if (deleteConfirmModal) {
        deleteConfirmModal.addEventListener('show.bs.modal', function (event) {
            const button = event.relatedTarget;
            const tradeId = button.getAttribute('data-trade-id');
            const idInput = document.getElementById('deleteTradeId');
            if (idInput && tradeId) {
                idInput.value = tradeId;
            }
        });
    }
}

/**
 * Basic form validation for trade forms
 */
function initTradeFormValidation() {
    const tradeForm = document.querySelector('form[action*="trade"]');
    if (tradeForm) {
        tradeForm.addEventListener('submit', function(event) {
            const pairInput = document.getElementById('pair');
            const entryInput = document.getElementById('entry');
            const orderTypeSelect = document.getElementById('order_type');
            const statusSelect = document.getElementById('status');
            
            let isValid = true;
            
            // Check required fields
            if (!pairInput || !pairInput.value.trim()) {
                highlightInvalidField(pairInput);
                isValid = false;
            } else {
                removeInvalidHighlight(pairInput);
            }
            
            if (!entryInput || !entryInput.value.trim() || isNaN(parseFloat(entryInput.value))) {
                highlightInvalidField(entryInput);
                isValid = false;
            } else {
                removeInvalidHighlight(entryInput);
            }
            
            if (!orderTypeSelect || !orderTypeSelect.value) {
                highlightInvalidField(orderTypeSelect);
                isValid = false;
            } else {
                removeInvalidHighlight(orderTypeSelect);
            }
            
            if (!statusSelect || !statusSelect.value) {
                highlightInvalidField(statusSelect);
                isValid = false;
            } else {
                removeInvalidHighlight(statusSelect);
            }
            
            if (!isValid) {
                event.preventDefault();
                // Scroll to first invalid field
                const firstInvalid = document.querySelector('.is-invalid');
                if (firstInvalid) {
                    firstInvalid.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }
            }
        });
    }
}

/**
 * Helper function to highlight invalid form fields
 * @param {HTMLElement} element - The form element to highlight
 */
function highlightInvalidField(element) {
    if (element) {
        element.classList.add('is-invalid');
        
        // Add error message if not already present
        const errorId = `${element.id}-error`;
        if (!document.getElementById(errorId)) {
            const errorDiv = document.createElement('div');
            errorDiv.className = 'invalid-feedback';
            errorDiv.id = errorId;
            errorDiv.textContent = 'This field is required';
            element.parentNode.appendChild(errorDiv);
        }
    }
}

/**
 * Helper function to remove invalid highlighting
 * @param {HTMLElement} element - The form element to unhighlight
 */
function removeInvalidHighlight(element) {
    if (element) {
        element.classList.remove('is-invalid');
        
        // Remove error message if present
        const errorId = `${element.id}-error`;
        const errorDiv = document.getElementById(errorId);
        if (errorDiv) {
            errorDiv.remove();
        }
    }
}

/**
 * Helper function to format currency values
 * @param {number} value - The value to format
 * @param {string} currency - The currency symbol (default: '$')
 * @returns {string} Formatted currency string
 */
function formatCurrency(value, currency = '$') {
    return `${currency}${parseFloat(value).toFixed(2)}`;
}

/**
 * Handles file input display for chart uploads
 * @param {HTMLElement} input - The file input element
 * @param {string} displayElementId - ID of element to display filename
 */
function handleFileInput(input, displayElementId) {
    const displayElement = document.getElementById(displayElementId);
    if (input && displayElement) {
        const fileName = input.files.length > 0 ? input.files[0].name : 'No file selected';
        displayElement.textContent = fileName;
    }
}

/**
 * Updates the risk-reward ratio calculation in real-time
 * Used on trade entry/edit forms
 */
function updateRiskRewardRatio() {
    const entryInput = document.getElementById('entry');
    const slInput = document.getElementById('stop_loss');
    const tpInput = document.getElementById('take_profit');
    const rrOutput = document.getElementById('rr_ratio');
    
    if (entryInput && slInput && tpInput && rrOutput) {
        const entry = parseFloat(entryInput.value);
        const sl = parseFloat(slInput.value);
        const tp = parseFloat(tpInput.value);
        
        if (!isNaN(entry) && !isNaN(sl) && !isNaN(tp) && entry !== 0 && sl !== 0 && tp !== 0) {
            const risk = Math.abs(entry - sl);
            const reward = Math.abs(tp - entry);
            
            if (risk > 0) {
                const ratio = (reward / risk).toFixed(2);
                rrOutput.textContent = ratio;
            } else {
                rrOutput.textContent = 'N/A';
            }
        } else {
            rrOutput.textContent = 'N/A';
        }
    }
}

/**
 * Handles clipboard copy functionality
 * @param {string} text - Text to copy to clipboard
 * @param {HTMLElement} feedbackElement - Element to show feedback in
 * @param {string} feedbackText - Text to show as feedback
 * @param {string} originalText - Original text to restore after feedback
 */
function copyToClipboard(text, feedbackElement, feedbackText = 'Copied!', originalText = '') {
    // Create temporary element
    const tempInput = document.createElement('input');
    tempInput.style.position = 'absolute';
    tempInput.style.left = '-9999px';
    tempInput.value = text;
    document.body.appendChild(tempInput);
    
    // Select and copy
    tempInput.select();
    document.execCommand('copy');
    document.body.removeChild(tempInput);
    
    // Show feedback
    if (feedbackElement) {
        const originalContent = originalText || feedbackElement.textContent;
        feedbackElement.textContent = feedbackText;
        
        // Reset after delay
        setTimeout(() => {
            feedbackElement.textContent = originalContent;
        }, 1500);
    }
}
