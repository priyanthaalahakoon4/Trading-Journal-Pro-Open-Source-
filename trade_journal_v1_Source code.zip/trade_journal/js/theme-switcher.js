/**
 * Theme Switcher for Trading Journal Application
 * Handles theme selection, persistence, and toggle functionality
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize theme system
    initThemeSystem();
});

/**
 * Sets up the theme system and initializes the current theme
 */
function initThemeSystem() {
    // Apply theme from localStorage or default to 'neon'
    const savedTheme = localStorage.getItem('tradeJournalTheme') || 'neon';
    applyTheme(savedTheme);
    
    // Add click handlers to theme selector buttons
    const themeOptions = document.querySelectorAll('.theme-option');
    themeOptions.forEach(option => {
        option.addEventListener('click', function() {
            const theme = this.getAttribute('data-theme-value');
            if (theme) {
                applyTheme(theme);
                // Save theme preference in localStorage
                localStorage.setItem('tradeJournalTheme', theme);
                
                // Update active state on buttons
                themeOptions.forEach(opt => opt.classList.remove('active'));
                this.classList.add('active');
            }
        });
        
        // Set active state on current theme button
        if (option.getAttribute('data-theme-value') === savedTheme) {
            option.classList.add('active');
        }
    });
}

/**
 * Applies the selected theme to the document
 * @param {string} theme - Theme identifier ('neon', 'light', 'financial', 'midnight')
 */
function applyTheme(theme) {
    // Remove any existing theme
    document.body.removeAttribute('data-theme');
    
    // Apply the selected theme (unless it's the default 'neon')
    if (theme && theme !== 'neon') {
        document.body.setAttribute('data-theme', theme);
    }
    
    // Update any theme-specific elements or classes
    updateThemeSpecificElements(theme);
}

/**
 * Updates any elements that need special handling for specific themes
 * @param {string} theme - The active theme
 */
function updateThemeSpecificElements(theme) {
    // Update logo colors, specific element classes, etc. based on theme
    const isDarkTheme = ['neon', 'financial', 'midnight'].includes(theme);
    
    // Update close buttons in modals for light/dark theme
    const closeButtons = document.querySelectorAll('.btn-close');
    closeButtons.forEach(button => {
        if (isDarkTheme) {
            button.classList.add('btn-close-white');
        } else {
            button.classList.remove('btn-close-white');
        }
    });
    
    // You can add more theme-specific adjustments here
}

/**
 * Handle paste from clipboard for screenshot uploads
 * Allows pasting images directly from clipboard
 */
function setupClipboardPaste() {
    // Find all file input elements for chart images
    const fileInputs = document.querySelectorAll('input[type="file"][name="chart_image"]');
    
    fileInputs.forEach(fileInput => {
        // Create a paste zone next to the file input
        const pasteZone = document.createElement('div');
        pasteZone.className = 'paste-zone';
        pasteZone.innerHTML = `
            <div class="paste-instructions">
                <i class="fas fa-paste me-2"></i> Click here and paste image from clipboard (Ctrl+V)
            </div>
        `;
        
        // Insert the paste zone after the file input container
        const fileInputContainer = fileInput.closest('.mb-3');
        if (fileInputContainer) {
            fileInputContainer.appendChild(pasteZone);
        }
        
        // Make the paste zone focusable
        pasteZone.tabIndex = 0;
        
        // Handle paste event on the paste zone
        pasteZone.addEventListener('paste', function(e) {
            handlePaste(e, fileInput);
        });
        
        // Focus and instruct to paste when clicked
        pasteZone.addEventListener('click', function() {
            pasteZone.focus();
        });
        
        // Also handle paste on the document when paste zone is focused
        pasteZone.addEventListener('focus', function() {
            const handleDocumentPaste = function(e) {
                if (document.activeElement === pasteZone) {
                    handlePaste(e, fileInput);
                }
            };
            
            document.addEventListener('paste', handleDocumentPaste);
            
            // Remove the event listener when focus is lost
            pasteZone.addEventListener('blur', function() {
                document.removeEventListener('paste', handleDocumentPaste);
            }, { once: true });
        });
    });
}

/**
 * Process clipboard paste event for image data
 * @param {Event} e - The paste event
 * @param {HTMLElement} fileInput - The file input to update
 */
function handlePaste(e, fileInput) {
    // Prevent the default paste behavior
    e.preventDefault();
    e.stopPropagation();
    
    // Get clipboard items
    const items = (e.clipboardData || window.clipboardData).items;
    
    let imageFile = null;
    
    // Find image data in clipboard
    for (let i = 0; i < items.length; i++) {
        if (items[i].type.indexOf('image') !== -1) {
            imageFile = items[i].getAsFile();
            break;
        }
    }
    
    if (imageFile) {
        // Create a new FileList-like object
        const dataTransfer = new DataTransfer();
        dataTransfer.items.add(imageFile);
        
        // Update the file input with the clipboard image
        fileInput.files = dataTransfer.files;
        
        // Trigger change event to update UI
        const event = new Event('change', { bubbles: true });
        fileInput.dispatchEvent(event);
        
        // If there's a display element for the filename, update it
        const displayElement = document.getElementById('selectedFileName');
        if (displayElement) {
            displayElement.textContent = imageFile.name || 'Image from clipboard';
        }
        
        // Visual feedback
        const pasteZone = fileInput.parentElement.querySelector('.paste-zone');
        if (pasteZone) {
            pasteZone.classList.add('paste-success');
            
            // Show success message
            pasteZone.innerHTML = '<div class="paste-success-message"><i class="fas fa-check-circle me-2"></i> Image added from clipboard!</div>';
            
            // Reset after 3 seconds
            setTimeout(() => {
                pasteZone.classList.remove('paste-success');
                pasteZone.innerHTML = `
                    <div class="paste-instructions">
                        <i class="fas fa-paste me-2"></i> Click here and paste image from clipboard (Ctrl+V)
                    </div>
                `;
            }, 3000);
        }
    }
}

// Initialize clipboard paste functionality when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    setupClipboardPaste();
});