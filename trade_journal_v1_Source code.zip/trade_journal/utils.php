<?php
/**
 * Utility functions for the Trading Journal application
 */

// Allow direct access for non-include files
if (!defined('DIRECT_ACCESS') && basename($_SERVER['SCRIPT_FILENAME']) !== 'utils.php') {
    define('DIRECT_ACCESS', true);
}

/**
 * Format PnL value with correct color class and sign
 * 
 * @param float $pnl The profit/loss value
 * @param bool $with_sign Whether to include +/- sign
 * @return array Containing formatted PnL and CSS class
 */
function format_pnl($pnl, $with_sign = true) {
    $class = 'neutral';
    $formatted = floatval($pnl);
    
    // Determine the class based on value
    if ($formatted > 0) {
        $class = 'profit';
        $formatted = ($with_sign ? '+' : '') . number_format($formatted, 2);
    } elseif ($formatted < 0) {
        $class = 'loss';
        $formatted = number_format($formatted, 2); // Negative sign is already included
    } else {
        $formatted = number_format($formatted, 2);
    }
    
    return [
        'value' => $formatted,
        'class' => $class
    ];
}

/**
 * Calculate risk-reward ratio based on entry, stop loss, and take profit prices
 * 
 * @param float $entry Entry price
 * @param float $stop_loss Stop loss price
 * @param float $take_profit Take profit price
 * @return mixed Risk-reward ratio as float or string if error
 */
function calculate_rr_ratio($entry, $stop_loss, $take_profit) {
    $entry = floatval($entry);
    $stop_loss = floatval($stop_loss);
    $take_profit = floatval($take_profit);
    
    if ($entry > 0 && $stop_loss > 0 && $take_profit > 0) {
        $risk = abs($entry - $stop_loss); // Simple absolute difference
        $reward = abs($take_profit - $entry); // Simple absolute difference
        
        // Calculate if risk > 0 to avoid division by zero
        if ($risk > 0) {
            return round($reward / $risk, 2);
        } else {
            return 'N/A (Zero Risk)';
        }
    } else {
        // If any price is missing or zero
        return 'N/A (Missing Prices)';
    }
}

/**
 * Get current wallet balance based on initial value and trades
 * 
 * @param mysqli $conn Database connection
 * @param float $start_wallet Initial wallet value
 * @return float Current wallet balance
 */
function get_wallet_balance($conn, $start_wallet = 30) {
    $current_wallet = $start_wallet;
    
    // Check if connection is valid
    if (isset($conn) && $conn instanceof mysqli && $conn->ping()) {
        $sql = "SELECT pnl FROM trades";
        $result = $conn->query($sql);
        
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $current_wallet += floatval($row['pnl']);
            }
        }
    }
    
    return $current_wallet;
}

/**
 * Sanitize and validate input data
 * 
 * @param string $data Data to sanitize
 * @return string Sanitized data
 */
function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

/**
 * Get performance statistics from trades
 * 
 * @param mysqli $conn Database connection
 * @return array Statistics data
 */
function get_trade_statistics($conn) {
    $stats = [
        'total_trades' => 0,
        'winning_trades' => 0,
        'losing_trades' => 0,
        'win_rate' => 0,
        'total_pnl' => 0,
        'total_win' => 0,
        'total_loss' => 0,
        'avg_win' => 0,
        'avg_loss' => 0,
        'largest_win' => 0,
        'largest_loss' => 0,
        'best_pair' => 'N/A',
        'worst_pair' => 'N/A'
    ];
    
    if (isset($conn) && $conn instanceof mysqli && $conn->ping()) {
        // Get basic trade statistics
        $sql = "SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN pnl > 0 THEN 1 ELSE 0 END) as winning,
                SUM(CASE WHEN pnl < 0 THEN 1 ELSE 0 END) as losing,
                SUM(pnl) as total_pnl,
                SUM(CASE WHEN pnl > 0 THEN pnl ELSE 0 END) as total_win,
                SUM(CASE WHEN pnl < 0 THEN pnl ELSE 0 END) as total_loss,
                MAX(CASE WHEN pnl > 0 THEN pnl ELSE 0 END) as largest_win,
                MIN(CASE WHEN pnl < 0 THEN pnl ELSE 0 END) as largest_loss
                FROM trades";
        
        $result = $conn->query($sql);
        
        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            
            $stats['total_trades'] = intval($row['total']);
            $stats['winning_trades'] = intval($row['winning']);
            $stats['losing_trades'] = intval($row['losing']);
            $stats['total_pnl'] = floatval($row['total_pnl']);
            $stats['total_win'] = floatval($row['total_win']);
            $stats['total_loss'] = floatval($row['total_loss']);
            $stats['largest_win'] = floatval($row['largest_win']);
            $stats['largest_loss'] = floatval($row['largest_loss']);
            
            // Calculate win rate
            if ($stats['total_trades'] > 0) {
                $stats['win_rate'] = round(($stats['winning_trades'] / $stats['total_trades']) * 100, 1);
            }
            
            // Calculate average win/loss
            if ($stats['winning_trades'] > 0) {
                $stats['avg_win'] = round($stats['total_win'] / $stats['winning_trades'], 2);
            }
            
            if ($stats['losing_trades'] > 0) {
                $stats['avg_loss'] = round($stats['total_loss'] / $stats['losing_trades'], 2);
            }
        }
        
        // Get best/worst performing pairs
        if ($stats['total_trades'] > 0) {
            $pair_sql = "SELECT pair, SUM(pnl) as pair_pnl 
                         FROM trades 
                         GROUP BY pair 
                         ORDER BY pair_pnl DESC 
                         LIMIT 1";
            
            $pair_result = $conn->query($pair_sql);
            if ($pair_result && $pair_result->num_rows > 0) {
                $pair_row = $pair_result->fetch_assoc();
                $stats['best_pair'] = $pair_row['pair'];
            }
            
            $worst_pair_sql = "SELECT pair, SUM(pnl) as pair_pnl 
                              FROM trades 
                              GROUP BY pair 
                              ORDER BY pair_pnl ASC 
                              LIMIT 1";
            
            $worst_pair_result = $conn->query($worst_pair_sql);
            if ($worst_pair_result && $worst_pair_result->num_rows > 0) {
                $worst_pair_row = $worst_pair_result->fetch_assoc();
                $stats['worst_pair'] = $worst_pair_row['pair'];
            }
        }
    }
    
    return $stats;
}

/**
 * Handle file upload for trade images
 * 
 * @param array $file The $_FILES array element
 * @return array Status and file path or error
 */
function handle_file_upload($file) {
    $result = [
        'success' => false,
        'filepath' => '',
        'error' => ''
    ];

    // Check if file was uploaded without errors
    if (isset($file) && $file['error'] == 0) {
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        $max_size = 5 * 1024 * 1024; // 5MB
        
        // Validate file type and size
        if (!in_array($file['type'], $allowed_types)) {
            $result['error'] = 'Invalid file type. Only JPG, PNG, GIF, and WEBP images are allowed.';
            return $result;
        }
        
        if ($file['size'] > $max_size) {
            $result['error'] = 'File too large. Maximum size is 5MB.';
            return $result;
        }
        
        // Create uploads directory if it doesn't exist
        $upload_dir = 'uploads/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }
        
        // Generate a unique filename
        $filename = uniqid('trade_') . '_' . preg_replace('/[^a-zA-Z0-9\.]/', '_', $file['name']);
        $filepath = $upload_dir . $filename;
        
        // Move the uploaded file
        if (move_uploaded_file($file['tmp_name'], $filepath)) {
            $result['success'] = true;
            $result['filepath'] = $filepath;
        } else {
            $result['error'] = 'Failed to save the uploaded file.';
        }
    } else {
        // Map error codes to messages
        switch ($file['error']) {
            case UPLOAD_ERR_INI_SIZE:
            case UPLOAD_ERR_FORM_SIZE:
                $result['error'] = 'File too large.';
                break;
            case UPLOAD_ERR_PARTIAL:
                $result['error'] = 'File was only partially uploaded.';
                break;
            case UPLOAD_ERR_NO_FILE:
                $result['error'] = 'No file was uploaded.';
                break;
            default:
                $result['error'] = 'Unknown upload error.';
        }
    }
    
    return $result;
}

/**
 * Format money with currency symbol
 * 
 * @param float $amount The amount to format
 * @param string|null $currency_symbol Optional currency symbol to use
 * @return string Formatted money string
 */
function format_money($amount, $currency_symbol = null) {
    if ($currency_symbol === null) {
        $currency_symbol = get_currency_symbol();
    }
    
    $amount = floatval($amount);
    return $currency_symbol . number_format($amount, 2);
}

/**
 * Get the currency symbol from settings
 * 
 * @return string Currency symbol (defaults to $ if not set)
 */
function get_currency_symbol() {
    // First try to get from settings table if connection is available
    global $conn;
    
    if (isset($conn) && $conn instanceof mysqli && $conn->ping()) {
        try {
            $query = "SELECT value FROM settings WHERE name = 'currency_symbol'";
            $result = $conn->query($query);
            
            if ($result && $result->num_rows > 0) {
                $row = $result->fetch_assoc();
                return $row['value'];
            }
        } catch (Exception $e) {
            // Fall back to config value if database query fails
        }
    }
    
    // If we can't get from database, try to get from config
    if (defined('CURRENCY_SYMBOL')) {
        return CURRENCY_SYMBOL;
    }
    
    // Default fallback
    return '$';
}

/**
 * Get the initial capital amount from settings
 * 
 * @return float Initial capital amount (defaults to 1000 if not set)
 */
function get_initial_capital() {
    // First try to get from settings table if connection is available
    global $conn;
    
    if (isset($conn) && $conn instanceof mysqli && $conn->ping()) {
        try {
            $query = "SELECT value FROM settings WHERE name = 'initial_capital'";
            $result = $conn->query($query);
            
            if ($result && $result->num_rows > 0) {
                $row = $result->fetch_assoc();
                return floatval($row['value']);
            }
        } catch (Exception $e) {
            // Fall back to config value if database query fails
        }
    }
    
    // If we can't get from database, try to get from config
    if (defined('INITIAL_CAPITAL')) {
        return floatval(INITIAL_CAPITAL);
    }
    
    // Default fallback
    return 1000.00;
}
