<?php
require_once 'db_connect.php';

// Initialize variables
$wallet = get_initial_capital();
$currency_symbol = get_currency_symbol();
$wallet_data = [];
$labels = [];
$dates = [];

// Make sure we have a valid connection
$conn = ensure_db_connection();

try {
    // Query to get trade data ordered by date
    $sql = "SELECT date, pnl, DATE(date) as formatted_date FROM trades ORDER BY date ASC";
    $result = $conn->query($sql);

    // Initial wallet value for starting point
    $wallet_data[] = $wallet;
    $dates[] = '';  // Empty for starting point
    $labels[] = 'Initial';

    if ($result && $result->num_rows > 0) {
        while ($trade = $result->fetch_assoc()) {
            $wallet += floatval($trade['pnl']);
            $wallet_data[] = $wallet;
            $dates[] = $trade['date'];
            $labels[] = $trade['formatted_date'];
        }
    }
} catch (Exception $e) {
    // Error handling for database query
    error_log("Wallet chart error: " . $e->getMessage());
    // Ensure we have at least initial data
    if (empty($wallet_data)) {
        $wallet_data[] = $wallet;
        $labels[] = 'Initial';
    }
}

// We'll use ensure_db_connection() elsewhere when needed

// Color settings for chart
$chart_border_color = '#00ffff';
$chart_background_color = 'rgba(0, 255, 255, 0.1)';
$chart_grid_color = 'rgba(0, 255, 255, 0.1)';
$chart_axis_color = '#8899a8';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wallet Balance History - Trade Journal</title>
    <link rel="icon" type="image/png" href="fav.png">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="themes.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <style>

        body {
            background-color: var(--bg-primary);
            color: var(--text-primary);
            font-family: var(--font-family);
            line-height: 1.6;
        }

        .navbar {
            background-color: var(--bg-secondary);
            border-bottom: 1px solid var(--border-color);
            padding: 0.8rem 0;
        }

        .navbar-brand {
            font-weight: 700;
            font-size: 1.4rem;
            color: var(--neon-cyan);
            text-shadow: 0 0 5px var(--glow-color-cyan);
            display: inline-flex;
            align-items: center;
        }
        .navbar-brand:hover { color: var(--neon-cyan); opacity: 0.9; }

        .navbar-brand svg {
             width: 28px;
             height: 28px;
             margin-right: 8px;
             vertical-align: -0.15em;
        }

        .nav-button {
            color: var(--neon-cyan);
            border: 1px solid var(--neon-cyan);
            background-color: transparent;
            padding: 0.4rem 0.9rem;
            border-radius: var(--border-radius);
            font-weight: 500;
            font-size: 0.9rem;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 0.4rem;
            text-decoration: none;
            margin-left: 0.5rem;
        }
        .nav-button:hover {
            background-color: rgba(0, 255, 255, 0.1);
            box-shadow: 0 0 10px var(--glow-color-cyan);
            color: var(--text-primary);
        }
        .nav-button.primary {
             background-color: var(--neon-cyan);
             color: var(--bg-primary);
             font-weight: 600;
        }
        .nav-button.primary:hover {
              background-color: #00e0e0;
             box-shadow: 0 0 15px var(--glow-color-cyan);
              color: var(--bg-primary);
        }
        
        .page-title {
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 2rem;
            position: relative;
            display: inline-block;
        }
        
        .page-title::after {
            content: '';
            position: absolute;
            bottom: -0.5rem;
            left: 0;
            width: 3rem;
            height: 0.2rem;
            background-color: var(--neon-cyan);
            border-radius: 2px;
            box-shadow: 0 0 10px var(--glow-color-cyan);
        }
        
        .chart-container {
            background-color: var(--bg-secondary);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            position: relative;
            min-height: 400px;
        }
        
        .chart-container:hover {
            border-color: var(--neon-cyan);
            box-shadow: 0 0 20px var(--glow-color-cyan);
        }
        
        .canvas-container {
            position: relative;
            height: 400px;
            width: 100%;
        }
        
        .empty-state {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 3rem 0;
            text-align: center;
            height: 300px;
        }
        
        .empty-state-icon {
            font-size: 3rem;
            color: var(--text-secondary);
            margin-bottom: 1.5rem;
            opacity: 0.6;
        }
        
        .empty-state-text {
            color: var(--text-secondary);
            font-size: 1.1rem;
            margin-bottom: 1.5rem;
        }
        
        .wallet-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .wallet-card {
            background-color: var(--bg-secondary);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: 1.5rem;
            text-align: center;
            transition: all 0.3s ease;
        }
        
        .wallet-card:hover {
            transform: translateY(-5px);
            border-color: var(--neon-cyan);
            box-shadow: 0 0 15px var(--glow-color-cyan);
        }
        
        .wallet-label {
            font-size: 0.9rem;
            color: var(--text-secondary);
            text-transform: uppercase;
            letter-spacing: 0.8px;
            margin-bottom: 0.5rem;
            font-weight: 500;
        }
        
        .wallet-value {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--neon-cyan);
            text-shadow: 0 0 5px var(--glow-color-cyan);
        }
        
        .wallet-value.profit {
            color: var(--neon-green);
            text-shadow: 0 0 5px var(--glow-color-green);
        }
        
        .wallet-value.loss {
            color: var(--neon-red);
            text-shadow: 0 0 5px var(--glow-color-red);
        }

        .stats-container {
            margin-top: 1rem;
        }
    </style>
</head>
<body>
    <?php 
    $current_page = basename($_SERVER['PHP_SELF']);
    include('navigation.php'); 
    ?>

    <div class="container mt-5">
        <h1 class="page-title">Wallet Balance History</h1>
        
        <?php 
        // Calculate performance metrics with error handling
        $initial_capital = get_initial_capital();
        $current_balance = empty($wallet_data) ? $initial_capital : end($wallet_data);
        $total_pnl = $current_balance - $initial_capital;
        $pnl_class = $total_pnl >= 0 ? 'profit' : 'loss';
        $percentage_change = $initial_capital > 0 ? (($current_balance - $initial_capital) / $initial_capital) * 100 : 0;
        ?>
        
        <div class="wallet-cards">
            <div class="wallet-card">
                <div class="wallet-label">Initial Capital</div>
                <div class="wallet-value">
                    <?= $currency_symbol . number_format($initial_capital, 2) ?>
                </div>
            </div>
            
            <div class="wallet-card">
                <div class="wallet-label">Current Balance</div>
                <div class="wallet-value">
                    <?= $currency_symbol . number_format($current_balance, 2) ?>
                </div>
            </div>
            
            <div class="wallet-card">
                <div class="wallet-label">Total P&L</div>
                <div class="wallet-value <?= $pnl_class ?>">
                    <?= $total_pnl >= 0 ? '+' : '' ?><?= $currency_symbol . number_format($total_pnl, 2) ?>
                </div>
            </div>
            
            <div class="wallet-card">
                <div class="wallet-label">Growth</div>
                <div class="wallet-value <?= $pnl_class ?>">
                    <?= $percentage_change >= 0 ? '+' : '' ?><?= number_format($percentage_change, 2) ?>%
                </div>
            </div>
        </div>
        
        <div class="chart-container">
            <?php if(count($wallet_data) > 1): ?>
                <div class="canvas-container">
                    <canvas id="walletChart"></canvas>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <div class="empty-state-icon">
                        <i class="fas fa-chart-line"></i>
                    </div>
                    <div class="empty-state-text">
                        No trade history available yet. Start by adding trades to see your balance evolution.
                    </div>
                    <a href="add_trade.php" class="nav-button primary">
                        <i class="fas fa-plus me-2"></i>Add First Trade
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script src="js/theme-switcher.js"></script>
    <script>
        <?php if(count($wallet_data) > 1): ?>
        // Chart configuration
        const ctx = document.getElementById('walletChart').getContext('2d');
        
        // Function to get colors based on current theme
        function getChartColors() {
            // Get CSS variables based on current theme
            const borderColor = getComputedStyle(document.documentElement).getPropertyValue('--neon-cyan').trim();
            const backgroundColor = `rgba(${hexToRgb(borderColor)}, 0.1)`;
            const gridColor = `rgba(${hexToRgb(borderColor)}, 0.1)`;
            const axisColor = getComputedStyle(document.documentElement).getPropertyValue('--text-secondary').trim();
            
            return {
                borderColor,
                backgroundColor,
                gridColor,
                axisColor
            };
        }
        
        // Helper to convert hex to rgb
        function hexToRgb(hex) {
            // Default to cyan if we can't parse
            if (!hex || hex === '') return '0, 255, 255';
            
            // Handle shorthand hex
            if (hex.charAt(0) === '#') {
                hex = hex.substring(1);
            }
            
            // Parse hex values
            let r, g, b;
            if (hex.length === 3) {
                r = parseInt(hex.charAt(0) + hex.charAt(0), 16);
                g = parseInt(hex.charAt(1) + hex.charAt(1), 16);
                b = parseInt(hex.charAt(2) + hex.charAt(2), 16);
            } else if (hex.length === 6) {
                r = parseInt(hex.substring(0, 2), 16);
                g = parseInt(hex.substring(2, 4), 16);
                b = parseInt(hex.substring(4, 6), 16);
            } else {
                // Default to cyan if format is invalid
                return '0, 255, 255';
            }
            
            return `${r}, ${g}, ${b}`;
        }
        
        // Get initial colors based on current theme
        let chartColors = getChartColors();
        
        const walletChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: <?= json_encode($labels) ?>,
                datasets: [{
                    label: 'Wallet Balance',
                    data: <?= json_encode($wallet_data) ?>,
                    borderColor: chartColors.borderColor,
                    backgroundColor: chartColors.backgroundColor,
                    borderWidth: 2,
                    pointRadius: 4,
                    pointBackgroundColor: chartColors.borderColor,
                    fill: true,
                    tension: 0.4,
                    pointHoverRadius: 6,
                    pointHoverBackgroundColor: 'white',
                    pointHoverBorderColor: chartColors.borderColor,
                    pointHoverBorderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: true,
                        labels: {
                            color: 'rgba(230, 241, 255, 0.8)'
                        }
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false,
                        backgroundColor: 'rgba(20, 24, 33, 0.9)',
                        titleColor: 'rgba(230, 241, 255, 1)',
                        bodyColor: 'rgba(230, 241, 255, 0.8)',
                        borderColor: 'rgba(0, 255, 255, 0.3)',
                        borderWidth: 1,
                        padding: 10,
                        cornerRadius: 4,
                        displayColors: false,
                        callbacks: {
                            label: function(context) {
                                let label = context.dataset.label || '';
                                if (label) {
                                    label += ': ';
                                }
                                label += '<?= $currency_symbol ?>' + parseFloat(context.raw).toFixed(2);
                                return label;
                            }
                        }
                    }
                },
                interaction: {
                    intersect: false,
                    mode: 'index'
                },
                scales: {
                    x: {
                        grid: {
                            color: '<?= $chart_grid_color ?>'
                        },
                        ticks: {
                            color: '<?= $chart_axis_color ?>'
                        }
                    },
                    y: {
                        grid: {
                            color: '<?= $chart_grid_color ?>'
                        },
                        ticks: {
                            color: '<?= $chart_axis_color ?>',
                            callback: function(value) {
                                return '<?= $currency_symbol ?>' + value.toFixed(2);
                            }
                        }
                    }
                }
            }
        });
        
        // Handle window resizing
        window.addEventListener('resize', function() {
            walletChart.resize();
        });
        <?php endif; ?>
    </script>
</body>
</html>
