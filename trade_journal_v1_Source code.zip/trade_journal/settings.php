<?php
include('db_connect.php');

// Initialize variables
$success_message = '';
$error_message = '';
$initial_capital = get_initial_capital();
$currency_symbol = get_currency_symbol();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Update initial capital
    if (isset($_POST['update_capital'])) {
        $new_capital = isset($_POST['initial_capital']) ? floatval($_POST['initial_capital']) : $initial_capital;
        
        if ($new_capital <= 0) {
            $error_message = "Initial capital must be greater than zero.";
        } else {
            if (update_setting('initial_capital', $new_capital)) {
                $initial_capital = $new_capital;
                $success_message = "Initial capital updated successfully.";
            } else {
                $error_message = "Failed to update initial capital.";
            }
        }
    }
    
    // Update currency symbol
    if (isset($_POST['update_currency'])) {
        $new_symbol = sanitize_input($_POST['currency_symbol'] ?? '$');
        
        if (empty($new_symbol)) {
            $error_message = "Currency symbol cannot be empty.";
        } else {
            if (update_setting('currency_symbol', $new_symbol)) {
                $currency_symbol = $new_symbol;
                $success_message = "Currency symbol updated successfully.";
            } else {
                $error_message = "Failed to update currency symbol.";
            }
        }
    }
    
    // Update strategies
    if (isset($_POST['update_strategies'])) {
        $strategies = sanitize_input($_POST['strategies'] ?? '');
        
        if (empty($strategies)) {
            $error_message = "Strategies list cannot be empty.";
        } else {
            if (update_setting('strategies', $strategies)) {
                $success_message = "Strategies updated successfully.";
            } else {
                $error_message = "Failed to update strategies.";
            }
        }
    }
    
    // Update emotions
    if (isset($_POST['update_emotions'])) {
        $emotions = sanitize_input($_POST['emotions'] ?? '');
        
        if (empty($emotions)) {
            $error_message = "Emotions list cannot be empty.";
        } else {
            if (update_setting('emotions', $emotions)) {
                $success_message = "Emotions updated successfully.";
            } else {
                $error_message = "Failed to update emotions.";
            }
        }
    }
    
    // Update market contexts
    if (isset($_POST['update_market_contexts'])) {
        $market_contexts = sanitize_input($_POST['market_contexts'] ?? '');
        
        if (empty($market_contexts)) {
            $error_message = "Market contexts list cannot be empty.";
        } else {
            if (update_setting('market_contexts', $market_contexts)) {
                $success_message = "Market contexts updated successfully.";
            } else {
                $error_message = "Failed to update market contexts.";
            }
        }
    }
    
    // Export data as JSON
    if (isset($_POST['export_data'])) {
        $export_data = array(
            'settings' => array(),
            'trades' => array()
        );
        
        // Get settings
        $sql = "SELECT * FROM settings";
        $result = $conn->query($sql);
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $export_data['settings'][$row['setting_name']] = $row['setting_value'];
            }
        }
        
        // Get trades
        $sql = "SELECT * FROM trades";
        $result = $conn->query($sql);
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $export_data['trades'][] = $row;
            }
        }
        
        // Generate JSON file
        $json_data = json_encode($export_data, JSON_PRETTY_PRINT);
        $filename = 'trade_journal_export_' . date('Y-m-d_H-i-s') . '.json';
        
        // Set headers for download
        header('Content-Type: application/json');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . strlen($json_data));
        
        // Output JSON data
        echo $json_data;
        exit;
    }
    
    // Reset all data with confirmation
    if (isset($_POST['reset_confirm']) && $_POST['reset_confirm'] === 'yes') {
        // Truncate trades table
        $sql = "TRUNCATE TABLE trades";
        if ($conn->query($sql)) {
            // Reset initial capital to default
            update_setting('initial_capital', '30.00');
            $initial_capital = 30.00;
            
            $success_message = "All trade data has been reset successfully.";
        } else {
            $error_message = "Failed to reset data: " . $conn->error;
        }
    }
}

// Calculate statistics
$total_trades = 0;
$total_profit = 0;
$total_loss = 0;
$win_count = 0;

$sql = "SELECT COUNT(*) as total, 
        SUM(CASE WHEN pnl > 0 THEN 1 ELSE 0 END) as wins,
        SUM(CASE WHEN pnl > 0 THEN pnl ELSE 0 END) as profit,
        SUM(CASE WHEN pnl < 0 THEN pnl ELSE 0 END) as loss
        FROM trades";
        
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    $stats = $result->fetch_assoc();
    $total_trades = $stats['total'];
    $win_count = $stats['wins'];
    $total_profit = $stats['profit'];
    $total_loss = $stats['loss'];
}

$win_rate = ($total_trades > 0) ? round(($win_count / $total_trades) * 100, 1) : 0;
$current_balance = $initial_capital + $total_profit + $total_loss;

// Format currency
function format_money($amount) {
    global $currency_symbol;
    return $currency_symbol . number_format($amount, 2);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings - Trade Journal</title>
    <link rel="icon" type="image/png" href="fav.png">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        :root {
            --bg-primary: #0a0c10;
            --bg-secondary: #141821;
            --border-color: rgba(0, 255, 255, 0.2);
            --text-primary: #e6f1ff;
            --text-secondary: #8899a8;
            --neon-cyan: #00ffff;
            --neon-green: #00ff7f;
            --neon-red: #ff3366;
            --neon-yellow: #f5f542;
            --glow-color-cyan: rgba(0, 255, 255, 0.4);
            --glow-color-green: rgba(0, 255, 127, 0.4);
            --glow-color-red: rgba(255, 51, 102, 0.4);
            --border-radius: 8px;
            --font-family: 'Inter', sans-serif;
        }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        body {
            background-color: var(--bg-primary);
            color: var(--text-primary);
            font-family: var(--font-family);
            line-height: 1.6;
        }

        .navbar {
            background-color: var(--bg-secondary);
            border-bottom: 1px solid var(--border-color);
            padding: 0.8rem 0;
            animation: fadeInUp 0.5s ease-out;
        }

        .navbar-brand {
            font-weight: 700;
            font-size: 1.4rem;
            color: var(--neon-cyan);
            text-shadow: 0 0 5px var(--glow-color-cyan);
            display: inline-flex;
            align-items: center;
        }
        .navbar-brand:hover { color: var(--neon-cyan); opacity: 0.9; }

        .navbar-brand svg {
             width: 28px;
             height: 28px;
             margin-right: 8px;
             vertical-align: -0.15em;
        }

        .nav-button {
            color: var(--neon-cyan);
            border: 1px solid var(--neon-cyan);
            background-color: transparent;
            padding: 0.4rem 0.9rem;
            border-radius: var(--border-radius);
            font-weight: 500;
            font-size: 0.9rem;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 0.4rem;
            text-decoration: none;
            margin-left: 0.5rem;
        }
        .nav-button:hover {
            background-color: rgba(0, 255, 255, 0.1);
            box-shadow: 0 0 10px var(--glow-color-cyan);
            color: var(--text-primary);
        }
        .nav-button.primary {
             background-color: var(--neon-cyan);
             color: var(--bg-primary);
             font-weight: 600;
        }
        .nav-button.primary:hover {
              background-color: #00e0e0;
             box-shadow: 0 0 15px var(--glow-color-cyan);
              color: var(--bg-primary);
        }
        .nav-button.danger {
            color: var(--neon-red);
            border-color: var(--neon-red);
        }
        .nav-button.danger:hover {
            background-color: rgba(255, 51, 102, 0.1);
            box-shadow: 0 0 10px var(--glow-color-red);
        }

        .page-title {
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 2rem;
            position: relative;
            display: inline-block;
            animation: fadeInUp 0.6s ease-out;
        }
        
        .page-title::after {
            content: '';
            position: absolute;
            bottom: -0.5rem;
            left: 0;
            width: 3rem;
            height: 0.2rem;
            background-color: var(--neon-cyan);
            border-radius: 2px;
            box-shadow: 0 0 10px var(--glow-color-cyan);
        }

        .settings-card {
            background-color: var(--bg-secondary);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: 2rem;
            margin-bottom: 2rem;
            animation: fadeInUp 0.7s ease-out;
        }

        .settings-card:hover {
            box-shadow: 0 0 15px rgba(0, 255, 255, 0.1);
            border-color: rgba(0, 255, 255, 0.4);
        }

        .settings-title {
            font-size: 1.25rem;
            color: var(--text-primary);
            margin-bottom: 1.5rem;
            font-weight: 600;
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 0.75rem;
        }

        .form-label {
            color: var(--text-primary);
            font-weight: 600;
            margin-bottom: 0.5rem;
        }

        .form-text {
            color: var(--text-secondary);
            font-size: 0.85rem;
        }

        .form-control {
            background-color: rgba(10, 12, 16, 0.5);
            border: 1px solid var(--border-color);
            color: var(--text-primary);
            border-radius: var(--border-radius);
            padding: 0.75rem 1rem;
            transition: all 0.2s ease;
        }

        .form-control:focus {
            background-color: rgba(10, 12, 16, 0.7);
            border-color: var(--neon-cyan);
            box-shadow: 0 0 0 0.25rem rgba(0, 255, 255, 0.2);
            color: var(--text-primary);
        }

        .form-select {
            background-color: rgba(10, 12, 16, 0.5);
            border: 1px solid var(--border-color);
            color: var(--text-primary);
            border-radius: var(--border-radius);
            padding: 0.75rem 1rem;
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='%2300ffff' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='m2 5 6 6 6-6'/%3e%3c/svg%3e");
        }

        .form-check-input {
            background-color: rgba(10, 12, 16, 0.5);
            border: 1px solid var(--border-color);
        }

        .form-check-input:checked {
            background-color: var(--neon-cyan);
            border-color: var(--neon-cyan);
        }

        /* Alert styling */
        .alert {
            border-radius: var(--border-radius);
            padding: 1rem;
            margin-bottom: 1.5rem;
            border: 1px solid transparent;
        }

        .alert-success {
            background-color: rgba(0, 255, 127, 0.1);
            border-color: var(--neon-green);
            color: var(--neon-green);
        }

        .alert-danger {
            background-color: rgba(255, 51, 102, 0.1);
            border-color: var(--neon-red);
            color: var(--neon-red);
        }

        .danger-zone {
            background-color: rgba(255, 51, 102, 0.05);
            border: 1px solid rgba(255, 51, 102, 0.3);
        }

        .danger-zone .settings-title {
            color: var(--neon-red);
            border-bottom-color: rgba(255, 51, 102, 0.3);
        }

        .danger-zone-warning {
            color: var(--text-secondary);
            font-size: 0.9rem;
            margin-bottom: 1rem;
            font-style: italic;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .stat-card {
            background-color: rgba(10, 12, 16, 0.3);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: 1.5rem;
            text-align: center;
            transition: all 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            border-color: var(--neon-cyan);
            box-shadow: 0 0 15px var(--glow-color-cyan);
        }

        .stat-label {
            color: var(--text-secondary);
            font-size: 0.85rem;
            margin-bottom: 0.5rem;
            text-transform: uppercase;
            letter-spacing: 0.8px;
            font-weight: 500;
        }

        .stat-value {
            font-size: 1.75rem;
            font-weight: 700;
            color: var(--neon-cyan);
            text-shadow: 0 0 5px var(--glow-color-cyan);
        }

        .stat-value.positive {
            color: var(--neon-green);
            text-shadow: 0 0 5px var(--glow-color-green);
        }

        .stat-value.negative {
            color: var(--neon-red);
            text-shadow: 0 0 5px var(--glow-color-red);
        }

        /* Modal styling */
        .modal-content {
            background-color: var(--bg-secondary);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
        }

        .modal-header {
            border-bottom: 1px solid var(--border-color);
            color: var(--text-primary);
        }

        .modal-title {
            color: var(--text-primary);
            font-weight: 600;
        }

        .modal-body {
            color: var(--text-primary);
        }

        .modal-footer {
            border-top: 1px solid var(--border-color);
        }

        .btn-close {
            color: var(--text-primary);
            filter: invert(1);
        }

        .input-group-text {
            background-color: rgba(10, 12, 16, 0.7);
            border: 1px solid var(--border-color);
            color: var(--text-primary);
        }
    </style>
</head>
<body>
    <?php 
    $current_page = basename($_SERVER['PHP_SELF']);
    include('navigation.php'); 
    ?>

    <div class="container mt-5">
        <h1 class="page-title">Settings</h1>

        <?php if (!empty($success_message)): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle me-2"></i> <?= htmlspecialchars($success_message) ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($error_message)): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle me-2"></i> <?= htmlspecialchars($error_message) ?>
            </div>
        <?php endif; ?>

        <!-- Account Summary -->
        <div class="settings-card">
            <h2 class="settings-title">
                <i class="fas fa-chart-line me-2"></i> Account Summary
            </h2>
            
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-label">Initial Capital</div>
                    <div class="stat-value"><?= format_money($initial_capital) ?></div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-label">Current Balance</div>
                    <div class="stat-value"><?= format_money($current_balance) ?></div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-label">Total P&L</div>
                    <div class="stat-value <?= ($total_profit + $total_loss) >= 0 ? 'positive' : 'negative' ?>">
                        <?= format_money($total_profit + $total_loss) ?>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-label">Win Rate</div>
                    <div class="stat-value"><?= $win_rate ?>%</div>
                </div>
            </div>
        </div>

        <!-- Capital Settings -->
        <div class="settings-card">
            <h2 class="settings-title">
                <i class="fas fa-money-bill-wave me-2"></i> Capital Settings
            </h2>
            
            <form method="post" class="mb-4">
                <div class="mb-3">
                    <label for="initial_capital" class="form-label">Initial Capital</label>
                    <div class="input-group">
                        <span class="input-group-text"><?= htmlspecialchars($currency_symbol) ?></span>
                        <input type="number" step="0.01" min="0.01" class="form-control" id="initial_capital" name="initial_capital" value="<?= htmlspecialchars($initial_capital) ?>" required>
                    </div>
                    <div class="form-text">This is your starting capital amount. Changing this will affect your total profit/loss calculations.</div>
                </div>
                <button type="submit" name="update_capital" class="nav-button primary">
                    <i class="fas fa-save me-2"></i> Update Capital
                </button>
            </form>
            
            <form method="post">
                <div class="mb-3">
                    <label for="currency_symbol" class="form-label">Currency Symbol</label>
                    <input type="text" class="form-control" id="currency_symbol" name="currency_symbol" value="<?= htmlspecialchars($currency_symbol) ?>" maxlength="5" required>
                    <div class="form-text">Symbol displayed for currency values (e.g., $, €, £, ¥)</div>
                </div>
                <button type="submit" name="update_currency" class="nav-button primary">
                    <i class="fas fa-save me-2"></i> Update Currency
                </button>
            </form>
        </div>

        <!-- Trading Metadata Management -->
        <div class="settings-card">
            <h2 class="settings-title">
                <i class="fas fa-tags me-2"></i> Trading Metadata
            </h2>
            
            <!-- Strategies -->
            <form method="post" class="mb-4">
                <div class="mb-3">
                    <label for="strategies" class="form-label">Trading Strategies</label>
                    <textarea class="form-control" id="strategies" name="strategies" rows="4"><?= htmlspecialchars(get_setting('strategies')) ?></textarea>
                    <div class="form-text">Enter strategies separated by commas (e.g., "Trend Following,Breakout,Range Trading")</div>
                </div>
                <button type="submit" name="update_strategies" class="nav-button primary">
                    <i class="fas fa-save me-2"></i> Update Strategies
                </button>
            </form>
            
            <!-- Emotions -->
            <form method="post" class="mb-4">
                <div class="mb-3">
                    <label for="emotions" class="form-label">Trading Emotions</label>
                    <textarea class="form-control" id="emotions" name="emotions" rows="4"><?= htmlspecialchars(get_setting('emotions')) ?></textarea>
                    <div class="form-text">Enter emotions separated by commas (e.g., "Calm,Excited,Fearful,Greedy")</div>
                </div>
                <button type="submit" name="update_emotions" class="nav-button primary">
                    <i class="fas fa-save me-2"></i> Update Emotions
                </button>
            </form>
            
            <!-- Market Contexts -->
            <form method="post" class="mb-4">
                <div class="mb-3">
                    <label for="market_contexts" class="form-label">Market Contexts</label>
                    <textarea class="form-control" id="market_contexts" name="market_contexts" rows="4"><?= htmlspecialchars(get_setting('market_contexts')) ?></textarea>
                    <div class="form-text">Enter market contexts separated by commas (e.g., "Trending Up,Trending Down,Ranging,Volatile")</div>
                </div>
                <button type="submit" name="update_market_contexts" class="nav-button primary">
                    <i class="fas fa-save me-2"></i> Update Market Contexts
                </button>
            </form>
        </div>

        <!-- Data Management -->
        <div class="settings-card">
            <h2 class="settings-title">
                <i class="fas fa-database me-2"></i> Data Management
            </h2>
            
            <form method="post" class="mb-4">
                <div class="mb-3">
                    <p>Export all your trade data and settings as a JSON file for backup purposes.</p>
                </div>
                <button type="submit" name="export_data" class="nav-button primary">
                    <i class="fas fa-file-export me-2"></i> Export Data
                </button>
            </form>
        </div>

        <!-- Danger Zone -->
        <div class="settings-card danger-zone">
            <h2 class="settings-title">
                <i class="fas fa-exclamation-triangle me-2"></i> Danger Zone
            </h2>
            
            <div class="danger-zone-warning">
                <p><strong>Warning:</strong> The actions below are irreversible. Please proceed with caution.</p>
            </div>
            
            <div class="mb-4">
                <p>Reset all your trade data and return to initial settings. This will delete all your trade records.</p>
                <button type="button" class="nav-button danger" data-bs-toggle="modal" data-bs-target="#resetConfirmModal">
                    <i class="fas fa-trash me-2"></i> Reset All Data
                </button>
            </div>
        </div>
    </div>

    <!-- Reset Confirmation Modal -->
    <div class="modal fade" id="resetConfirmModal" tabindex="-1" aria-labelledby="resetConfirmModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="resetConfirmModalLabel">Confirm Reset</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Are you absolutely sure you want to reset all data? This action will:</p>
                    <ul>
                        <li>Delete all your trade records</li>
                        <li>Reset your initial capital to default (<?= format_money(30.00) ?>)</li>
                        <li>Clear all performance statistics</li>
                    </ul>
                    <p class="text-danger"><strong>This action cannot be undone!</strong></p>
                    <div class="form-check mt-3">
                        <input class="form-check-input" type="checkbox" id="confirmCheck">
                        <label class="form-check-label" for="confirmCheck">
                            I understand that this action is irreversible
                        </label>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="nav-button" data-bs-dismiss="modal">Cancel</button>
                    <form method="post">
                        <input type="hidden" name="reset_confirm" value="yes">
                        <button type="submit" id="resetButton" class="nav-button danger" disabled>
                            <i class="fas fa-trash me-2"></i> Reset All Data
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    
    <script>
        // Handle confirmation checkbox for reset
        const confirmCheck = document.getElementById('confirmCheck');
        const resetButton = document.getElementById('resetButton');
        
        confirmCheck.addEventListener('change', function() {
            resetButton.disabled = !this.checked;
        });
    </script>
</body>
</html>
